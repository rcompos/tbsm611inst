#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

#set -n
. $PREREQ_HOME/lib/common_function.sh

logInfo "In config_parser.sh File"
logDebug "OSInfo   $1"
logDebug "ProductCode   $2"
logDebug "OSArch   $3"
logDebug "CPUArch   $4"
logDebug "Version   $5"
logDebug "XXX   $6"

###Validating and Handling the mutliple Configuration files Case####
version=`echo "$5" | cut -d "=" -f2`
check=`echo $version | grep  "[0-9]"`
logDebug "config_parser.sh - check=$check"
if [ $check ]; then
        mv $PREREQ_HOME/UNIX_Linux/$2_$version.cfg $PREREQ_HOME/UNIX_Linux/$2_$version.cfg-Master 2>/dev/null
        Master_File="$PREREQ_HOME/UNIX_Linux/$2_$version.cfg-Master"

	cat $Master_File 2> /dev/null |  grep -v "^#" | grep -i "\[sev:WARN\]" > $TMP_DIR/TMP_$2_$version.tmp

	#Remove the Warning messages from Master config file if any
	cat $Master_File 2> /dev/null | sed 's/\[[S|s][E|e][V|v]:[w|W][a|A][r|R][n|N]\]//g' | sed 's/\[[S|s][E|e][V|v]:[E|e][R|r][R|r][O|o][R|r]\]//g' | sed 's/\[[S|s][E|e][V|v]:[F|f][A|a][I|i][L|l]\]//g' > $TMP_DIR/BAK_${tmpCfgfile}-Master
	mv $TMP_DIR/BAK_${tmpCfgfile}-Master $Master_File

        TEMPvar=""
        TEMPvar=`cat $Master_File 2> /dev/null | grep -v "^#" | grep '$TEMP'`
        #Check if the TEMP and TMP environment variables are defined in the product config file
        if [ "$TEMPvar" != "" ]; then
                if [ -z "$TEMP" ]; then
                if [ -z "$TEMP" ]; then
                        echo "" >> $TMP_DIR/SectionWarningMsg.txt
                        printmessage "$ENV_VAR_IS_NOT_SET_IN_MACHINE_STR" "TEMP" >> $TMP_DIR/SectionWarningMsg.txt
                        echo "TEMP=FALSE" 2> /dev/null >> $TMP_DIR/envVarChecking.txt
                else
                        echo "TEMP=TRUE" 2> /dev/null >> $TMP_DIR/envVarChecking.txt
                fi
                fi

        fi
        TEMPvar=""
        TEMPvar=`cat $Master_File | grep -v "^#" | grep '$TMP'`
        if [ "$TEMPvar" != "" ]; then
                if [ -z "$TMP" ]; then
                if [ -z "$TMP" ]; then
                        echo "" >> $TMP_DIR/SectionWarningMsg.txt
                        printmessage "$ENV_VAR_IS_NOT_SET_IN_MACHINE_STR" "TMP" >> $TMP_DIR/SectionWarningMsg.txt
                        echo "TMP=FALSE" 2> /dev/null >> $TMP_DIR/envVarChecking.txt
                else
                        echo "TMP=TRUE" 2> /dev/null >> $TMP_DIR/envVarChecking.txt
                fi
                fi
        fi

        CtrlMchar=""
        #Check for control M (CTRL-M) characters in the product config file
        CtrlMchar=`cat $Master_File 2>/dev/null | awk '/\015/ { print $0}'`
        if [ "$CtrlMchar" != "" ]; then
                #Delete the CTRL-M char from the product config file
                cat $Master_File 2> /dev/null | tr -s "\015" " " > /$TMP_DIR/tmpCTRLfile.cfg
                mv /$TMP_DIR/tmpCTRLfile.cfg $Master_File
                logDebug "Found Ctrl-M charecters in the config file : $Master_File"
                echo " " >> $TMP_DIR/SectionWarningMsg.txt
                printmessage "$REMOVE_CTRL_M_CHAR_STR" "`basename $Master_File | sed 's/-Master//g'`" >> $TMP_DIR/SectionWarningMsg.txt
                echo " " >> $TMP_DIR/SectionWarningMsg.txt
        fi
        CONFIG="$Master_File"
else
	Master_File="`ls $PREREQ_HOME/UNIX_Linux/$2*.cfg 2>/dev/null | sort -ir | sed -n "1p"`"
	logDebug "Master_File=$Master_File"

	if [ "$Master_File" = "" ]; then
		logDebug "Master_File not Found, returning back."
		exit
	fi

	tmpMaster_File=`basename "$Master_File" | sed 's/-Master//g' | sed 's/cfg/tmp/g'`
	cat $Master_File 2> /dev/null | grep -v "^#" | grep -i "\[sev:WARN\]" > $TMP_DIR/TMP_${tmpMaster_File}
	#Remove the Warning messages from Master config file if any
	cat $Master_File 2> /dev/null | sed 's/\[[S|s][E|e][V|v]:[w|W][a|A][r|R][n|N]\]//g' | sed 's/\[[S|s][E|e][V|v]:[E|e][R|r][R|r][O|o][R|r]\]//g' | sed 's/\[[S|s][E|e][V|v]:[F|f][A|a][I|i][L|l]\]//g' > $TMP_DIR/BAK_${tmpCfgfile}-Master
	mv $TMP_DIR/BAK_${tmpCfgfile}-Master $Master_File

	TEMPvar=""
	TEMPvar=`cat $Master_File 2> /dev/null | grep -v "^#" | grep '$TEMP'`
	#Check if the TEMP and TMP environment variables are defined in the product config file
	if [ "$TEMPvar" != "" ]; then
		if [ -z "$TEMP" ]; then
                if [ -z "$TEMP" ]; then
                        echo "" >> $TMP_DIR/SectionWarningMsg.txt
                        printmessage "$ENV_VAR_IS_NOT_SET_IN_MACHINE_STR" "TEMP" >> $TMP_DIR/SectionWarningMsg.txt
                        echo "TEMP=FALSE" 2> /dev/null >> $TMP_DIR/envVarChecking.txt
                else
                        echo "TEMP=TRUE" 2> /dev/null >> $TMP_DIR/envVarChecking.txt
                fi
		fi

	fi
	TEMPvar=""
	TEMPvar=`cat $Master_File | grep -v "^#" | grep '$TMP'`
	if [ "$TEMPvar" != "" ]; then
		if [ -z "$TMP" ]; then
                if [ -z "$TMP" ]; then
                        echo "" >> $TMP_DIR/SectionWarningMsg.txt
                        printmessage "$ENV_VAR_IS_NOT_SET_IN_MACHINE_STR" "TMP" >> $TMP_DIR/SectionWarningMsg.txt
                        echo "TMP=FALSE" 2> /dev/null >> $TMP_DIR/envVarChecking.txt
                else
                        echo "TMP=TRUE" 2> /dev/null >> $TMP_DIR/envVarChecking.txt
                fi
		fi
	fi

        CtrlMchar=""
	#Check for control M (CTRL-M) characters in the product config file
        CtrlMchar=`cat $Master_File 2>/dev/null | awk '/\015/ { print $0}'`
        if [ "$CtrlMchar" != "" ]; then
		#Delete the CTRL-M char from the product config file
                cat $Master_File 2> /dev/null | tr -s "\015" " " > /$TMP_DIR/tmpCTRLfile.cfg
                mv /$TMP_DIR/tmpCTRLfile.cfg $Master_File
                logDebug "Found Ctrl-M charecters in the config file : $Master_File"
                echo " " >> $TMP_DIR/SectionWarningMsg.txt
                printmessage "$REMOVE_CTRL_M_CHAR_STR" "`basename $Master_File`" >> $TMP_DIR/SectionWarningMsg.txt
                echo " " >> $TMP_DIR/SectionWarningMsg.txt
        fi
	logDebug "Meti*****2=$Master_File***version=$version****"
        mv $Master_File $Master_File"-Master" 2>/dev/null
        CONFIG=$Master_File"-Master"
        echo $CONFIG >/$TMP_DIR/check5
        logDebug "config_parser.sh - done else block"
fi

FALSE=1
TRUE=0
GetIn=$FALSE
First_String=""
ParseCount=0
ParseArray=""

# Function name : Form_Parse_String
# Description   : Forms the Array to compare with the section in the config file
# inputs        : $1 -> Section name to parse
#
Form_Parse_String() {

        logInfo "Form_Parse_String"
        logDebug "OSInfo   $1"
        logDebug "ProductCode   $2"
        logDebug "OSArch   $3"
        logDebug "CPU   $4"
        logDebug "CPUArch   $5"
        logDebug "Heath   $6"

        OSNamepre=`echo $1 | cut -d '{' -f1`
        ## REmoving release from OSNAME for RedHatEnterpriseLinuxServer release
        ## Removing V from OSName for Solaris V10 and removing spaces   
        OSName=`echo $OSNamepre | sed 's/release//g' |sed  's/V//g' | sed  's/ //g'`
        #Detect the OS version if it is Oracle Solaris System
        if [ "`uname`" = "SunOS" ]; then
                IsOracleSun=`cat /etc/*release 2>/dev/null | grep "Solaris" | grep "Oracle"`
                if [ "$IsOracleSun" != "" ]; then
                        OSName=`echo "$IsOracleSun" | awk '{print $2$3}'`
                fi
        fi
        ###Check for Update in RHEL 4Versions anc change it to specified format###
        isred=`cat /etc/*release 2>/dev/null | grep "Linux" | awk '{print $1}' | sed -n '/[Rr]ed/p'| sed -n 1p`
        if [ $isred ]; then
                # get the version
                ver4=`cat /etc/*release 2>/dev/null | grep "Linux" | grep "Red" | sed 's/.* release \([0-9]\{1,\}\).*/\1/g'| sed -n 1p`
                if [ $ver4 ]; then
                        UpdateFound=`cat /etc/*release 2>/dev/null | grep -i update | sed 's/[Uu]pdate/[Uu]pdate+/g' | cut -d "+" -f2 | sed 's/ //g' | cut -c 1 | sed -n 1p`
                        if [ $UpdateFound ]; then
                                OSName=$OSName"."$UpdateFound
                        fi
                fi
        fi

	cputest=`echo $4 | cut -d '=' -f2`
	Archtest=`echo $3 | cut -d "=" -f2`
	HealthArchtest=`echo "$6" | cut -d "=" -f2`
        CPUArchtest=`echo "$5" | cut -d "=" -f2`
        if [ "$cputest" = "" ]; then
      		if [ "$Archtest" = "" ]; then
       			Section="[OSType:$OSName]" 
       	 	else
       			Section="[OSType:$OSName][OSArch:$Archtest]" 
           	fi
       else
      	        Section="[OSType:$OSName][OSArch:$3][CPU:$cputest]" 
       fi

       if [ "$CPUArchtest" = "" ]; then
       		echo "$Section[OSKernel:$CPUArchtest]" >/$TMP_DIR/prs.test3
       else
       		Section="$Section[CPUArch:$CPUArchtest]"
       fi
       if [ "$HealthArchtest" != "" ]; then
                Section="$Section[Health:$HealthArchtest]"
       fi
       

        ParseArray=""
        IsRedhatFound=""
        IsEnterpriseFound=""
        ISAdvanceFound="" 
			#####Checking for OS NAME and adding the Sections to the CONFIG Fiel####
			IsAIXFound=`echo "$OSName" | grep AIX | cut -d " " -f1`
			IsRedhatFound=`echo "$OSName" | grep -i "RedHat" | cut -d " " -f1`
                        IsEnterpriseFound=`echo "$OSName" | grep -i "Enterprise" | cut -d " " -f1`
                        ISAdvanceFound=`echo "$OSName" | grep -i "Advance" | cut -d " " -f1`
			ISAdvanceASFound=`echo "$OSName" | grep  "AS" | cut -d " " -f1`
			ISAdvanceESFound=`echo "$OSName" | grep  "ES" | cut -d " " -f1`
                        IsRedhatEnterpriseLinuxServerFound=`echo "$OSName" | grep -i "RedHatEnterpriseLinux" | cut -d " " -f1`
			IsSolarisFound=`echo "$OSName" | grep -i Solaris | cut -d " " -f1`
			IsSUSEFound=`echo "$OSName" | grep -i "SUSE" | cut -d " " -f1`
			IsCentOSFound=`echo "$OSName" | grep -i "CentOS" | cut -d " " -f1`

			IsHP_UXFound=`echo "$OSName" | grep -i HP-UX | cut -d " " -f1`
			IsHP_UXv1Found=`echo "$OSName" | grep -i HP-UX | grep -i 11iv1 | cut -d " " -f1`
			IsHP_UXv2Found=`echo "$OSName" | grep -i HP-UX | grep -i 11iv2 |cut -d " " -f1`
			IsHP_UXv3Found=`echo "$OSName" | grep -i HP-UX | grep -i 11iv3 |cut -d " " -f1`
			
                        if [ $IsHP_UXFound ]; then
                                ParseArray="[OSType:UNIX][OSType:HP-UX]$Section"
			# Hp-UX version 1
                        elif [ $IsHP_UXv1Found ]; then
                                ParseArray="[OSType:UNIX][OSType:HP-UX][OSType:HP-UX 11iv1]$Section"
			# Hp-UX version 2
                        elif [ $IsHP_UXv2Found ]; then
                                ParseArray="[OSType:UNIX][OSType:HP-UX][OSType:HP-UX 11iv2]$Section"
			# Hp-UX version 3
                        elif [ $IsHP_UXv3Found ]; then
                                ParseArray="[OSType:UNIX][OSType:HP-UX][OSType:HP-UX 11iv3]$Section"

                        elif [ $IsSolarisFound ]; then
                                ParseArray="[OSType:UNIX][OSType:Solaris]$Section"
                        elif [ $IsSUSEFound ]; then
                                ParseArray="[OSType:UNIX][OSType:LINUX][OSType:SUSE]$Section"

                        elif [ $IsCentOSFound ]; then
                                ParseArray="[OSType:UNIX][OSType:LINUX][OSType:CentOS]$Section"

                        elif [ $IsAIXFound ]; then
				VersionString=`echo $OSName | cut -d '.' -f1`".*"
				ParseArray="[OSType:UNIX][OSType:AIX][OSType:$VersionString]$Section"

                        elif [ $IsRedhatEnterpriseLinuxServerFound ]; then
                                 VersionString=`echo $OSName | cut -d '.' -f1`".*"
                                 ParseArray="[OSType:UNIX][OSType:LINUX][OSType:RedHat][OSType:RedHatEnterpriseLinuxServer][OSType:$VersionString]$Section"
                                 if [ "$ISAdvanceFound" != "" ]; then
                                 	ParseArray="[OSType:UNIX][OSType:LINUX][OSType:RedHat][OSType:RedHatEnterpriseLinuxServer][OSType:RedHatEnterpriseLinuxAdvance][OSType:$VersionString]$Section"
                                 fi
                                 if [ "$ISAdvanceASFound" != "" ]; then
                                   	OSName1=`echo $OSName | sed 's/AS/Server/g'`
                                   
                                   	VersionString1=`echo $OSName1 | cut -d '.' -f1`".*"
                                   	ParseArray="[OSType:UNIX][OSType:LINUX][OSType:RedHat][OSType:$VersionString1][OSType:RedHatEnterpriseLinuxAS][OSType:$VersionString]$Section"
                                 fi
                                 if [ "$ISAdvanceESFound" != "" ]; then
                                       OSName1=`echo $OSName | sed 's/ES/Server/g'`

                                        VersionString1=`echo $OSName1 | cut -d '.' -f1`".*"
                                   	ParseArray="[OSType:UNIX][OSType:LINUX][OSType:RedHat][OSType:RedHatEnterpriseLinuxServer][OSType:RedHatEnterpriseLinuxES][OSType:$VersionString]$Section"
                                 fi

			elif [ "$IsRedhatFound" != "" -a "$ISAdvanceFound" != ""  -o "$ISAdvanceESFound" != "" -o "$ISAdvanceASFound" != ""  ]; then
                                 VersionString=`echo $OSName | cut -d '.' -f1`".*" 
			         ParseArray="[OSType:UNIX][OSType:LINUX][OSType:RedHat][OSType:$VersionString]$Section"

                        else
				ParseArray="[OSType:UNIX]"
                                #echo "WARNING: Product doesn't support this OS"
			fi
               
                	ParseArray=$ParseArray
	logDebug "Form_Parse_String - ParseArray: $ParseArray"
        logDebug "Exiting Form_Parse_String"

}

# Function name : Read_conigFile
# Description   : Reads the config file with sectionwise and the result will be store in file
# inputs        : $1 -> config File name
#
Read_conigFile() {
	
        logDebug "Entering Read_configFile()"
	logDebug "ConfigFile   $1"
        logDebug "Product   $2"
	CONFIG_FILE=$1
	RCorgParseArray=$ParseArray
	basenameofConfigFile=`basename $1`
	ConfigFileName=$2
	ConfigFileversion=`echo "$basenameofConfigFile" | cut -d"_" -f2 | cut -d"." -f1`
	logDebug "ConfigFileName=$ConfigFileName ** ConfigFileversion=$ConfigFileversion"
        if [ -f $CONFIG_FILE ]; then


        	cat $CONFIG_FILE | while read LINE
        	do
				LINE=`echo "$LINE" | tr -d '\n'`
        		TRIM_LINE=`echo "$LINE" | tr -s "        " " " | sed  's/:[ ]*/:/g'`
				logDebug "Found the line : $LINE"
				logDebug "Found the line : $TRIM_LINE"
               
              	#Skip the commented lines
              	FIRSTCHAR_TRIM_LINE=`echo "$TRIM_LINE" | cut -c 1`
                if [ "$FIRSTCHAR_TRIM_LINE" = "#" ]
                then
                       	continue
                fi
                if [ -z "$TRIM_LINE" ]
                then
                       	continue
                fi
				# Check if the line has the empty braces li [][Disk] or [Disk][] or [disk][      ]
				if [ "`echo "$TRIM_LINE" | awk '/\[\]/||/\[ \]/'`" ]; then
                	logDebug "Line = $LINE contains empty brackets"
					echo " " >> $TMP_DIR/SectionWarningMsg.txt
					printmessage "$SECTION_MISSING_DELIMITER_WARN_STR" "[$ConfigFileName $ConfigFileversion]" "$TRIM_LINE" >> $TMP_DIR/SectionWarningMsg.txt
					echo " " >> $TMP_DIR/SectionWarningMsg.txt
					GetInFlag=FALSE
					continue
                fi

                FIRSTCHAR_LINE=`echo "$LINE" | cut -c 1`
                LenLINE=`echo "$LINE" | tr -s "        " " " |  wc -m`
                LLINE=`expr $LenLINE - 1`
                LASTCHAR=`echo "$LINE" | cut -c $LLINE` 
				if [ "$FIRSTCHAR_LINE" = "[" -a "$LASTCHAR" != "]" ]; then
					echo " " >> $TMP_DIR/SectionWarningMsg.txt
					printmessage "$SECTION_MISSING_CLOSING_BRACKET_WARN_STR" "[$ConfigFileName $ConfigFileversion]"  "$LINE" >> $TMP_DIR/SectionWarningMsg.txt
					echo " " >> $TMP_DIR/SectionWarningMsg.txt
					GetInFlag=FALSE
					continue
				fi
	            if [ "$FIRSTCHAR_LINE" = "[" -a "$LASTCHAR" = "]" ]
        	    then
                	if [ $GetIn -eq $TRUE ]
                   	then
                           	GetIn=$FALSE
                   	fi
                      
			ParseArray=$RCorgParseArray
			###Checking for ENV variables###
	                EnvFound=`echo "$TRIM_LINE" | grep "@" | cut -d ":" -f1`
			logDebug "Is the line contains char @ ? $EnvFound"
        	        if [ $EnvFound ]; then
				OrigLine=`echo "$TRIM_LINE" | sed 's/\]\[/\] \[/g' | sed 's/|/\] \[/g'`
				logDebug "Strip the [], line = $OrigLine"
				EnvLine=""
				for EvryField in $OrigLine
				do
					####Check for EnvSymbol####
					IsFound=`echo "$EvryField" | cut -c 2`
					if [ "$IsFound" = "@" ]; then
						EnvLine=$EvryField" $EnvLine"
						logDebug "Line contains environment variable : $EnvLine"
					fi
				done
                                
						####ENV Variables Line Created,Now Checking the EnvValues Set in the Environment####
                                
						for EnvField in $EnvLine
                        do
                           	EnvVar=`echo "$EnvField" | cut -c 3- | cut -d ":" -f1 `
                           	logDebug "Found Env Var - $EnvVar"
                           	ConfigEnvVal=`echo "$EnvField" | cut -d ":" -f2 | cut -d "]" -f1`
                           	logDebug "$EnvVar has '$ConfigEnvVal' in config file"
					
        	                ####Finding the EnvVar Value from Environment####
                                ExistingEnvVal=`env | grep "$EnvVar" | cut -d "=" -f2`
                                logDebug "$EnvVar env var value - '$ExistingEnvVal'"
                                if [ "$ConfigEnvVal" = "$ExistingEnvVal" ]; then
                                        logDebug "$EnvVar environment variables evaluated to TRUE"
                                        logDebug "$EnvVar environment variables real Value : $ExistingEnvVal"
                                        if [ "$ExistingEnvVal" = "" ]; then
                                                echo "$EnvVar=[Not Found]" >> $TMP_DIR/ENV_VARIABLE_SETTINGS_STR.txt
                                        else
                                                echo "$EnvVar=$ExistingEnvVal" >> $TMP_DIR/ENV_VARIABLE_SETTINGS_STR.txt
                                        fi
                                        logDebug "Adding $EnvVar to ParseArray..."
                                        ParseArray=$ParseArray$EnvField
                                        logDebug "Environment variable $EnvVar found"
                                else
                                        logDebug "$EnvVar environment variables evaluated to FALSE"
                                        logDebug "$EnvVar environment variables real Value : $ExistingEnvVal"
                                        if [ "$ExistingEnvVal" = "" ]; then
                                                echo "$EnvVar=[Not Found]" >> $TMP_DIR/ENV_VARIABLE_SETTINGS_STR.txt
                                        else
                                                echo "$EnvVar=$ExistingEnvVal" >> $TMP_DIR/ENV_VARIABLE_SETTINGS_STR.txt
                                        fi
                                fi
                   		 done
                   	fi

					PropFound=`echo "$TRIM_LINE" | grep "="`
					logDebug "Found the Property : $PropFound"
                    if [ "$PropFound" ]; then
                    	OrigLine=`echo "$TRIM_LINE" | sed 's/ /%/g' | sed 's/\]\[/\] \[/g' | sed 's/|/ \[\] /g'`
                        PropLine=""
						logDebug "OrigLine=$OrigLine"
                        for PropField in $OrigLine
                        do
                        	####Check for EnvSymbol####
                            IsFound=`echo "$PropField" | grep "="`
                            if [ "$IsFound" ]; then
					notSectionCheck=""
					notSectionCheck=`echo "$PropField" | grep "!"`
					logDebug "Is the section contains ! ? $notSectionCheck"
					if [ $notSectionCheck ]; then 
						logDebug "Yes found !"
						PropField=`echo "$PropField" | sed 's/!//g'`
						PropResult=`Execute_Property "$PropField"`
						if [ "$PropResult" = "$FAIL_STR" ]; then
							logDebug "Property execution is PASSED"
							logDebug "Return value from Property : FAIL"
							ParseArray=$ParseArray$PropField
						fi
					else
						PropResult=`Execute_Property "$PropField"`
						if [ "$PropResult" = "$PASS_STR" ]; then
							logDebug "Property execution is PASSED"
							logDebug "Return value from Property : PASS"
							ParseArray=$ParseArray$PropField
						fi
					fi
                       		fi
                       	done
               		fi

			#echo "** $ParseArray ** "
			logDebug "Replace the [ and ] char to ~ before the grep"
                	Trim_ParseArray=`echo "$ParseArray~" | sed 's/\]/~/g' | sed 's/\[/~/g' | sed 's/\//~/g'`
			#Trim_Line=`echo "$TRIM_LINE" | sed 's/\]/~/g' | sed 's/\[/~/g' | sed 's/|/+/g'`
			Trim_Line=`echo "$TRIM_LINE" | sed 's/\]/~/g' | sed 's/\[/~/g'`
			Trim_Line1=`echo "$Trim_Line" |  sed 's/ /%/g' | sed 's/~~/~ ~/g' | sed 's/\//~/g'`       
			logDebug "Before processign Trim_Line1=$Trim_Line1"

			checkIfNextCharIsOR=False
			logDebug "Modified Section line : $Trim_Line"
	                GetInFlag=TRUE
        	        if [ `echo "$Trim_ParseArray" | grep -i "$Trim_Line" | cut -d' ' -f1` ]
                	then
                    	GetIn=$TRUE
                        continue
                    else
                    	OrigLine=`echo "$TRIM_LINE" | sed 's/ /%/g' | sed 's/\]\[/\] \[/g' | sed 's/|/ \[\] /g'`
						logDebug "**OrigLine=$OrigLine ** checkIfNextCharIsOR=$checkIfNextCharIsOR"
						LastSectionType=""
						istheConditionSuccessful="False"
						GotLogicalOR="False"
						FirstLoop="True"
                        for eachSection in $OrigLine
                        do 
							logDebug "Inside the for loop eachSection=$eachSection ** checkIfNextCharIsOR=$checkIfNextCharIsOR ** GetInFlag=$GetInFlag ** istheConditionSuccessful=$istheConditionSuccessful ** GotLogicalOR=$GotLogicalOR"

							if [ "$FirstLoop" = "False" ]; then
								if [ `echo "$eachSection" | awk '/\[\]/'` ]; then
									GotLogicalOR="True"
									continue
								else
									if [ "$GotLogicalOR" = "True" ]; then
										GotLogicalOR="False"
										if [ "$istheConditionSuccessful" = "True" ]; then
											logDebug "Skipping the condition eachSection=$eachSection"
											continue
										fi
									else
										if [ "$istheConditionSuccessful" = "False" ]; then
											break
										fi
									fi
								fi
							fi
						FirstLoop="False"
						if [ "$LastSectionType" ]; then
							if [ `echo "$eachSection" | awk '/\=/||/:/||/@/'` ]; then
								logDebug "eachSection=$eachSection"
							else
								eachSection=`echo "$LastSectionType:$eachSection"`
							fi
						fi
						if [ `echo "$eachSection" | awk '/:/'` ]; then
							LastSectionType=`echo "$eachSection" | cut -d":" -f1`
							logDebug "Last Section Type = $LastSectionType"
						fi
						logDebug "Proceed only if the checkIfNextCharIsOR is False checkIfNextCharIsOR=$checkIfNextCharIsOR"
						#if [ "$checkIfNextCharIsOR" = "True" ]; then
						#	break
						#fi

						eachSection=`echo "$eachSection" | sed 's/\]/~/g' | sed 's/\[/~/g' | sed 's/\//~/g'`
						logDebug "Is Logical OR found ? eachSection=$eachSection"
                          			eachSectionCheck=`echo "$eachSection" | grep "|"`
               		          		if [ $eachSectionCheck ]; then 
                                                	logDebug "Found '|' in section..."
                        	        		orList=`echo "$eachSection" | sed 's/!//g' | sed 's/|/~ ~/g'`
                                			orString="" 

                                        	        ####Getting the Type of Field Like (OSType,OSArch,CPUNAME,)####
                                                	Type=`echo "$eachSection" | cut -c 2- | cut -d ":" -f1`
						logDebug "Just Before the for loop orList=$orList"
                                			for eachor in $orList
                                			do 
								logDebug "Inside the for loop eachor=$eachor"
                                                        	####Differentiating Between EnvFields and Normal Fields####
								logDebug "$eachor list of $orList"
                                                        	IsEnv=`echo "$eachor" | cut -c 2`
                                                        	IsEqual=`echo "$eachor" | grep "="`
                                                        	if [ "$IsEnv" = "@" ]; then
									logDebug "Contains environment variable :$eachor"
                                                                	eachor=$eachor
                                                        	elif [ "$IsEqual" ] ; then
									logDebug "Contains Property variable : $eachor"
                                                                	eachor=$eachor
								else
									logDebug "Checking Whether Type of Field  Present or not (OSType,OSArch,CPUNAME,)"
                                                                	IsFound=`echo "$eachor" | grep "$Type"`
                                                                	if [ $IsFound ]; then
										logDebug "Found $eachor"
                                                                        	eachor=$eachor
                                                                	else
                                                                        	eachor=`echo "$eachor" | cut -c 2- | sed 's/^/~'$Type':/g'`
										logDebug "Found $eachor"
									fi
								fi
                                 				if [ `echo "$Trim_ParseArray" | grep -i "$eachor" | cut -d' ' -f1` ]; then
									logDebug "Yes, $Trim_ParseArray contains String : $eachor"
                                 					orString=$orString" True"
                                  				else
									logDebug "No, $Trim_ParseArray does not contain String : $eachor"
                                  					orString=$orString" False" 
                                 				fi
                                			done

		                              		orStringCheck=`echo "$orString" | grep "True"`
               			              		if [ "$orStringCheck" ]; then
								GetInFlag=TRUE	
								istheConditionSuccessful="True"
                               				else
                                				GetInFlag=FALSE
								istheConditionSuccessful="False"
                                                        	break
                               				fi                                 
 
                         			else
							#Make sure all the section variables are present
							# if not present then throw WARNING message
							logDebug "check the string $eachSection contains strings OSType|CPUArch|OSArch|CPUType"
							
							if [ `echo "$eachSection" | awk '/\=/||/:/||/@/'` ]; then
								logDebug "eachSection=$eachSection"
							else
								eachSection=`echo "$eachSection" | sed 's/^~/\[/' | sed 's/~$/\]/g'`
								echo " " >> $TMP_DIR/SectionWarningMsg.txt
								eachSection=`echo "$eachSection" | sed 's/%/ /g'`
								printmessage "$SECTION_MISSING_DELIMITER_WARN_STR" "[$ConfigFileName $ConfigFileversion]" "$eachSection" >> $TMP_DIR/SectionWarningMsg.txt
								echo " " >> $TMP_DIR/SectionWarningMsg.txt
								GetInFlag=FALSE
								break 
							fi
							if [ `echo "$eachSection" | awk '/@/||/\=/||/CPU/||/OSType/||/CPUArch/||/OSArch/||/CPUType/'` ]; then
								logDebug "eachSection=$eachSection"
                                                        else
								eachSection=`echo "$eachSection" | sed 's/^~/\[/' | sed 's/~$/\]/g'`
								logDebug "$Msg_INVALID_SECTION_CATEGORY_WARNSTR $eachSection"
								echo " " >> $TMP_DIR/SectionWarningMsg.txt
								eachSection=`echo "$eachSection" | sed 's/%/ /g'`
								printmessage "$SECTION_CATEGORY_WARN_STR" "[$ConfigFileName $ConfigFileversion]" "$eachSection" >> $TMP_DIR/SectionWarningMsg.txt
								echo " " >> $TMP_DIR/SectionWarningMsg.txt

								GetInFlag=FALSE
								break 
							fi
							notSectionCheck=`echo "$eachSection" | grep "!"`
							equalSectionCheck=`echo "$eachSection" | grep "="`
							envSectionCheck=`echo "$eachSection" | grep "@"`
							logDebug "Is section contains ! or = ?"
							if [ "$envSectionCheck" ]; then 
								logDebug "Yes contains @"
								logDebug "Trim_ParseArray=$Trim_ParseArray ** eachSection=$eachSection"
                                                                notSectionLine=`echo "$Trim_ParseArray" | grep -i  "$eachSection" | cut -d' ' -f1`
                                                                if [ $notSectionLine ]; then
                                                                        GetInFlag=TRUE
									istheConditionSuccessful="True"
                                                                else
                                                                        GetInFlag=FALSE
									checkIfNextCharIsOR="True"
									istheConditionSuccessful="False"
                                                                fi
								
							elif [ $equalSectionCheck ]; then 
								logDebug "Yes contains ="
								#Check if the Section has the !
                                                                eachSection=`echo "$eachSection" | sed 's/!//g'`
								logDebug "Trim_ParseArray=$Trim_ParseArray ** eachSection=$eachSection"
                                                                notSectionLine=`echo "$Trim_ParseArray" | grep -i  "$eachSection" | cut -d' ' -f1`
                                                                if [ $notSectionLine ]; then
                                                                        GetInFlag=TRUE
									istheConditionSuccessful="True"
                                                                else
                                                                        GetInFlag=FALSE
									checkIfNextCharIsOR="True"
									istheConditionSuccessful="False"
                                                                fi
							elif [ $notSectionCheck ]; then 
								logDebug "Yes contains !"
								#Check if the Section has the :
								eachSection=`echo "$eachSection" | sed 's/!//g'`
								logDebug "Trim_ParseArray=$Trim_ParseArray ** eachSection=$eachSection"
								notSectionLine=`echo "$Trim_ParseArray" | grep -vi  "$eachSection" | cut -d' ' -f1`
								if [ $notSectionLine ]; then
									GetInFlag=TRUE
									istheConditionSuccessful="True"
								else
									GetInFlag=FALSE
									checkIfNextCharIsOR="True"
									istheConditionSuccessful="False"
								fi
							#Section do not have ! 
							elif [ `echo "$Trim_ParseArray" | grep -i  "$eachSection" | cut -d' ' -f1` ]
								then
									logDebug "------1  Trim_ParseArray=$Trim_ParseArray ** eachSection=$eachSection"
									GetInFlag=TRUE
									istheConditionSuccessful="True"
								else
									logDebug "------2  Trim_ParseArray=$Trim_ParseArray ** eachSection=$eachSection"
									GetInFlag=FALSE
									checkIfNextCharIsOR="True"
									istheConditionSuccessful="False"
								fi
							fi
                          		done
                        	fi
                	fi
                	if [ "$GetInFlag" = "FALSE" ]; then
                		GetIn=$FALSE
                	else
                		FIRSTCHAR_LINE=`echo "$LINE" | cut -c 1`
                        	if [ "$FIRSTCHAR_LINE" = "[" ]; then
    					GetIn=$FALSE 
                        	else
                          		GetIn=$TRUE
                        	fi
                	fi
                	if [ $GetIn -eq $TRUE ]
                	then
                        	check=`echo "$version" | grep  "[0-9]"`
        
       			        if [ $check ]; then
                                	echo "$TRIM_LINE" >>$2_$version.cfg
                        	else
                                	version=`echo "$CONFIG_FILE" | sed 's/.*\/\(.*\)/\1/' | cut -d "_" -f2 | cut -d "." -f1`
                                	logDebug "Writing $TRIM_LINE to $2_$version.cfg"
                                	echo "$TRIM_LINE" >>$2_$version.cfg
                        	fi
                	fi
        	done
	fi
	version=`echo "$CONFIG_FILE" | sed 's/.*\/\(.*\)/\1/' | cut -d "_" -f2 | cut -d "." -f1`
	echo " " >> $2_$version.cfg 2> /dev/null
        logDebug "Exiting Read_configFile()"
}
#Function Name : Execute_Property()
#Input Arg     : Single Property Name
#Output        : This function executes the Single properties, returns PASS/FAIL 
#		 On failure, it returns the WARNING messages and execution continues.
Execute_Property() 
{
	logDebug "Entering function : Execute_Property"
	logDebug "Removing the temporary files : $TMP_DIR/EPsingleProp.result ,$PREREQ_HOME/UNIX_Linux/EPsingleProp.cfg, $PREREQ_HOME/UNIX_Linux/EPsingleProp.sh "
	rm -rf $TMP_DIR/EPsingleProp.result > /dev/null 2>&1
	rm -rf $PREREQ_HOME/UNIX_Linux/EPsingleProp.cfg > /dev/null 2>&1
	rm -rf $PREREQ_HOME/UNIX_Linux/EPsingleProp.sh > /dev/null 2>&1

	# Remove the starting and ending [] brackets 
	EPtrimline=`echo "$1" | sed 's/%/ /g' | sed -e 's/^\[//'  -e 's/\]$//'`
	EPvalue=`echo "$EPtrimline" | cut -d"=" -f 2-`
	EPkey=`echo "$EPtrimline" | cut -d"=" -f1`

	logDebug "EPKey=$EPkey***** Value=$EPvalue"

	if [ `echo "$EPkey" | sed 's/ //g' | awk '/OSVersion/||/Temp/||/Disk/||/Memory/||/risc.cpu/||/intel.cpu/||/numCPU/'` ]; then
                if [ -s $TMP_DIR/localhost_hw.txt ]; then
                        logDebug "File $TMP_DIR/localhost_hw.txt exists, hence not running common.sh file..."
                else
                        logDebug "File $TMP_DIR/localhost_hw.txt does not exist, Running common.sh file..."
                        chmod +x $PREREQ_HOME/UNIX_Linux/common.sh
                        logDebug "Calling common.sh script..."
                        eval "cd $PREREQ_HOME/UNIX_Linux/;$PREREQ_HOME/UNIX_Linux/common.sh "/opt/IBM/ITM""
                fi

		EPresult=`echo "$EPkey" | grep "OS Version"`
                if [ "$EPresult" ]; then
                        logDebug "Run the plugin scripts"
                        PackageName=""

                        chmod +x $PREREQ_HOME/lib/os_keypatch_plug.sh 2>/dev/null
                        chmod +x $PREREQ_HOME/lib/OS_Version_plug.sh 2>/dev/null
                        eval "cd $PREREQ_HOME/lib;$PREREQ_HOME/lib/os_keypatch_plug.sh "/opt/IBM/ITM" "$PackageName" >> $TMP_DIR/localhost_hw.txt  2>>/dev/null"
                        eval "cd $PREREQ_HOME/lib;$PREREQ_HOME/lib/OS_Version_plug.sh "/opt/IBM/ITM" "$PackageName" >> $TMP_DIR/localhost_hw.txt  2>>/dev/null"

                        EPrealVal=`cat $TMP_DIR/localhost_hw.txt | sort | uniq | grep "$EPkey" | cut -d"=" -f2`
                        logDebug "Comparing realValue=$EPrealVal and expected Value=$EPvalue"
                        chmod +x $PREREQ_HOME/UNIX_Linux/OS_Version_compare.sh
                        EPresult=`$PREREQ_HOME/UNIX_Linux/OS_Version_compare.sh "$EPrealVal" "$EPvalue" "$PackageName"`

			EPPropresult=`echo "$EPresult" | grep "$PASS_STR"`
			if [ "$EPPropresult" ]; then
				logDebug "Result of the Property $1 = $PASS_STR"
				echo "$PASS_STR"
			else
				logDebug "Result of the Property $1 = $FAIL_STR"
				echo "$FAIL_STR"
			fi
                        return
                else
                        EPrealVal=`cat $TMP_DIR/localhost_hw.txt | sort | uniq | grep "$EPkey" | cut -d"=" -f2`
                        logDebug "Comparing realValue=$EPrealVal and expected Value=$EPvalue"
                        EPreturnVal=`compare "$EPrealVal" "$EPvalue"`
                        echo "$EPreturnVal"
                        logDebug "Return value from the common function = $EPreturnVal"
                        return
                fi
        fi

	# Create the single property file
	logDebug "Line in the Single property file = $EPtrimline"
	echo "$EPtrimline" > $PREREQ_HOME/UNIX_Linux/EPsingleProp.cfg
	chmod +x $PREREQ_HOME/UNIX_Linux/packageTest.sh
	logDebug "Executing packageTest.sh with arguments $PREREQ_HOME/UNIX_Linux/ EPsingleProp.cfg "
	$PREREQ_HOME/UNIX_Linux/packageTest.sh $PREREQ_HOME/UNIX_Linux/ EPsingleProp.cfg 1>/dev/null
	chmod +x $PREREQ_HOME/UNIX_Linux/EPsingleProp.sh

	# Check the file has the more than 6 entries, if not then the property check is failed.
	EPcount=`cat $PREREQ_HOME/UNIX_Linux/EPsingleProp.sh | wc -l`
	if [ $EPcount -lt 5 ]; then
		logDebug "Invalid Property : $1"
		echo " " >> $TMP_DIR/SectionWarningMsg.txt
		EPWarningMsg=`echo $1 | sed 's/%/ /g'`
		printmessage "$SECTION_PROPERTY_WARN_STR" "[$ConfigFileName $ConfigFileversion]" "$EPWarningMsg"  >> $TMP_DIR/SectionWarningMsg.txt
		echo " " >> $TMP_DIR/SectionWarningMsg.txt
		echo "NULL"
		return
	fi

	logInfo "Found valid Property : $1"
	eval "cd $PREREQ_HOME/UNIX_Linux/;$PREREQ_HOME/UNIX_Linux/EPsingleProp.sh $PREREQ_HOME/UNIX_Linux/packageTest.sh "/opt/IBM/ITM" >> $TMP_DIR/EPsingleProp.result 2>>/dev/null"


	rstvalue=`cat $TMP_DIR/EPsingleProp.result | cut -d= -f2`
	logDebug "Return value from the Property = $rstvalue"
	CFGHOME=$PREREQ_HOME/UNIX_Linux/
	if [ -n "$rstvalue" ]; then
	# compare, it's the compare between $value and $rstvalue
	# $value is from configuration file
	# $rstvalue is from result file
	# if there exists user defined comparison file, use it
	# else use the compare function
		item=`cat $PREREQ_HOME/UNIX_Linux/EPsingleProp.cfg | cut -d"=" -f1`
		riditem=`echo "$item" | sed "s/ /_/g"`

		comparefile=`ls "$CFGHOME"/*$riditem*_compare* 2>/dev/null | sed "s;${CFGHOME};\.;" | sed 's/^..//' | sort -ir | sed -n "1p"`
		logDebug "compare file name $comparefile"
		if [ -z "$comparefile" ]; then
			comparefile=`ls "$CFGHOME"/$riditem*_compare* 2>/dev/null  | sed "s;${CFGHOME};\.;" | sed 's/^..//' | sort -ir | sed -n "1p"`
			logDebug "compare file name $comparefile"
			GetEnvVar=`echo "$riditem" | grep "env.var.set"`
			logDebug "GetEnvVar=$GetEnvVar"
			if [ $GetEnvVar ]; then
				comparefile=`ls "$CFGHOME"/env.var.set_compare* 2>/dev/null  | sed "s;${CFGHOME};\.;" | sed 's/^..//' | sort -ir | sed -n "1p"`
			fi
			GetEnvVar=`echo "$riditem" | grep "env.JRE.version"`
			logDebug "look for env.JRE.version_compare GetEnvVar=$GetEnvVar"
			if [ $GetEnvVar ]; then
				comparefile=`ls "$CFGHOME"/env.JRE.version_compare* 2>/dev/null  | sed "s;${CFGHOME};\.;" | sed 's/^..//' | sort -ir | sed -n "1p"`
			fi
		fi

		if [ -n "$comparefile" ]; then
			logDebug "[$comparefile] used as comparison for [$item]"
			eval "cd $CFGHOME;chmod +x \"$comparefile\";"

			PackageName=""
			ISPackageFound=`echo "$item" | grep "os.package"`
			if [ "$ISPackageFound" != "" ]; then
			    PackageName=`echo "$item" | cut -d'.' -f3-`
			 fi

			EPresult=`$PREREQ_HOME/UNIX_Linux/$comparefile "$rstvalue" "$EPvalue" "$PackageName"`
			logDebug "Result of the Property $1 = $EPresult"
			echo "$EPresult"
		else
			 if [ "$rstvalue" = "NFS_NOT_AVAILABLE" -o "$rstvalue" = "NOT_A_VALID_PATH" -o "$rstvalue" = "Not Found" ]; then
                                 r="$FAIL_STR"
			else
				logDebug "compare used as comparison for [$rstvalue] of [$EPvalue]"
				EPr=`compare "$rstvalue" "$EPvalue"`
				logDebug "Return value from the compare function = $EPr "
			fi
			EPPropresult=`echo "$EPr" | grep "$PASS_STR"`
			if [ "$EPPropresult" = "$PASS_STR" ]; then
				logDebug "Result of the Property $1 = $PASS_STR"
				echo "$PASS_STR"
			else
				logDebug "Result of the Property $1 = $FAIL_STR"
				echo "$FAIL_STR"
			fi
                        return

		fi
	fi
} 
logDebug "Forming parse array..."
Form_Parse_String "$1" $2 $3 $4 $6 $7
logDebug "Reading config file and parsing using parse array..."
Read_conigFile $CONFIG $2 $version
cp $2_*.cfg ../UNIX_Linux/ 2>/dev/null
#cat $2_$version.cfg  | sed '/^$/d' > ../UNIX_Linux/$2_$version.cfg
rm -f $2_*.cfg 2>/dev/null
logDebug "Exiting config_parser.sh"
