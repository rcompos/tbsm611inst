#!/bin/sh

# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
#set -n

# step 1: judge the release version
# here we handle Linux, Unix, Solaris, AIX

case `uname` in
	Linux) 
		if [ -r /etc/SuSE-release ] ; then
			release=`ls /etc/SuSE-release 2>/dev/null`
		elif [ -r /etc/redhat-release ] ; then
			release=`ls /etc/redhat-release 2>/dev/null`
		fi

        if [ ! "$release" = "" ]; then
                for rr in $release
                do
                        #getconf is unreliable so continue to use arch
                        Architecture=`arch`
                        case $Architecture in
                                i*86|s390|ppc)
                                        check_arch="32-bit";;
                                ia64|x86_64|ppc64|s390x)
                                        check_arch="64-bit";;
                                *) # Look for CONFIG_64bit=y in /boot/config-`uname -r`
                                        BootConfig=/boot/config-`uname -r`
                                if [ -f $BootConfig ]
                                then
                                        grep ". *CONFIG_64BIT=y" $BootConfig >/dev/null 2>&1
                                        if [ $? -eq 0 ]
                                        then
                                                check_arch="64-bit"
                                        else
                                                check_arch="32-bit"
                                        fi
                                else
                                        #No /boot/config... so fallback to getconf.  Best we can
                                        check_arch=`getconf LONG_BIT`"-bit"

                                fi
                        esac
						# getconf isn't safe to use since it returns the bit mode that it, itself, is compile with.
                        # On at least SLES 10.1 ppc64 it's compiled as 32 bit
                        OS=`cat $rr | sed -n '1p' | sed 's/^[ ]*//g' | cut -d '(' -f1`
                        echo "OS Version="$OS"("$check_arch")"
                        echo "Kernel"=$Architecture
                        exit
                done
        fi

        issue=`ls /etc/*issue 2>/dev/null`
        if [ ! "$issue" = "" ]; then
                for rr in $issue
                do
                        echo "OS Version="`cat $rr | sed -n '1p' | sed 's/^[ ]*//g'`
                        exit
                done
        fi
        ;;
                        
	HP-UX) 
# Added for Bug 141762
#		echo "OS Version="`cat /etc/issue 2>/dev/null | sed 's/.*\[\(.*\)\].*/\1/g'`" ("`getconf KERNEL_BITS`" bit)"	
 #       echo "OS Version="`uname` `uname -r`" ("`getconf KERNEL_BITS`"-bit)"
    check=`uname -r`
            if [ "$check" = "B.11.0" ]; then
                ver="11.0"
            fi
             if [ "$check" = "B.11.11" ]; then
                ver="11iv1"
            fi

             if [ "$check" = "B.11.23" ]; then
                ver="11iv2"
            fi

            if [ "$check" = "B.11.31" ]; then
                ver="11iv3"
            fi
             echo "OS Version="`uname`" "$ver
             echo "Kernel"=`model |awk '{print $1}'`
	;;
	AIX)
		echo "OS Version="`uname`" "V`oslevel`" ("`getconf KERNEL_BITMODE 2>/dev/null`"-bit)"
		echo "Kernel"=`lsattr -E -l proc0 | grep "Processor type" | awk '{print $2}' | cut -d '_' -f2`
	;;
        SunOS)
                release=`ls /etc/*release 2>/dev/null`
                if [ ! "$release" = "" ]; then
                        for rr in $release
                        do
                                OS_version=`cat $rr | sed -n '1p' | sed 's/^[ ]*//g' | awk '{print $1,"V"$2,"("$5")";}'`
                                echo "OS Version=$OS_version ("`isainfo -b 2>/dev/null`"-bit)"
                                echo "Kernel"=`isainfo -k`
                                exit
                        done
                fi

        ;;

        *) echo "can not handle"
esac
