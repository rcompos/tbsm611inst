#!/bin/sh
#
# Licensed Materials - Property of IBM
# "Restricted Materials of IBM"
# 5725-F56 (c) Copyright IBM 2014
# IBM Tivoli Netcool Configuration Manager
#

if [ "`uname`" = "SunOS" ]; then
        PRS_HOME=`echo $0`
        PREREQ_HOME=`dirname $PRS_HOME`
        if [ "$PREREQ_HOME" = "." ]; then
                PREREQ_HOME=`pwd`
        else
                cd $PREREQ_HOME
                PREREQ_HOME=`pwd`
        fi
else
        PRS_HOME=`dirname $0`
        cd $PRS_HOME
        PREREQ_HOME=$PWD
        cd - > /dev/null 2>&1
fi

if [ `uname -s` = "Linux" ]; then
	ECHO="echo -e"
else
	ECHO="echo"
fi

available=`(cd ${PREREQ_HOME}/UNIX_Linux;ls -1 NCM_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].cfg | cut -f2 -d'_' | cut -f1 -d'.')`
latest=`echo "${available}" | sort -n | tail -1`
available=`echo "${available}" | tr '\n' ',' | sed -e 's?,$??'`

if [ $# -gt 1 ]; then
	$ECHO "Usage: $0 [NCMrelease]"
	$ECHO "Valid NCMrelease values for this version of the prerequisite scanner tool are \"${available}\""
	$ECHO "If no NCMrelease is supplied \"${latest}\" is used"
	exit
fi

if [ $# -eq 1 ]; then
	release="$1"
else
	release="${latest}"
fi

if [ ! -f ${PREREQ_HOME}/UNIX_Linux/NCM_${release}.cfg ]; then
	$ECHO "Error: Unsupported NCMrelease selected \"${release}\""
	$ECHO "Usage: $0 NCMrelease"
	$ECHO "NCMrelease is specified by an 8-digit string in the format \"VVRRMMFF\""
	$ECHO "where each Version(V), Release(R), Modification(M) and Fixpack(F) value contains a leading zero where necessary"
	$ECHO "Valid NCMrelease values for this version of the prerequisite scanner tool are \"${available}\""
	$ECHO "If no NCMrelease is supplied \"${latest}\" is used"
	exit
fi

IATEMPDIR_SET="False"
if [ -n "$IATEMPDIR" ]
then
	IATEMPDIR_SET="True"
fi

TNCM_COMPLIANCE_CORE="False"
TNCM_COMPLIANCE_EVALUATION="False"
TNCM_WORKER_SERVER="False"
TNCM_PRESENTATION_SERVER="False"
TNCM_REPORTING="False"

selection="unset"

while [ "${selection}" = "unset" ]
do
	${ECHO} "
	Prerequisite scanner for ITNCM ${release} release.

	Please select your desired deployment for this server:-
	
	1. Presentation Server + Worker Server : Compliance Core=Enabled : Reporting = Not to be installed
	2. Presentation Server + Worker Server : Compliance Core=Enabled : Reporting = To be installed
	3. Presentation Server + Worker Server : Compliance Core=Disabled : Reporting = Not to be installed
	4. Presentation Server + Worker Server : Compliance Core=Disabled : Reporting = To be installed
	
	5. Worker Server : Base=Enabled  : Compliance Eval Engine=Enabled
	6. Worker Server : Base=Enabled  : Compliance Eval Engine=Disabled
	7. Worker Server : Base=Disabled : Compliance Eval Engine=Enabled

	0. Quit
	
	Select option -> \c"
	
	read selection
	
	case $selection in
		1) config="Presentation Server + Worker Server : Compliance Core=Enabled : Reporting = Not to be installed"
		   TNCM_PRESENTATION_SERVER="True"; TNCM_WORKER_SERVER="True"; TNCM_COMPLIANCE_CORE="True"; TNCM_COMPLIANCE_EVALUATION="False"; TNCM_REPORTING="False";;
		2) config="Presentation Server + Worker Server : Compliance Core=Enabled : Reporting = To be installed"
		   TNCM_PRESENTATION_SERVER="True"; TNCM_WORKER_SERVER="True"; TNCM_COMPLIANCE_CORE="True"; TNCM_COMPLIANCE_EVALUATION="False"; TNCM_REPORTING="True";;
		3) config="Presentation Server + Worker Server : Compliance Core=Disabled : Reporting = Not to be installed"
		   TNCM_PRESENTATION_SERVER="True"; TNCM_WORKER_SERVER="True"; TNCM_COMPLIANCE_CORE="False"; TNCM_COMPLIANCE_EVALUATION="False"; TNCM_REPORTING="False";;
		4) config="Presentation Server + Worker Server : Compliance Core=Disabled : Reporting = To be installed"
		   TNCM_PRESENTATION_SERVER="True"; TNCM_WORKER_SERVER="True"; TNCM_COMPLIANCE_CORE="False"; TNCM_COMPLIANCE_EVALUATION="False"; TNCM_REPORTING="True";;
		5) config="Worker Server : Base=Enabled  : Compliance Eval Engine=Enabled"
		   TNCM_PRESENTATION_SERVER="False"; TNCM_WORKER_SERVER="True"; TNCM_COMPLIANCE_CORE="False"; TNCM_COMPLIANCE_EVALUATION="True"; TNCM_REPORTING="False";;
		6) config="Worker Server : Base=Enabled  : Compliance Eval Engine=Disabled"
		   TNCM_PRESENTATION_SERVER="False"; TNCM_WORKER_SERVER="True"; TNCM_COMPLIANCE_CORE="False"; TNCM_COMPLIANCE_EVALUATION="False"; TNCM_REPORTING="False";;
		7) config="Worker Server : Base=Disabled : Compliance Eval Engine=Enabled"
		   TNCM_PRESENTATION_SERVER="False"; TNCM_WORKER_SERVER="False"; TNCM_COMPLIANCE_CORE="False"; TNCM_COMPLIANCE_EVALUATION="True"; TNCM_REPORTING="False";;
		0) ${ECHO} "Quit selected"; exit;;
		*) ${ECHO} "Error: Unrecognised selection requested - \"${selection}\" - Please select a valid selection from the list of options or 0 to quit"; selection="unset";;
	esac
done

${ECHO} ""
${ECHO} "\tExecuting prerequisite scanner for \"NCM ${release}\" with configuration: \"${config}\"\n"
${ECHO} ""

export IATEMPDIR_SET TNCM_PRESENTATION_SERVER TNCM_WORKER_SERVER TNCM_COMPLIANCE_CORE TNCM_COMPLIANCE_EVALUATION TNCM_REPORTING

$PREREQ_HOME/prereq_checker.sh "NCM ${release}" detail outputDir=/tmp/prs

unset IATEMPDIR_SET TNCM_PRESENTATION_SERVER TNCM_WORKER_SERVER TNCM_COMPLIANCE_CORE TNCM_COMPLIANCE_EVALUATION TNCM_REPORTING

exit 0
