#!/bin/sh
############### Begin Standard Header - Do not add comments here ###############
# 
# Licensed Materials - Property of IBM
# 
# Restricted Materials of IBM
# 
# 5724-N55
# 
# (C) COPYRIGHT IBM CORP. 2013.  All Rights Reserved.
# 
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# 
############################# End Standard Header ##############################

# get PRS_HOME directory

if [ "`uname`" = "SunOS" ];then
        SCRIPT_HOME=`echo $0`
        SCRIPT_HOME_FP=`dirname $PRS_HOME`
        if [ "$SCRIPT_HOME_FP" = "." ]; then
                SCRIPT_HOME_FP=`echo $PWD`
                PREREQ_HOME=$SCRIPT_HOME_FP/..
        else
                cd $SCRIPT_HOME_FP
                PREREQ_HOME=$SCRIPT_HOME_FP/..
                PREREQ_HOME=`pwd`
        fi
else
        SCRIPT_HOME_FP=`dirname $0`
        cd $SCRIPT_HOME_FP/..
        PREREQ_HOME=$PWD
        cd - > /dev/null 2>&1
fi

"$PREREQ_HOME/prereq_checker.sh" TS1 detail outputDir="/tmp/taddm/prs"
