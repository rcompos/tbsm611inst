#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

. ../lib/common_function.sh

#appends or trims mantissa length to 2, 123MB -> 123.00MB, 123.123MB -> 123.12MB
#tested on Linux|AIX|HPUX
formatSizeDisplay() {
	echo "DEBUG: formatSizeDisplay: before="$1 >>${DEBUG_FILE}
	valueLength=`echo $1| wc -m`
    splitId=`expr $valueLength - 3`
    valuePart=`echo $1 | cut -c1-$splitId`
    unitId=`expr $splitId + 1`
    unitPart=`echo $1 | cut -c${unitId}-`
	
    echo $valuePart | grep \\. > /dev/null
    if [ $? = 0 ]; then
        mantissaTmp=`echo $valuePart | cut -d"." -f2 | wc -m`
        mantissaLength=`expr $mantissaTmp - 1`
        if [ $mantissaLength -eq 0 ]; then
            echo "${valuePart}00${unitPart}"
        elif [ $mantissaLength -eq 1 ]; then
            echo "${valuePart}0${unitPart}"
        elif [ $mantissaLength -eq 2 ]; then
            echo "$1"
        else
        	correctPosition=`expr $splitId - $mantissaLength + 2`
            echo "`echo $valuePart | cut -c-$correctPosition`${unitPart}"
        fi
    else
            echo "${valuePart}.00${unitPart}"
    fi
}

#given the directory parameter returns self, if directory exists, 
#or the closest existing parent directory in tree hierarchy
getClosestExistingParentDir() {
	awkcmd='awk'
	
	#Solaris awk does not support system() function, so use nawk instead
	case `uname` in
		SunOS)
			awkcmd='nawk'
		;;
	esac
	
	echo $1 | $awkcmd -F"/" '{
		#build full path parameter
		for (i=2; i<=NF; i++) path = path"/"$i;
		
		subpath = path
		#for each parent directory
		for (i=NF; i>1; i--) {
			#if directory exists return it
			if (! system("test -d "subpath)) { print subpath; exit }
			#else move to the grandparent  
			else subpath = substr(subpath, 1, length(subpath)-length($i)-1)
		}
		print "/" #where no parent exists return root
	}'
}


#print the available disk space for a given directory
printDirSize() {
	
	KEY=$1
	DIRPATH=$2
	echo "DEBUG: printDirSize: key=$KEY path=$DIRPATH" >>${DEBUG_FILE}
	nfs_check_status=`NFScheck $DIRPATH`
	if [ "$nfs_check_status" = "TRUE" ]; then
		dirToCheck=`getClosestExistingParentDir $DIRPATH`
		case `uname` in
	        Linux)			
				dsize=`df -h "$dirToCheck" | awk '{ if(NF<7 && NF>1){ print $(NF-2)"B" } }'`
				;;
			SunOS)
				dsize=`df -k "$dirToCheck" | awk '{ if(NF<7 && NF>1){ print $(4)/1024"MB" } }'`
				;;
	        AIX)
				dsize=`df -m "$dirToCheck" | awk '{ if(NF<8 && NF>1){ print $(NF-4)"MB" } }'`
	    		;;
	        HP-UX)
				dsize=`df -k "$dirToCheck" | grep -i "free" | awk '{ print $(1)/1024"MB" }'`
	        	;;
		esac
		echo "$KEY=`formatSizeDisplay $dsize`"
	else
		echo "$KEY=NFS_NOT_AVAILABLE"
	fi
}

DEBUG_FILE="TWAplugin_debug.log"

if [ -f ${DEBUG_FILE} ]; then
	rm -f ${DEBUG_FILE}
fi

CFG=$1
PRODUCT=`echo $CFG | cut -d_ -f1`

#set Disk path
path1=$2

SYSTEM=`uname`
SYSTEMID=`getSystemId`

echo "DEBUG: input 1: $1" >>${DEBUG_FILE}
echo "DEBUG: input 2: $2" >>${DEBUG_FILE}
echo "DEBUG: input 3: $3" >>${DEBUG_FILE}

#create dynamically keys
for INPUT in `echo $3 | tr "," "\n"`; do
	echo "DEBUG: INPUT $INPUT" >>${DEBUG_FILE}
	keyValue=`echo $INPUT | awk -F"=" '{print $1}'`
	echo "DEBUG: keyValue $keyValue" >>${DEBUG_FILE}
	pathValue=`echo $INPUT | awk -F"=" '{print $2}'`
	echo "DEBUG: pathValue $pathValue" >>${DEBUG_FILE}
	printDirSize $keyValue $pathValue
done
