# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
#set -n



# RTC Defect 20889
#       Find the working directory for all the supported platforms
#       Working directory "PREREQ_HOME" is available throughout the execution of PRS

if [ "`uname`" = "SunOS" ];then
        PRS_HOME=`echo $0`
        PREREQ_HOME=`dirname $PRS_HOME`
        if [ "$PREREQ_HOME" = "." ]; then
                PREREQ_HOME=`pwd`
        else
                        tmpcwd=`pwd`
                cd $PREREQ_HOME
                PREREQ_HOME=`pwd`
                cd $tmpcwd > /dev/null 2>&1
        fi
else
        PRS_HOME=`dirname $0`
        cd $PRS_HOME
        PREREQ_HOME=$PWD
        cd - > /dev/null 2>&1
fi

export PREREQ_HOME
PREREQ_LOGDIR="$PREREQ_HOME"
export PREREQ_LOGDIR
PASS_STR=PASS
export PASS_STR
WARN_STR=WARN
export WARN_STR
WARNING_STR=WARNING
export WARNING_STR
FAIL_STR=FAIL
export FAIL_STR
 
. "$PREREQ_HOME"/lib/common_function.sh


# Create the temporary files with time and date extension
DatenTime=`date +%Y%m%d_%H%M%S`
tempDir="prs_$DatenTime"
mkdir -p /tmp/$tempDir/nls > /dev/null 2>&1
if [  ! -d /tmp/$tempDir/nls ]; then
        echo ""
	echo "Cannot create temporary directory: /tmp/$tempDir/nls  Permission Denied, Exiting..."
        exit 2
fi

#Check the temporary nls directory has minimum 2MB of space
type=`uname`

if [ "$type" = "Linux" ]; then
	res=` df -k /$PRS_BASE_DIR | tail -n 1`
	len=`echo $res | wc -w`
	len1=`expr $len - 2`
	avail=`echo $res | cut -d ' ' -f$len1`
fi
if [ "$type" = "SunOS" ]; then
	avail=`df -k /$PRS_BASE_DIR | awk '{ if(NF<7 && NF>1){ print $(4) } }'`
fi
if [ "$type" = "AIX" ]; then
	avail=`df -k /$PRS_BASE_DIR | sed -n 2p | awk '{print $3}'`
fi
if [ "$type" = "HP-UX" ]; then
	avail=`df -k /$PRS_BASE_DIR | sed -n 2p | awk '{print $1}'`
fi
tmpSize=`expr $avail / 1024`
#Return Error message if temporary nls directory has less than 2MB of space
if [ $tmpSize -le 2 ]; then
	echo ""
	echo "Prerequisite Scanner has detected insufficient disk space in the /tmp/$tempDir/nls directory: The minimum disk space required to run the tool is 2MB"
	echo ""
	exit 2
fi

#Construct the nls file in required format to export
#by default LangProperty_File = "$PREREQ_HOME/nls/messages_en-US.properties"
DefaultLang=`echo "$LANG" | cut -d "." -f1 | sed 's/_/-/g'`
if [ "$DefaultLang" = "" ]; then
        LangProperty_File="$PREREQ_HOME/nls/messages.properties"
else
        #Check if the lang file exists in nls directory
        LangProperty_File=`ls -1 $PREREQ_HOME/nls/messages_* 2> /dev/null | grep -i "_${DefaultLang}\." | tail -1`
        if [ -s "$LangProperty_File" ]; then
                LangProperty_File="$LangProperty_File"
        else
                LangProperty_File="$PREREQ_HOME/nls/messages_en-US.properties"
        fi
fi

while read line
do
	#Ignore the commented lines
	ignoreLine=`echo "$line" | cut -c 1`
	if [ "$ignoreLine" = "#" ]
	then
		continue
	fi
	if [ -z "$line" ]
	then
		continue
	fi

	strMessageID=`echo "$line" | grep "_STR"`
        if [ "$strMessageID" = "" ]; then
                continue
        else
                MessageID=`echo "$line" | cut -d"=" -f1`
                MessageStr=`echo "$line" | cut -d"=" -f2`

                MessageUID=`echo "$MessageID" | sed 's/_STR/_UID/g'`
                UIDstrinFile=`grep -w "${MessageUID}" ${LangProperty_File} | grep -v "^#" | tail -1 | cut -d"=" -f2`
		if [ "$UIDstrinFile" = "" ]; then
			echo "$MessageID=\"$MessageStr\"; export $MessageID" >> /tmp/$tempDir/nls/messages.properties 2>/dev/null
		else
			echo "$MessageID=\"$UIDstrinFile: $MessageStr\"; export $MessageID" >> /tmp/$tempDir/nls/messages.properties 2>/dev/null
		fi
        fi

done < "$LangProperty_File" 2>/dev/null

if [ -z "/tmp/$tempDir/nls/messages.properties" ] ;then
	echo "Cannot create temporary file: /tmp/$tempDir/nls/messages.properties  Permission Denied, Exiting..."
	exit 2
fi

#Provide the execution persmission to messages.properties file
chmod +x /tmp/$tempDir/nls/messages.properties 2>/dev/null
. /tmp/$tempDir/nls/messages.properties

#Once the messages are exported successfully, remove the temporary nls directory
if [ -d "/tmp/$tempDir" ]; then
	rm -rf /tmp/$tempDir 2>/dev/null
fi


# Check the existence of the Bourne shell

if [ ! -x /bin/sh ]; then
        echo ""
        echo "$BOURNE_SHELL_NOT_FOUND_STR"
        echo ""
        exit 2
fi

#!/bin/sh

# Get the some of the directories in the PATH
PATH=/usr/sbin:/usr/bin:/bin:/usr/local/bin:/sbin/:/usr/ucb:$PATH; export PATH


# Define the XML results flags
XML_Header=1
PRS_Info=2
Machine_Info=3
Scenario_Info=4
User_Info=5
Product_Info=6
Detailed_Result=7
Overall_Result=8
SinglePropWarn=9
XML_Flag=$XML_Header
outputDirFlag="False"
HealthChkFlag="False"
HealthFlag=""
TmpHealthFlag="False"
DetailFlag="False"
ShortArgFlag="False"
True=0
False=1
TotalComp=$True
LoopCount=0
PREREQ_BUILD="20140505"
PRS_Version="1.2.0.11"
Msg_DENOTAVAILABLE='DENotAvailable';export Msg_DENOTAVAILABLE
Indent='    '
PRS_Str="IBM Prerequisite Scanner"
Result_XML_File="result.xml"
Result_TXT_File="result.txt"
Scn_Log_File="precheck.log"
NO_CMD_LINE_ARGS=0
TmpPropertyFlag="False"
PropertyFile="Property.cfg"
tmpPropertyFile="tmpProperty.cfg"
WarningMsgFile="WarningMsgFile.txt"
DebuggerFalg="False"
_DEBUG="off"
PRS_Size_WithoutDEBUG=5
PRS_Size_WithDEBUG=6
Str_ConfigHomeDir=""
ConfigHomeDir="false"
PRSVersionFalg="False"
PRSVersionFile="$PREREQ_HOME/properties/version/PRS.fxtag"

os_name=`uname`
if [ "`uname`" = "SunOS" ];then
        HostID=`hostid`
fi

PREREQ_TRACE="True"
export PREREQ_TRACE
PREREQ_DEBUG="True"
export PREREQ_DEBUG
####################################################
#	Loging function it puts data in to log file

#	Calls New Log functions with the type of log info and the message

wrll(){
        logInfo "INFO" "$1"
}

#	Calls wrl() with type of log warning and message
wrlw(){
        logWarning "WARNING" "$1"
}

#	Cleans tmp directory
clean_temp(){
	logDebug "Entering function clean_temp()"
	logDebug "removing Directories $TMP_DIR/$tft ** $TMP_DIR/$tfi ** $TMP_DIR/$tfe "
	rm -f $TMP_DIR/$tft $TMP_DIR/$tfi $TMP_DIR/$tfe
	logDebug "Exiting from function clean_temp()"
}
clean_temp_Directory() {
	# RTC Defect 20889
	#       Moving "results.txt", "precheck.log" and prs.trc files to "outputDir" dir
	#       "outputDir" dir is deleted if Prereqchecker is running in non-debug mode
	#       Dir "outputDir" is not deleted if running in debug mode
	logDebug "Entering function clean_temp_Directory()"
	outputdir=`dirname $TMP_DIR`
	logDebug "outputdir=$outputdir"

	if [ "$DebuggerFalg" = "True" ]; then
		logDebug "Switching off the Debugger mode"
		set +x
		exec 1>&3 2>&4
		mv $TMP_DIR/$pdbgger $outputdir/ > /dev/null 2>&1
		echo ""
		echo "Debug information is available in the file : $outputdir/$pdbgger"
		logInfo "Debug information is available in the file : $outputdir/$pdbgger"
	fi
	if [ "$debugFlag" = "True" ]; then
			mv $TMP_DIR/$Result_TXT_File $Default_outputDir/ > /dev/null 2>&1
			mv $TMP_DIR/$Result_XML_File $Default_outputDir/ > /dev/null 2>&1
			mv $TMP_DIR/$Scn_Log_File $Default_outputDir/ > /dev/null 2>&1
			mv $TMP_DIR/prs.debug $Default_outputDir/ > /dev/null 2>&1
			mv $TMP_DIR $Default_outputDir/ > /dev/null 2>&1
	else
			mv $TMP_DIR/$Result_TXT_File $Default_outputDir/ > /dev/null 2>&1
			mv $TMP_DIR/$Result_XML_File $Default_outputDir/ > /dev/null 2>&1
			mv $TMP_DIR/$Scn_Log_File $Default_outputDir/ > /dev/null 2>&1
			rm -rf $TMP_DIR > /dev/null 2>&1
	fi
	if [ "$xmlResult" = "True" ]; then
		mv $PREREQ_HOME/PRSResults.xsd $outputdir/ > /dev/null 2>&1
	fi

	echo ""
	echo "$DETAIL_STR ${Default_outputDir}${Result_TXT_File}"
	cd $Default_outputDir
	#logDebug "Removing Dir $PREREQ_HOME"
	rm -rf $PREREQ_HOME > /dev/null 2>&1
	#logDebug "Exiting function clean_temp_Directory()"
}
#	Description : Detects OS 
#	input : it takes 3 parameters , 1 : product info 2: OS info 3 : CPU architecture
#	output : product code (TPM)and version (07200000)
AutoOsDetection(){

 	product_version=$1           
	logDebug " product_version = $product_version"
        
	logDebug "entering function AutoOsDetection()" 
	logDebug "Function parameters 1=$1 ** 2=$2 ** 3=$3"
        cd $PREREQ_HOME/lib
	logDebug "Entering dir $PREREQ_HOME/lib"
	
	#####Executing the Script for detecting the OS#####
	logInfo "Executing the Script for detecting the OS"
	Os_detected="$2"
	logDebug "Os_detected=$2"
        product=`echo $product_version | cut -d '+' -f1`
	logDebug "product=$product"

	####Checking if the Version is specified with the Product or not ####
        NoofCodes=`echo $product_version | sed 's/+/ /g' | wc -w`
	logDebug "NoofCodes=$NoofCodes"
        if [ $NoofCodes -gt 1 ]; then

                version=`echo $product_version | cut -d '+' -f2`
		logDebug "version=$version"
        else
                version=""
		logDebug "version=$version"
        fi
	####Ending the Validation#####
	prod_check=""
	if [ "$HealthChkFlag" = "True" ]; then
                numProdname=`ls "$PREREQ_HOME"/codename.cfg | wc -l`
		logDebug "numProdname=$numProdname"
        else
                numProdname=`ls "$PREREQ_HOME"/*codename.cfg | wc -l`
		logDebug "numProdname=$numProdname"
        fi
	if [ $numProdname -eq 1 ]; then
	logInfo "Finding product code in product.cfg"
	if [ "$HealthChkFlag" = "True" ]; then
                prod_check=`grep $product "$PREREQ_HOME"/codename.cfg | grep " for "  | cut -d'=' -f1`
		logDebug "prod_check=$prod_check"
        else
                prod_check=`grep $product "$PREREQ_HOME"/codename.cfg | grep " for "  | cut -d'=' -f1`
		logDebug "prod_check=$prod_check"
        fi
	logInfo "product code found : $prod_check"
        fi
         if [ $numProdname -gt 1 ]; then
		logInfo "Finding product code in multiple product.cfg"
		logDebug "numProdname=$numProdname"
	if [ "$HealthChkFlag" = "True" ]; then
                 code_check=`grep $product "$PREREQ_HOME"/codename.cfg | cut -d ':' -f2 | cut -d '=' -f1 | sed -n 1p`
			logDebug "code_check=$code_check"
        else
                 code_check=`grep $product "$PREREQ_HOME"/*codename.cfg | cut -d ':' -f2 | cut -d '=' -f1 | sed -n 1p`
			logDebug "code_check=$code_check"
        fi
		logInfo "product code found : $code_check"
         fi


		logInfo "Found $product code in product.cfg"
		if [ "$code_check" = "" ]; then
			if [ "$HealthChkFlag" = "True" ]; then
                                code_check=`grep "^$product" "$PREREQ_HOME"/codename.cfg | cut -d'=' -f1`
				logDebug "code_check=$code_check"
                        else
                                code_check=`grep "^$product" "$PREREQ_HOME"/*codename.cfg | cut -d'=' -f1`
				logDebug "code_check=$code_check"
                        fi
		fi
		logDebug "Finding OS Arch and CPU Type"
		####Checking for The Architecture of the Server####
        	arch64_test=`echo "$Os_detected" | grep -i "64-bit" | cut -d ' ' -f1`
        	arch32_test=`echo "$Os_detected" | grep -i  "32-bit" | cut -d ' ' -f1`
		logDebug "arch64_test=$arch64_test ** arch32_test=$arch32_test"
                #archs390x_test=`echo "$Os_detected" | grep -iw  "s390x" | cut -d ' ' -f1`
                #archs390_test=`echo "$Os_detected" | grep -iw  "s390" | cut -d ' ' -f1`
		####Checking for the CPU of the Server####
       		cpu_itanium=`echo "$Os_detected" | grep -i Itanium | cut -d '=' -f1`
		logDebug "cpu_itanium=$cpu_itanium"

		####Validating#####
       		if [ $plat_test ]; then
        		Os_detected="UNIX"
           		code_check=$prod_check
			logDebug "Os_detected=$Os_detected ** code_check=$code_check"
        	fi
      		if [ $plat_test_linux ]; then
           		Os_detected="LINUX"
           		code_check=$prod_check
			logDebug "Os_detected=$Os_detected ** code_check=$code_check"
       		fi

        	os_arch=""
        	if [ $arch64_test ]; then
        		os_arch="64-bit"
			logDebug "os_arch=$os_arch"
        	fi
        	if [ $arch32_test ]; then
        		os_arch="32-bit"
			logDebug "os_arch=$os_arch"
        	fi
                #if [ $archppc64_test ]; then
                #        os_arch="ppc64"
			logDebug "os_arch=$os_arch"
                #fi
                #if [ $archs390x_test ]; then
                #        os_arch="s390x"
			logDebug "os_arch=$os_arch"
                #fi
                #if [ $archs390_test ]; then
                #        os_arch="s390"
			logDebug "os_arch=$os_arch"
                #fi


       		cpu_test=""
        	if [ $cpu_itanium ]; then
         		cpu_test="Itanium"
			logDebug "cpu_test=$cpu_test"
        	fi 
#	This function is called during the OS detection
#	it creates the Master Config file parses it and creates the new config file, without the sections.
		logDebug "Found OS Arch = $os_arch, CPU Type=$cpu_test"
                logInfo "Calling config_parser.sh... $3"
                $PREREQ_HOME/lib/config_parser.sh "$Os_detected" $code_check "Arch=$os_arch" "CPU=$cpu_test" "version=$version" $3 $Health
	
	echo $code_check $version 
	logInfo "code_check=$code_check ** version=$version"
	logDebug "Exiting from the function AutoOsDetection()"

}

#	Description : Display it to std output
#	input : it takes 5 parameters , 1 : pattern to display 2: eveluation pass/fail 3 : Result in the output 4: Actual Result collected from the system 5: Expected Result
#	output : None
myprintf(){
	# it should contains five parameters, as below:
	# printf "$patt" "Property" "Result"  "Found" 'Expected'
	logDebug "Entering function myprintf()"
	if [ "$xmlResult" = "True" ]; then
		logDebug "xmlResult=$xmlResult"
		if [ "$2" != "$PROPERTY_STR" -a "$2" != "========" ]; then
			xmlStr=`echo "$2 ~ $3 ~ $4 ~ $5"`
			generateXmlReport "$xmlStr"
		fi
	fi
	if [ "$2" = "OS Version" -o "$2" = "os.version" ]; then
           echo "$5" | tr "," "\n" > $TMP_DIR/pppppp_temp
    else
           echo "$5"  > $TMP_DIR/pppppp_temp
    fi

	ww=`wc -l $TMP_DIR/pppppp_temp | awk '{print $1}'`
	if [ "$ww" = "1" ]; then
		f="not"
	else
		f="true"
	fi
	while read tt
	do
		Fourtharg=$4
                MBstr=`echo $5 | grep "MB$"`
                MBPlusstr=`echo $5 | grep "MB+$"`
                GBstr=`echo $5 | grep "GB$"`
                GBPlusstr=`echo $5 | grep "GB+$"`
		MBunitstr=`echo $5 | grep "unit:MB"`
		GBunitstr=`echo $5 | grep "unit:GB"`

		if [ "$GBstr" != "" -o "$GBPlusstr" != "" -o "$GBunitstr" != "" ]; then
                        actMBstr=`echo $4 | grep "MB$"`
                        actMBPlusstr=`echo $4 | grep "MB+$"`
                        if [ "$actMBstr" != "" -o "$actMBPlusstr" != "" ]; then
							tmpConStr=`echo $4 | sed s'/+//' | sed s'/MB//'`
							ConStr=`echo "scale=2; $tmpConStr / 1024" | bc`
							Fourtharg=`echo ${ConStr}GB`
                        fi
                fi
		if [ "$MBstr" != "" -o "$MBPlusstr" != "" -o "$MBunitstr" != "" ]; then
                        actGBstr=`echo $4 | grep "GB$"`
                        actMGPlusstr=`echo $4 | grep "GB+$"`
                        if [ "$actGBstr" != "" -o "$actGBPlusstr" != "" ]; then
                            tmpConStr=`echo $4 | sed s'/+//' | sed s'/GB//'`
                            ConStr=`echo "scale=2; $tmpConStr * 1024" | bc`
                            Fourtharg=`echo ${ConStr}MB`
                        fi
        fi
		FinalStrCount=`echo $Fourtharg | wc -m`
        FinalStr=`echo $Fourtharg |  cut -c 1-35 | sed 's/     $//' | sed 's/,$//'`
        if [ $FinalStrCount -gt 35 ]; then
        	Fourtharg=`echo "$FinalStr..."`
        fi
		
		if [ "$f" = "true" ]; then
			printf "$1" "$2 " "$3" "$Fourtharg  " "$tt"
			logDebug " $1 ** $2 ** $3 ** $Fourtharg ** $tt "
			f="false"
		elif [ "$f" = "false" ]; then
			printf "$1" " " " " " " "$tt"
			logDebug " $1 ** $tt "
		else
			ates=`echo "$4" | sed -n '/[ ]\{1,\}/p'`
			if [ -z "$ates" ]; then
				printf "$1" "$2 " "$3" "$Fourtharg  " "$tt" 
				logDebug " $1 ** $2 ** $3 ** $Fourtharg ** $tt "
			else
				printf "$1" "$2 " "$3" "$Fourtharg  " "$tt" 
				logDebug " $1 ** $2 ** $3 ** $Fourtharg ** $tt "
			fi
		fi
	done < $TMP_DIR/pppppp_temp
	rm -f $TMP_DIR/pppppp_temp
	logDebug "Exiting function myprintf()"
}

#	Description : Display it to std output
#	input : it takes 5 parameters , 1 : pattern to display 2: eveluation pass/fail 3 : Result in the output 4: Actual Result collected from the system 5: Expected Result
#	output : None
smyprintf(){

	logDebug "Entering function smyprintf()"
        if [ "$2" = "Connectivity" ]; then
           return
        fi 

        
        if [ "$2" = "OS Version" -o "$2" = "os.version" ]; then
                echo "$5" | tr "," "\n" > $TMP_DIR/pppppp_temp
        else
                echo "$5"  > $TMP_DIR/pppppp_temp
        fi
        
        ww=`wc -l $TMP_DIR/pppppp_temp | awk '{print $1}'`
        if [ "$ww" = "1" ]; then
                f="not"
        else
                f="true"
        fi
        while read tt
        do
		check=`echo $2 |grep "#" | cut -d' ' -f1`
		if [ $check ]; then
			echo $check > $TMP_DIR/prs.abc
		else

		Fourtharg=$4
		MBstr=`echo $5 | grep "MB$"`
		MBPlusstr=`echo $5 | grep "MB+$"`
		MBunitstr=`echo $5 | grep "unit:MB"`
		GBstr=`echo $5 | grep "GB$"`
		GBPlusstr=`echo $5 | grep "GB+$"`
		GBunitstr=`echo $5 | grep "unit:GB"`

		if [ "$GBstr" != "" -o "$GBPlusstr" != "" -o "$GBunitstr" != "" ]; then
			actMBstr=`echo $4 | grep "MB$"`
			actMBPlusstr=`echo $4 | grep "MB+$"`
			if [ "$actMBstr" != "" -o "$actMBPlusstr" != "" ]; then
				tmpConStr=`echo $4 | sed s'/+//' | sed s'/MB//'`
				ConStr=`echo "scale=2; $tmpConStr / 1024" | bc`
				Fourtharg=`echo ${ConStr}GB`
			fi
		fi
		if [ "$MBstr" != "" -o "$MBPlusstr" != "" -o "$MBunitstr" != "" ]; then
			actGBstr=`echo $4 | grep "GB$"`
			actMGPlusstr=`echo $4 | grep "GB+$"`
			if [ "$actGBstr" != "" -o "$actGBPlusstr" != "" ]; then
				tmpConStr=`echo $4 | sed s'/+//' | sed s'/GB//'`
				ConStr=`echo "scale=2; $tmpConStr * 1024" | bc`
				Fourtharg=`echo ${ConStr}MB`
			fi
		fi

				logInfo "PropertyName : $2"
                logInfo "Result : $3"
                logInfo "Found Value : $Fourtharg "
                logInfo "Expected Value : $tt"

                FinalStrCount=`echo $Fourtharg | wc -m`
                FinalStr=`echo $Fourtharg |  cut -c 1-35 | sed 's/     $//' | sed 's/,$//'`
                if [ $FinalStrCount -gt 35 ]; then
                        FinalStr=`echo "$FinalStr..."`
                fi

                if [ "$f" = "true" ]; then
                        printf "$spatt" "$2 " "$3" "$FinalStr  " "$tt"
                        logDebug "$spatt ** $2 ** $3 ** $FinalStr ** $tt "
                        f="false"
                elif [ "$f" = "false" ]; then
                        printf "$spatt" " " " " " " " $tt"
                        logDebug "$spatt ** $tt "
                else
                        printf "$spatt" "$2 " "$3" "$FinalStr  " "$tt"
                        logDebug "$spatt ** $2 ** $3 ** $FinalStr ** $tt "
                fi

             fi 
        done < $TMP_DIR/pppppp_temp
        rm -f $TMP_DIR/pppppp_temp
	logDebug "Exiting function smyprintf()"
}

#       Description : clean OutputDir files
#       input : none
#       output : None

clean_outputDir(){
        Dir=$1
        rm -f $Dir/$Result_XML_File 2>/dev/null
        rm -f $Dir/$Result_TXT_File 2>/dev/null
        rm -f $Dir/$Scn_Log_File 2>/dev/null
        rm -rf $Dir/temp 2>/dev/null
}


#	Description : clean tmp files
#	input : none
#	output : None

clean_log(){
	if [ "$TMP_DIR" = "" ]; then
                exit 2
        else
                rm -f $TMP_DIR/$Result_TXT_File 2>/dev/null
                rm -f $TMP_DIR/$plog 2>/dev/null
                rm -f $TMP_DIR/$ptrace 2>/dev/null
                rm -rf $TMP_DIR 2>/dev/null
                rm -rf /tmp/$tempDir 2>/dev/null
                rm -rf $PRS_BASE_DIR/$tempDir 2>/dev/null
        fi

}

#       Description : Generate XML Header 
#       input : none
#       output : None
Create_XML_Header() {

	logDebug "Entering function Create_XML_Header() "
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\" ?> " > $TMP_DIR/$Result_XML_File
	logDebug "<?xml version=\"1.0\" encoding=\"UTF-8\" ?> "

	echo "<!--  " >> $TMP_DIR/$Result_XML_File
	logDebug "<!--  "
	echo "$Indent Begin Standard Header  " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent Begin Standard Header  "
	echo "  " >> $TMP_DIR/$Result_XML_File
	logDebug "  "
	echo "$Indent Licensed Materials - Property of IBM  " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent Licensed Materials - Property of IBM  "
	echo "$Indent (C) Copyright IBM Corp. 2009, 2013  All Rights Reserved." >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved. "
	echo "$Indent US Government Users Restricted Rights - Use, duplication or  " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent US Government Users Restricted Rights - Use, duplication or  "
	echo "$Indent disclosure restricted by GSA ADP Schedule Contract with IBM Corp.  " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent disclosure restricted by GSA ADP Schedule Contract with IBM Corp.  "
	echo "$Indent   " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent   "
	echo "$Indent End Standard Header  " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent End Standard Header  "
	echo "-->  " >> $TMP_DIR/$Result_XML_File
	logDebug "-->  "


	echo "<Results schemaVersion=\"1.3\"" >> $TMP_DIR/$Result_XML_File
	logDebug "<Results schemaVersion=\"1.3\""
	echo "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"" >> $TMP_DIR/$Result_XML_File
	logDebug "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
	echo "xsi:noNamespaceSchemaLocation=\"PRSResults.xsd\"" >> $TMP_DIR/$Result_XML_File
	logDebug "xsi:noNamespaceSchemaLocation=\"PRSResults.xsd\""
	echo ">" >> $TMP_DIR/$Result_XML_File
	logDebug ">"
	logDebug "Exiting function Create_XML_Header() "
}

#       Description : Display system information on console
#       input : String
#       output : None
ElementAsItIs() {
	
	logDebug "Entering function ElementAsItIs() "
	bufStr="$1"
	if [ "$xmlResult" = "True" ]; then
		echo "$1" >> $TMP_DIR/$Result_XML_File
		logDebug "$1"
	fi
	logDebug "Exiting function ElementAsItIs() "
}
#	Description : Display system information on console
#	input : none
#	output : None
Display_PRS_Info() {

        logDebug "Entering function Display_PRS_Info() "
        logDebug "$Indent $Indent PRSName : $PRS_Str"
        logDebug "     $VER_STR: $PRS_Version"
        logDebug "     $BLD_STR  : $PREREQ_BUILD"
        logDebug "     $OSNAME_STR: $os_name"
        if [ "$os_name" = "SunOS" ]; then
                logDebug "   $USRNM_STR: `id | cut -d')' -f1 | cut -d'(' -f2`"
        else
                logDebug "   $USRNM_STR: `whoami`"
        fi

        outputdir=`dirname $TMP_DIR`

        if [ "$DetailFlag" = "True" ]; then
        echo "$PRS_Str"
        echo "     $VER_STR: $PRS_Version"
        echo "     $BLD_STR  : $PREREQ_BUILD"
        echo "     $OSNAME_STR: $os_name"
                if [ "$os_name" = "SunOS" ]; then
                        echo "   $USRNM_STR: `id | cut -d')' -f1 | cut -d'(' -f2`"
                else
                        echo "   $USRNM_STR: `whoami`"
                fi
        fi
        if [ "$xmlResult" = "True" ]; then
                ElementAsItIs "$Indent <PRSInfo>"
                generateXmlReport "$Indent $Indent PRSName : $PRS_Str"
                generateXmlReport "             PRSVersion: $PRS_Version"
                generateXmlReport "$Indent $Indent PRSBuild  : $PREREQ_BUILD"
                generateXmlReport "$Indent $Indent PRSOutputDir : $outputdir"
                generateXmlReport "$Indent $Indent PRSResultXmlFile : $outputdir/$Result_XML_File"
                ElementAsItIs "$Indent </PRSInfo>"
        fi
        logDebug "Exiting function Display_PRS_Info() "
}

#       Description : generates the XML results for PRS inforamtion
#       input : String
#       output : None
Create_PRS_info_Section() {
	logDebug "Entering function Create_PRS_info_Section()"
	
	bufStr="$1"
	FirstStr=`echo $bufStr | sed 's/ //g' | cut -d':' -f1 | sed -e 's/^ *//g;s/ *$//g'`
	SecStr=`echo $bufStr | cut -d':' -f2 | sed -e 's/^ *//g;s/ *$//g'`

	echo "$Indent $Indent <$FirstStr>$SecStr</$FirstStr>" >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent <$FirstStr>$SecStr</$FirstStr>"
	logDebug "Exiting function Create_PRS_info_Section()"
}

#       Description : generates the XML results for User inforamtion
#       input : String
#       output : None
Create_User_info_Section() {
	
	logDebug "Entering function Create_User_info_Section()"
	bufStr="$1"
	FirstStr=`echo $bufStr | sed 's/ //g' | cut -d':' -f1 | sed -e 's/^ *//g;s/ *$//g'`
	SecStr=`echo $bufStr | cut -d':' -f2 | sed -e 's/^ *//g;s/ *$//g'`

	echo "$Indent $Indent <$FirstStr>$SecStr</$FirstStr>" >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent <$FirstStr>$SecStr</$FirstStr>"
	logDebug "Exiting function Create_User_info_Section()"
}

# JC - quick fix to add ScenarioInfo section.  needs to be updated during Unix health check implementation
#       Description : generates the XML results for Scenario inforamtion
#       input : String
#       output : None
Create_Scenario_info_Section() {

	logDebug "Entering function Create_Scenario_info_Section()"
	# hard coded for prereq scenario, needs to be changed to use a variable to identify the real scenario
	if [ "$HealthFalg" = "Active" -o "$HealthFalg" = "active" ]; then
		echo "$Indent<ScenarioInfo>$HEALTH_ACTIVE_STR</ScenarioInfo>" >> $TMP_DIR/$Result_XML_File
		logDebug "$Indent<ScenarioInfo>$HEALTH_ACTIVE_STR</ScenarioInfo>"
	elif [ "$HealthFalg" = "Inactive" -o "$HealthFalg" = "inactive" ]; then
		echo "$Indent<ScenarioInfo>$HEALTH_INACTIVE_STR</ScenarioInfo>" >> $TMP_DIR/$Result_XML_File
		logDebug "$Indent<ScenarioInfo>$HEALTH_INACTIVE_STR</ScenarioInfo>"
	else
		echo "$Indent<ScenarioInfo>$PREREQ_STR</ScenarioInfo>" >> $TMP_DIR/$Result_XML_File
		logDebug "$Indent<ScenarioInfo>$PREREQ_STR</ScenarioInfo>"
	fi
	logDebug "Exiting function Create_Scenario_info_Section()"
}

#       Description : generates the XML results for machine inforamtion
#       input : String
#       output : None
Create_machine_info_Section() {

	
	logDebug "Entering function Create_machine_info_Section()"
	bufStr="$1"
	FirstStr=`echo $bufStr | sed 's/ //g' | cut -d':' -f1 | sed -e 's/^ *//g;s/ *$//g'`
	SecStr=`echo $bufStr | cut -d':' -f2 | sed -e 's/^ *//g;s/ *$//g'`

	echo "$Indent $Indent <$FirstStr>$SecStr</$FirstStr>" >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent <$FirstStr>$SecStr</$FirstStr>"
	logDebug "Exiting function Create_machine_info_Section()"
}

#       Description : generates the XML results for Product inforamtion
#       input : String
#       output : None
Create_Product_info_Section() {

	logDebug "Entering function Create_Product_info_Section()"
        bufStr="$1"
        FirstStr=`echo $bufStr | cut -d':' -f1 | sed -e 's/^ *//g;s/ *$//g'`
        SecStr=`echo $bufStr   | cut -d':' -f2 | sed -e 's/^ *//g;s/ *$//g'`
	ThirdStr=`echo $bufStr | cut -d':' -f3 | sed -e 's/^ *//g;s/ *$//g'`

	echo "$Indent <ProductElement> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent <ProductElement> "
	echo "$Indent $Indent <ProductCode>$FirstStr</ProductCode> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent <ProductCode>$FirstStr</ProductCode> "
	echo "$Indent $Indent <ProductName>$SecStr</ProductName> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent <ProductName>$SecStr</ProductName> "
	echo "$Indent $Indent <ProductVersion>$ThirdStr</ProductVersion> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent <ProductVersion>$ThirdStr</ProductVersion> "
	echo "$Indent </ProductElement> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent </ProductElement> "
	logDebug "Exiting function Create_Product_info_Section()"
}

#       Description : generates the XML results for detailed results inforamtion
#       input : String
#       output : None
Create_detailed_result_Section() {

	logDebug "Entering function Create_detailed_result_Section()"
        bufStr="$1"
        FirstStr=`echo $bufStr | sed 's/&/ and /g' | cut -d'~' -f1 | sed -e 's/^ *//g;s/ *$//g'`
        SecStr=`echo $bufStr   | cut -d'~' -f2 | sed -e 's/^ *//g;s/ *$//g'`
        ThirdStr=`echo $bufStr |  cut -d'~' -f3 | sed -e 's/^ *//g;s/ *$//g'`
        FourthStr=`echo $bufStr | cut -d'~' -f4 | sed -e 's/^ *//g;s/ *$//g'`

	MBstr=`echo $FourthStr | grep "MB$"`
	MBPlusstr=`echo $FourthStr | grep "MB+$"`
	GBstr=`echo $FourthStr | grep "GB$"`
	GBPlusstr=`echo $FourthStr | grep "GB+$"`
	MBunitstr=`echo $5 | grep "unit:MB"`
	GBunitstr=`echo $5 | grep "unit:GB"`

	if [ "$GBstr" != "" -o "$GBPlusstr" != "" -o "$GBunitstr" != "" ]; then
		actMBstr=`echo $ThirdStr | grep "MB$"`
		actMBPlusstr=`echo $ThirdStr | grep "MB+$"`
		if [ "$actMBstr" != "" -o "$actMBPlusstr" != "" ]; then
			tmpConStr=`echo $ThirdStr | sed s'/+//' | sed s'/MB//'`
			ConStr=`echo "scale=2; $tmpConStr / 1024" | bc`
			ThirdStr=`echo ${ConStr}GB`
		fi
	fi
	if [ "$MBstr" != "" -o "$MBPlusstr" != "" -o "$MBunitstr" != "" ]; then
		actGBstr=`echo $ThirdStr | grep "GB$"`
		actMGPlusstr=`echo $ThirdStr | grep "GB+$"`
		if [ "$actGBstr" != "" -o "$actGBPlusstr" != "" ]; then
			tmpConStr=`echo $ThirdStr | sed s'/+//' | sed s'/GB//'`
			ConStr=`echo "scale=2; $tmpConStr * 1024" | bc`
			ThirdStr=`echo ${ConStr}MB`
		fi
	fi

        echo "$Indent $Indent <ResultElement> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent <ResultElement> "
        echo "$Indent $Indent $Indent <PropertyName>$FirstStr</PropertyName> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent $Indent <PropertyName>$FirstStr</PropertyName> "
        echo "$Indent $Indent $Indent <Result>$SecStr</Result> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent $Indent <Result>$SecStr</Result> "
        echo "$Indent $Indent $Indent <Found>$ThirdStr</Found> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent $Indent <Found>$ThirdStr</Found> "
        echo "$Indent $Indent $Indent <Expected>$FourthStr</Expected> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent $Indent <Expected>$FourthStr</Expected> "
        echo "$Indent $Indent </ResultElement> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent </ResultElement> "
	logDebug "Exiting function Create_detailed_result_Section()"
}

#       Description : generates the XML results for Overall results inforamtion
#       input : String
#       output : None
Create_Overall_Result_Section() {

	logDebug "Entering function Create_Overall_Result_Section()"
        bufStr="$1"
        FirstStr=`echo $bufStr | cut -d'~' -f1 | sed -e 's/^ *//g;s/ *$//g'`
        SecStr=`echo $bufStr   | cut -d'~' -f2 | sed -e 's/^ *//g;s/ *$//g'`
        ThirdStr=`echo $bufStr | cut -d'~' -f3 | sed -e 's/^ *//g;s/ *$//g'`
        FourthStr=`echo $bufStr | cut -d'~' -f4 | sed -e 's/^ *//g;s/ *$//g'`

        MBstr=`echo $FourthStr | grep "MB$"`
        MBPlusstr=`echo $FourthStr | grep "MB+$"`
        GBstr=`echo $FourthStr | grep "GB$"`
        GBPlusstr=`echo $FourthStr | grep "GB+$"`
	MBunitstr=`echo $5 | grep "unit:MB"`
	GBunitstr=`echo $5 | grep "unit:GB"`

	if [ "$GBstr" != "" -o "$GBPlusstr" != "" -o "$GBunitstr" != "" ]; then
                actMBstr=`echo $ThirdStr | grep "MB$"`
                actMBPlusstr=`echo $ThirdStr | grep "MB+$"`
                if [ "$actMBstr" != "" -o "$actMBPlusstr" != "" ]; then
                        tmpConStr=`echo $ThirdStr | sed s'/+//' | sed s'/MB//'`
                        ConStr=`echo "scale=2; $tmpConStr / 1024" | bc`
                        ThirdStr=`echo ${ConStr}GB`
                fi
        fi
	if [ "$MBstr" != "" -o "$MBPlusstr" != "" -o "$MBunitstr" != "" ]; then
                actGBstr=`echo $ThirdStr | grep "GB$"`
                actMGPlusstr=`echo $ThirdStr | grep "GB+$"`
                if [ "$actGBstr" != "" -o "$actGBPlusstr" != "" ]; then
                        tmpConStr=`echo $ThirdStr | sed s'/+//' | sed s'/GB//'`
                        ConStr=`echo "scale=2; $tmpConStr * 1024" | bc`
                        ThirdStr=`echo ${ConStr}MB`
                fi
        fi

        echo "$Indent $Indent <ResultElement> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent <ResultElement> "
        echo "$Indent $Indent $Indent <PropertyName>$FirstStr</PropertyName> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent $Indent <PropertyName>$FirstStr</PropertyName> "
        echo "$Indent $Indent $Indent <Result>$SecStr</Result> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent $Indent <Result>$SecStr</Result> "
        echo "$Indent $Indent $Indent <Found>$ThirdStr</Found> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent $Indent <Found>$ThirdStr</Found> "
        echo "$Indent $Indent $Indent <Expected>$FourthStr</Expected> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent $Indent <Expected>$FourthStr</Expected> "
        echo "$Indent $Indent </ResultElement> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent </ResultElement> "
	logDebug "Exiting function Create_Overall_Result_Section()"
}

#       Description : generates the XML results for Single Property warning messages
#       input : String
#       output : None
Create_Single_Prop_Warn_Section() {

	logDebug "Entering function Create_Single_Prop_Warn_Section()"
        echo "$Indent<Warnings> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent<Warnings> "
        echo "$Indent $Indent <Message>$1</Message> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent $Indent <Message>$1</Message> " 
        echo "$Indent</Warnings> " >> $TMP_DIR/$Result_XML_File
	logDebug "$Indent</Warnings> "

	logDebug "Exiting function Create_Single_Prop_Warn_Section()"
}


#	Description : generates the XML results
#	input : String
#	output : None
generateXmlReport() {

	logDebug "Entering function generateXmlReport()"
	str=$1
	if [ "$xmlResult" = "True" ]; then
		if [ "$xmlFlag" = "$XML_Header" ]; then
			logDebug "Calling function Create_XML_Header $str"
			Create_XML_Header
		fi
		if [ "$xmlFlag" = "$PRS_Info" ]; then
			logDebug "Calling function Create_PRS_info_Section $str"
			Create_PRS_info_Section "$str"
		fi
		if [ "$xmlFlag" = "$Machine_Info" ]; then
			logDebug "Calling function Create_machine_info_Section $str"
			Create_machine_info_Section "$str"
		fi
		if [ "$xmlFlag" = "$User_Info" ]; then
			logDebug "Calling function Create_User_info_Section $str"
			Create_User_info_Section "$str"
		fi
		if [ "$xmlFlag" = "$Scenario_Info" ]; then
			logDebug "Calling function Create_Scenario_info_Section"
			Create_Scenario_info_Section
		fi
		if [ "$xmlFlag" = "$Product_Info" ]; then
			logDebug "Calling function Create_Product_info_Section $str"
			Create_Product_info_Section "$str"
		fi
		if [ "$xmlFlag" = "$Detailed_Result" ]; then
			logDebug "Calling function Create_detailed_result_Section $str"
			Create_detailed_result_Section "$str"
		fi
		if [ "$xmlFlag" = "$Overall_Result" ]; then
			logDebug "Calling function Create_Overall_Result_Section $str"
			Create_Overall_Result_Section "$str"
		fi
		if [ "$xmlFlag" = "$SinglePropWarn" ]; then
			logDebug "Calling function Create_Single_Prop_Warn_Section $str"
			Create_Single_Prop_Warn_Section "$str"
		fi
	fi
	logDebug "Exiting function generateXmlReport()"
	
}
#	Description : generates the code version and codename 
#	input : file name 
#	output : None
GetCodenameAndVersion() {

	logDebug "Entering function GetCodenameAndVersion()"
		
	if [ "$xmlResult" = "True" ]; then
		#Display Product info only for "XML" report generations
		xmlFlag=$Product_Info
		ElementAsItIs "    <ProductInfo>"
		file=$1
		logDebug "reading the contents of file:$file"
		while read cf
		do 
			logDebug "line = $cf"
			baserst=`basename $cf`
			code=`echo $baserst | sed "s/\(.*\)_.*/\1/g"`
			version=`echo $baserst | sed "s/.*_\(.*\)/\1/g"`
			codename=$code
			logDebug "baserst=$baserst ** code=$code ** version=$version ** codename=$codename"

			if [ "$HealthChkFlag" = "True" ]; then
                                numCodename=`ls $PREREQ_HOME/codename.cfg 2>/dev/null | wc -l`
				logDebug "numCodename=$numCodename"
                        else
                                numCodename=`ls $PREREQ_HOME/*codename.cfg 2>/dev/null | wc -l`
				logDebug "numCodename=$numCodename"
                        fi
                        if [ $numCodename -ge 1 ]; then
                                if [ "$HealthChkFlag" = "True" ]; then
                                        codename=`cat $PREREQ_HOME/codename.cfg | grep "$code=" | sed "s/$code=//g" | tr -d "\015"`
					logDebug "codename=$codename"
                                else
                                        codename=`cat $PREREQ_HOME/*codename.cfg | grep "$code=" | sed "s/$code=//g" | tr -d "\015"`
					logDebug "codename=$codename"
                                fi
                        else
                         codename=$code
                        fi

			generateXmlReport "$code : $codename : $version"
		done < $file
		ElementAsItIs "$Indent </ProductInfo>"
	fi
	logDebug "Exiting function GetCodenameAndVersion()"
}
#       Description : Check the /tmp disk space before executing PRS
#       input :  None
#       output : None
Check_tmp_DiskSpace() {
	
        type=`uname`
	
        if [ "$type" = "Linux" ]; then
                res=` df -k /$PRS_BASE_DIR | tail -n 1`
                len=`echo $res | wc -w`
                len1=`expr $len - 2`
                avail=`echo $res | cut -d ' ' -f$len1`
        fi
        if [ "$type" = "SunOS" ]; then
                avail=`df -k /$PRS_BASE_DIR | awk '{ if(NF<7 && NF>1){ print $(4) } }'`
        fi
        if [ "$type" = "AIX" ]; then
                avail=`df -k /$PRS_BASE_DIR | sed -n 2p | awk '{print $3}'`
        fi
        if [ "$type" = "HP-UX" ]; then
                avail=`df -k /$PRS_BASE_DIR | sed -n 2p | awk '{print $1}'`
        fi
        tmpSize=`expr $avail / 1024`
	

	if [ "$debugFlag" = "True" ]; then
		if [ $tmpSize -le $PRS_Size_WithDEBUG ]; then
			echo ""
			printmessage "$INSUFFICIENT_DISKSPACE_FOR_PRS_EXECUTION_STR" "$PRS_BASE_DIR" "$PRS_Size_WithDEBUG" "$PRS_Size_WithoutDEBUG" 
			echo ""
			clean_log
			exit 2
		fi
	else
		if [ $tmpSize -le $PRS_Size_WithoutDEBUG ]; then
			echo ""
			printmessage "$INSUFFICIENT_DISKSPACE_FOR_PRS_EXECUTION_STR" "$PRS_BASE_DIR" "$PRS_Size_WithDEBUG" "$PRS_Size_WithoutDEBUG"
			echo ""
			clean_log
			exit 2
		fi
	fi
}
#       Description : Display Scenario Info on the console
#       input :  None
#       output : None
Display_Scenario_Info() {
        logDebug "Entering function Display_Scenario_Info()"
        if [ "$HealthFalg" = "Active" -o "$HealthFalg" = "active" ]; then
                if [ "$DetailFlag" = "True" ]; then
                        echo ""
                        echo "${SCENARIO_STR}: $HEALTH_ACTIVE_STR"
                fi
                echo "${SCENARIO_STR}: $HEALTH_ACTIVE_STR" >> $TMP_DIR/$rep
                logDebug "${SCENARIO_STR}: $HEALTH_ACTIVE_STR"
        elif [ "$HealthFalg" = "Inactive" -o "$HealthFalg" = "inactive" ]; then
                if [ "$DetailFlag" = "True" ]; then
                        echo ""
                        echo "${SCENARIO_STR}: $HEALTH_INACTIVE_STR"
                fi
                echo "${SCENARIO_STR}: $HEALTH_INACTIVE_STR" >> $TMP_DIR/$rep
                logDebug "${SCENARIO_STR}: $HEALTH_INACTIVE_STR"
        else
                if [ "$DetailFlag" = "True" ]; then
                        echo ""
                        echo "${SCENARIO_STR}: $PREREQ_STR"
                fi
                echo "${SCENARIO_STR}: $PREREQ_STR" >> $TMP_DIR/$rep
                logDebug "${SCENARIO_STR}: $PREREQ_STR"
        fi
        echo "" >> $TMP_DIR/$rep
        logDebug "Exiting function Display_Scenario_Info()"
}
#       Description : Display Error Message if No entries found in the run time Config file
#       input :  File name
#       output : None
IsConfigFileHasEntries() {

	logDebug "Entering function IsConfigFileHasEntries()"
        sed '/^$/d' $1 > $TMP_DIR/tmpConfigFile.txt
	logDebug "Reading the contents of file : $TMP_DIR/tmpConfigFile.txt"
        while read pp vv
        do
                cfgMasterfile=`ls -1 "$CFGHOME"/"$pp"_*$vv.cfg-Master 2>/dev/null | sort -ir | sed -n "1p" `
                cfgfile=`ls -1 "$CFGHOME"/"$pp"_*$vv.cfg 2>/dev/null | sort -ir | sed -n "1p" `
		logDebug "cfgMasterfile=$cfgMasterfile ** cfgfile=$cfgfile"
                if [ "$cfgMasterfile" ]; then
                        if [ "$cfgfile" = "" ]; then
                                printmessage "$NO_VALID_PROPERTIES_FOUND_STR" "$pp $vv"
				logError "$NO_VALID_PROPERTIES_FOUND_STR : $pp $vv"
                                echo ""
                                PRS_Usage
                        fi
                fi
                if [ "$cfgMasterfile" = "" -a "$cfgfile" = "" ]; then
                        printmessage "$PRODUCT_CODE_NOT_VALID_ERROR_STR" "$pp $vv"
			logError "$PRODUCT_CODE_NOT_VALID_ERROR_STR : $pp $vv"
                        echo ""
                        PRS_Usage
                fi
        done < $TMP_DIR/tmpConfigFile.txt
	logDebug "Exiting function IsConfigFileHasEntries()"
}
#       Description : This function handles the Single Property Check
#       input :  File name
#       output : None
SinglePropertyCheck() {

	logDebug "Entering function SinglePropertyCheck()"
	# If No arguments passed, then throw Error message and exit
	if [ "$UserPassedinProperty" = "" ]; then
		echo "$PASSINPROP_EMPTYPROPS_ERROR_STR" 
		logError "$PASSINPROP_EMPTYPROPS_ERROR_STR"
		echo ""
		if [ $NO_CMD_LINE_ARGS -ne 0 ]; then
			clean_log
		fi
		PRS_Usage
	else
		# Seperate the user passed in properties, All the properties separated by a "\n" 
		echo "$UserPassedinProperty" | sed 's/, /,/g' |  tr "," "\n"  | sort | uniq  > $TMP_DIR/$PropertyFile
	fi
	
	#Delete the tmpProperty file
	rm -rf $TMP_DIR/$tmpPropertyFile 2>/dev/null
	sed '/^$/d' $1 > $TMP_DIR/tmpConfigFile.txt
	ProdCount=`cat $TMP_DIR/tmpConfigFile.txt | wc -l`
	# check if Multiple products are passed as a command line arguments 
	if [ $ProdCount -gt 1 ]; then
		#echo "$PASSINPROP_MULTPROD_ERROR_STR"
		echo "$PASSINPROP_MULTPROD_ERROR_STR"
		#logError "$PASSINPROP_MULTPROD_ERROR_STR"
		logError "$PASSINPROP_MULTPROD_ERROR_STR"
		echo ""
		if [ $NO_CMD_LINE_ARGS -ne 0 ]; then
			clean_log
		fi
		PRS_Usage
	fi
	# Remove the warning message file if exists
	rm -rf $TMP_DIR/$WarningMsgFile 2>/dev/null
	# Read the Product and it version one by one (This is implemented if the feature is extended for Multiple products)
	logDebug "reading the contents of file $TMP_DIR/tmpConfigFile.txt"
	while read pp vv
        do
		cfgfile=`ls -1 "$CFGHOME"/"$pp"_*$vv.cfg 2>/dev/null | sort -ir | sed -n "1p" `
		# Read the properties one by one and process it
		logDebug "Config file name = $cfgfile"
		while read SingleProp
		do
			# replace the [] with \[\]
			SingleProp=`echo "$SingleProp" | sed -e 's/\[/\\\[/g;s/\]/\\\]/g'`
			IsPropExist=`grep "^$SingleProp" $cfgfile`
			# If the user passed in property is null
			IsRootProp=`echo $IsPropExist | grep  ":non_root"`
			IsNonRootProp=`echo $IsPropExist | grep ":root"`
			logDebug "SingleProp=$SingleProp ** IsPropExist=$IsPropExist ** IsRootProp=$IsRootProp ** IsNonRootProp=$IsNonRootProp "
			# Remove the lines which have non_root 
			if [ "$userid" = "root" ]; then
				if [ "$IsRootProp" != "" ]; then
					logDebug "user ID is : $userid "
					echo "$SingleProp" >> $TMP_DIR/$WarningMsgFile
					logDebug "SingleProp=$SingleProp"
					continue
				fi
			else
				if [ "$IsNonRootProp" != "" ]; then
					echo "$SingleProp" >> $TMP_DIR/$WarningMsgFile
					continue
				fi
			fi
			if [ "$IsPropExist" = "" ]; then
				echo "$SingleProp" >> $TMP_DIR/$WarningMsgFile
				echo ""
			else
				# If property exists and set the falg to true
				echo "$IsPropExist" >> $TMP_DIR/$tmpPropertyFile
			fi
		done < $TMP_DIR/$PropertyFile
		if [ -s "$TMP_DIR/$tmpPropertyFile" ]; then
			# Overwite the existing config file in the /tmp directory
			logInfo "Overwite the existing config file in the /tmp directory"
			mv $TMP_DIR/$tmpPropertyFile $cfgfile > /dev/null 2>&1
			logDebug "Replacing file  $TMP_DIR/$tmpPropertyFile with $cfgfile"
		else
			# Print the error message if any Warning messages
			WarningMsgString1=`cat $TMP_DIR/$WarningMsgFile | tr "\n" ","`
			WarningMsgString=`echo "$WarningMsgString1" | sed s'/.$//'`
			#Find the version of the config file
			MainbasenameofConfigFile=`basename $cfgfile`
			MainConfigFileversion=`echo "$MainbasenameofConfigFile" | cut -d'_' -f2 | cut -d'.' -f1`
			printmessage "$PASSINPROP_NOTVALID_WARN_STR" "[$pp $MainConfigFileversion]" "$WarningMsgString"

			logWarning "$PASSINPROP_NOTVALID_WARN_STR : $WarningMsgString [$pp $MainConfigFileversion]"
			echo ""
			printmessage "$PASSINPROP_NOTAPPLY_ERROR_STR" "[$pp $MainConfigFileversion]"
			#Print the message to log file
			tmpStr=`printmessage "$PASSINPROP_NOTAPPLY_ERROR_STR" "[$pp $MainConfigFileversion]"`
			logError "$tmpStr"
			echo ""
			echo "Fixing Solaris Issue, Creating tmp file instead of flag variable" >> $TMP_DIR/$SolarisMsgFile.txt
			break ;
		fi
	done < $TMP_DIR/tmpConfigFile.txt
	if [ -s "$TMP_DIR/$SolarisMsgFile.txt" ]; then
		if [ $NO_CMD_LINE_ARGS -ne 0 ]; then
			clean_log
		fi
		exit 2 ;
	fi
	logDebug "Exiting function SinglePropertyCheck()"
}

#       Description : Display PRS Usage and clean the /tmp directory
#       input :  none
#       output : None and exit with error code 2
PRS_Usage() {
        echo ""
        echo "${USAGE_STR}: ./prereq_checker.sh \"<Product Code>  [product version],  <Product Code>  [product version]...\" [PATH=<Agent install path>]  [detail]|[detail -s]  [-p <Product Code>.SECTION.NAME=VALUE pairs] [outputDir=\"<PRS output dir path>\"] [xmlResult] [-health <active|inactive>] [debug] [configHomeDir=\"<PRS config home dir path>\"]"
        echo ""
        echo "${EXAMPLE_STR}: ./prereq_checker.sh \"KLZ,KUD 06200000\" detail PATH=/opt/ibm/itm -p SERVER=IP.PIPE://mytems:1918,LCM.ad=/opt outputDir=\"/tmp/PRS/\" xmlResult -health active debug configHomeDir=\"/tmp/configHome\""
		if [ $NO_CMD_LINE_ARGS -ne 0 ]; then
			clean_log
        fi

	exit 2
}

#       Description : Display PRS Usage 
#       input :  none
#       output : None and exit with error code 2

PRS_Usage_without_clean() {
        echo ""
        echo "${USAGE_STR}: ./prereq_checker.sh \"<Product Code>  [product version],  <Product Code>  [product version]...\" [PATH=<Agent install path>]  [detail]|[detail -s]  [-p <Product Code>.SECTION.NAME=VALUE pairs] [outputDir=\"<PRS output dir path>\"] [xmlResult] [-health <active|inactive>] [debug] [configHomeDir=\"<PRS config home dir path>\"]"
        echo ""
        echo "${EXAMPLE_STR}: ./prereq_checker.sh \"KLZ,KUD 06200000\" detail PATH=/opt/ibm/itm -p SERVER=IP.PIPE://mytems:1918,LCM.ad=/opt outputDir=\"/tmp/PRS/\" xmlResult -health active debug configHomeDir=\"/tmp/configHome\""
		exit 2
}

#       Description : Check the Severity of the Property
#       input :  Property Ret Value, Property Name, Temp config file
#       output : Return PASS/FAIL
CheckSeverityOfProperty() {

	PropertyRetVal=$1
	PropertyName=`echo "$2" | sed 's/\[/\./g' | sed 's/\]/\./g'`
	TMPConfigFileName="$TMP_DIR/TMP_$3.tmp"
	FoundVal="$4"
	ExpVal="$5"
	logDebug "**PropertyRetVal=$PropertyRetVal****PropertyName=$PropertyName***TMPConfigFileName=$TMPConfigFileName***FoundVal=$FoundVal***ExpVal=$ExpVal"


	if [ "$PropertyRetVal" = "$PASS_STR" ]; then
		logDebug "Property result is PASS, Hence ignoring the Severity checking"
		echo "$PASS_STR"
	else
                PropertyList1=`echo "$PropertyName" | grep "os.space"`
                PropertyList2=`echo "$PropertyName" | grep "os.RAMSize"`
                PropertyList3=`echo "$PropertyName" | grep "db2.home.space"`
                if [ "$PropertyName" = "Memory" -o "$PropertyName" = "Disk" -o "$PropertyName" = "Temp" -o "$PropertyList1" != "" -o "$PropertyList2" != "" -o "$PropertyList3" != "" ]; then
                        logDebug "Found Property Memory,,/"
                        valueStatus=`echo "$ExpVal" | grep "[0-9]-[0-9]"`
                        if [ "$valueStatus" != "" ]; then
                                logDebug "CheckSeverityOfProperty ****FoundVal=$FoundVal****ExpVal=$ExpVal"
                                RangeValStatus=`CompareRangeValues "$FoundVal" "$ExpVal"`
                                echo "$RangeValStatus"
                                return
                        fi
                        SeviarityLineStatus=""
                        SeviarityLineStatus=`cat $TMPConfigFileName 2> /dev/null | grep "$PropertyName"`
                        if [ "$SeviarityLineStatus" = "" ]; then
                                logDebug "Severity Warn is not checking for property : $PropertyName"
                                echo "$PropertyRetVal"
                        else
                                logDebug "Severity Warn is Modified for property : $PropertyName"
                                echo "$WARN_STR"
                        fi
                        return
                fi
                if [ "$PropertyName" = "intel.cpu"  -o "$PropertyName" = "risc.cpu" ]; then
                                logDebug "Found Property Memory,,/"
                                valueStatus=`echo "$ExpVal" | grep "[0-9]-[0-9]"`
                                if [ "$valueStatus" != "" ]; then
                                        RangeValStatus=`CompareGHzMHzRangeValues "$FoundVal" "$ExpVal"`
                                        echo "$RangeValStatus"
                                        return
                                fi
                fi
                if [ -s "$TMPConfigFileName" ]; then
                        SeviarityLineStatus=""
                        SeviarityLineStatus=`cat $TMPConfigFileName 2> /dev/null | grep "$PropertyName"`
                        if [ "$SeviarityLineStatus" = "" ]; then
                                logDebug "Severity Warn is not checking for property : $PropertyName"
                                echo "$PropertyRetVal"
                        else
                                logDebug "Severity Warn is Modified for property : $PropertyName"
                                echo "$WARN_STR"
                        fi
                else
                        echo "$PropertyRetVal"
                fi
	fi
	
}

#       Description : Display PRS Build Version and Build ID
#       input :  PRS Property file
#       output : None
getPRSVersion() {

	fixVersion=""
	buildId=""
	logInfo "Reading PRS Version File : $1"
	if [ -s "$1" ]; then
		fixVersion=`cat "$1" 2>/dev/null | grep "FixVersion" | cut -d">" -f2 | cut -d"<" -f1`
		buildId=`cat "$1" 2>/dev/null | grep "BuildID" | cut -d">" -f2 | cut -d"<" -f1`
		echo ""
		echo "PRS Version : $fixVersion"
		echo "Build ID : $buildId"
		echo ""
	fi
}

####################################################
# Start of main logic
# If no parameter, show usage

NO_CMD_LINE_ARGS=$#

if [ $# -eq 0 ]; then
	printmessage "$MISSING_PRODUCT_CODE_ERROR_STR"
	echo ""
	PRS_Usage
fi

rep="result1.txt"
if [ "`uname`" = "AIX" ]; then
	if [ "$TERM" = "" ]; then
		TERM=vt100
		export TERM
	fi
fi
LC_ALL=C
export LC_ALL
if [ "$#" -eq 1 ]; then
	if [ ! "`echo $1 | sed -n '/[v|V][e|E][r|R][s|S][i|I][o|O][n|N]/p'`" = "" ]; then
		getPRSVersion $PRSVersionFile
		exit
	fi
fi
product_version=`echo $1 | sed 's/, /,/g'`
shift

spath=""
flag=""
deliverPara=""
xmlResult="False"
xmlFlag=0
debugFlag="False"
traceFlag="False"

pdbgger="/debugger.out"
Default_outputDir=`pwd`
PRS_OUTPUT_DIR=""

# RTC story 20889
#   Defined new parameters PRS_OUTPUT_DIR and TMP_DIR to handle the "outputDir" directory as command line input
#   If "outputDir" is not passed as a command line input then 
#   output dir will be default to PRS installation dir
#   Supports "outputDir" in both capital and non capital letters

ArgPosition=0
DetailArgPosition=0

for ARGS in "$@"
do
	ArgPosition=`expr $ArgPosition + 1`
        if [ ! "`echo $ARGS | sed -n '/[o|O][u|U][t|T][p|P][u|U][t|T][d|D][i|I][r|R].*/p'`" = ""  ]; then
                PRS_OUTPUT_DIR=`echo $ARGS | awk -F= '{print $1}'`
                outputdir=`echo $ARGS | awk -F= '{print $2}'`
                outputDirFlag="True"
        elif [ "$ARGS" = "xmlResult" ]; then
                xmlResult="True"
		elif [ ! "`echo $ARGS | sed -n '/[C|c][O|o][N|n][F|f][I|i][G|g][H|h][o|O][M|m][E|e][D|d][I|i][R|r]/p'`" = "" ]; then
                Str_ConfigHomeDir=`echo $ARGS | awk -F= '{print $2}'`
                ConfigHomeDir="True"
        elif [ "$ARGS" = "debugger" ]; then
                DebuggerFalg="True"
        elif [ "$ARGS" = "debug" ]; then
                debugFlag="True"
		_DEBUG="on" ;export _DEBUG
        elif [ "$ARGS" = "trace" ]; then
		traceFlag="True"
		echo ""
		echo "$TRACE_OPTION_NOT_FOUND_STR" 
		echo ""
	
	elif [ ! "`echo $ARGS | sed -n '/[P|p][r|R][o|O][p|P][e|E][r|R][t|T][y|Y]/p'`" = "" ]; then
		UserPassedinProperty=`echo $ARGS | sed 's/.[^=]*=\(.*\)/\1/'`
                TmpPropertyFlag="True"
		echo ""
		echo "$PASSIN_PROP_STR $UserPassedinProperty"
		echo ""

	elif [ ! "`echo $ARGS | sed -n '/-[h|H][e|E][a|A][l|L][t|T][h|H]/p'`" = "" ]; then
                TmpHealthFlag="True"

	elif [ ! "`echo $ARGS | sed -n '/[v|V][e|E][r|R][s|S][i|I][o|O][n|N]/p'`" = "" ]; then
                PRSVersionFalg="True"
		PRSVersionARGS=$ARGS

	elif [ "$TmpHealthFlag" = "True" ]; then
                HealthChkFlag="True"
		HealthFalg=`echo $ARGS `
		ActiveFalg=`echo $ARGS | grep "[a|A]ctive"`
                InactiveFalg=`echo $ARGS | grep "[i|I]nactive"`
                if [ "$ActiveFalg" = "" -a "$InactiveFalg" = "" ]; then
                        PRS_Usage
                fi
		TmpHealthFlag="False"
        
        elif [ "$pflag" = "TRUE" ]; then
                deliverPara=$ARGS
                pflag="FALSE"
        elif [ ! "`echo $ARGS | sed -n '/-[p|P]/p'`" = "" ]; then
                pflag="TRUE"
        elif [ ! "`echo $ARGS | sed -n '/[p|P][A|a][t|T][h|H]=.*/p'`" = "" ]; then
                spath=`echo $ARGS | sed 's/[p|P][A|a][t|T][h|H]=//'`
        elif [ ! "`echo $ARGS | sed -n '/[D|d]etail/p'`" = "" ]; then
                flag=$ARGS
		DetailFlag="True"
		DetailArgPosition=$ArgPosition
        elif [ ! "`echo $ARGS | sed -n '/-[s|S]/p'`" = "" ]; then
		ShortArgPosition=`expr $ArgPosition - 1`
		if [ $DetailArgPosition -eq 0 ]; then
			ShortArgFlag="False"
			echo ""
			printmessage "$SHORT_STR" "$ARGS"
			PRS_Usage
		elif [ $ShortArgPosition -eq $DetailArgPosition ]; then
			ShortArgFlag="True"
		else
			echo ""
			printmessage "$SHORT_STR" "$ARGS"
			PRS_Usage
			ShortArgFlag="False"
		fi
        else
                if [ "$InvalidArg" = "" ]; then
                        InvalidArg="\"$ARGS\""
                else
                        InvalidArg="$InvalidArg","\"$ARGS\""
                fi
        fi
done

if [ "$TmpHealthFlag" = "True" ]; then
	PRS_Usage
fi

if [ "$PRSVersionFalg" = "True" ]; then
	echo ""
	printmessage "$PRSVERSION_STR" "$PRSVersionARGS"
	echo ""
fi

if [ "$InvalidArg" != "" ]; then
        echo ""
        printmessage "$ARGUMENT_ERROR_STR" "$InvalidArg"
        echo ""
        PRS_Usage_without_clean
fi

if [ "$outputDirFlag" = "True" ]; then
	clean_outputDir $outputdir
	rm -rf $outputdir/temp/* 2>/dev/null
	if [ $? != 0 ]; then
		echo ""
		printmessage "$UNABLE_CLEAN_TEMP_DIR_STR" $outputdir
		echo ""
		PRS_Usage
	fi
else
	clean_outputDir $PWD
fi
if [ ! "$PRS_OUTPUT_DIR" = ""  -a  "$outputdir" = "" ]; then
	printmessage "$EMPTY_OUTPUTDIR_ERROR_STR" $product
	PRS_Usage
fi

# Create the temorary directory "/temp" within the "outputDir" 
# New "/temp" location is updated in "TMP_DIR" and this "TMP_DIR" variable is available thoughout the execution of the PRS

if [ ! "$PRS_OUTPUT_DIR" = "" ]; then
        FirstChar=`echo $outputdir | cut -c 1`
        if [ "$FirstChar" = "." ]; then
                TMP_DIR=$PREREQ_HOME/$outputdir/temp
		PRS_BASE_DIR=$PREREQ_HOME/$outputdir/
        elif [ "$FirstChar" != "." -a "$FirstChar" != "/" ]; then
                TMP_DIR=$PREREQ_HOME/$outputdir/temp
		PRS_BASE_DIR=$PREREQ_HOME/$outputdir/
        else
                TMP_DIR=$outputdir/temp
		PRS_BASE_DIR=$outputdir/
        fi
        outputDir=`dirname $TMP_DIR`
	printmessage "${OUTPUTDIR_STR}: %s1" $outputDir
        echo ""
else
        TMP_DIR=$Default_outputDir/temp
	PRS_BASE_DIR=$Default_outputDir/
fi


#### Copy all the source code to $TMP_DIR

DatenTime=`date +%Y%m%d_%H%M%S`
tempDir="prs_$DatenTime"
# All the log messages should start from here
mkdir -p /$PRS_BASE_DIR/$tempDir/temp > /dev/null 2>&1
if [  ! -d /$PRS_BASE_DIR/$tempDir ]; then
	echo ""
	printmessage "$TEMP_DIR_PERMISSION_DENIED_STR" "${PRS_BASE_DIR}${tempDir}"
	PRS_Usage
fi

TMP_DIR=/$PRS_BASE_DIR/$tempDir/temp
export TMP_DIR
export Scn_Log_File

if [ "$DebuggerFalg" = "True" ]; then
	echo ""
	echo "Executing PRS in Debugger Mode, This may take a few min to complete..."
	logDebug "Executing PRS in Debugger Mode, This may take a few min to complete..."
	echo ""
        exec 3>&1 4>&2 >$TMP_DIR/$pdbgger 2>&1
        set -x
fi

# Check the "/$PRS_BASE_DIR" disk space before copying PRS into "/$PRS_BASE_DIR" Directory 
Check_tmp_DiskSpace
logInfo "All the Log Messages should Start from here"
logDebug "Calling function Check_tmp_DiskSpace"


logInfo "Copying all files from $PREREQ_HOME into /$PRS_BASE_DIR/$tempDir Dir"
cp -r "$PREREQ_HOME"/prereq_checker.sh /$PRS_BASE_DIR/$tempDir 2>/dev/null
cp -r "$PREREQ_HOME"/PRSResults.xsd /$PRS_BASE_DIR/$tempDir 2>/dev/null
cp -r "$PREREQ_HOME"/lib /$PRS_BASE_DIR/$tempDir 2>/dev/null
cp -r "$PREREQ_HOME"/UNIX_Linux /$PRS_BASE_DIR/$tempDir 2>/dev/null
cp -r "$PREREQ_HOME"/*codename.cfg /$PRS_BASE_DIR/$tempDir 2>/dev/null
#cp -r "$PREREQ_HOME"/codename.cfg /$PRS_BASE_DIR/$tempDir 2>/dev/null
if [ "$HealthChkFlag" = "True" ]; then
	cp -r "$PREREQ_HOME"/UNIX_Linux/cfg/health/codename.cfg /$PRS_BASE_DIR/$tempDir 2>/dev/null
	rm -rf /"$PRS_BASE_DIR"/$tempDir/UNIX_Linux/*.cfg 2>/dev/null
	cp -r "$PREREQ_HOME"/UNIX_Linux/cfg/health/*.cfg /$PRS_BASE_DIR/$tempDir/UNIX_Linux/ 2>/dev/null
	if [ "$HealthFalg" = "Active" -o "$HealthFalg" = "active" ]; then
		Health='Active' ;export Health
		Result_XML_File="result_health_active.xml"
		Result_TXT_File="result_health_active.txt"
		Scn_Log_File="health_active.log"
		logDebug "Health=$Health ** Result_XML_File=$Result_XML_File ** Result_TXT_File=$Result_TXT_File ** Scn_Log_File=$Scn_Log_File"
	elif [ "$HealthFalg" = "Inactive" -o "$HealthFalg" = "inactive" ]; then
		Result_XML_File="result_health_inactive.xml"
		Result_TXT_File="result_health_inactive.txt"
		Health=Inactive ; export Health
		Scn_Log_File="health_inactive.log"
		logDebug "Result_XML_File=$Result_XML_File ** Result_TXT_File=$Result_TXT_File ** Scn_Log_File=$Scn_Log_File"
	else
		echo "Invalid Health Check option "
		logError "Invalid Health Check option "
		exit
	fi
elif [ "$ConfigHomeDir" = "True" ]; then
        if [  -d  "$Str_ConfigHomeDir" ]; then
                if [ -r "$Str_ConfigHomeDir" ]; then
                        rm -rf /$PRS_BASE_DIR/$tempDir/UNIX_Linux/*.cfg 2>/dev/null
                        cp -r "$Str_ConfigHomeDir"/*.cfg "/$PRS_BASE_DIR/$tempDir/UNIX_Linux/" 2>/dev/null
                        logInfo "Reading Prerequisite Scanner configuration files from user defined directory:  /$Str_ConfigHomeDir"
						echo ""
						printmessage "${CONFIGDIR_STR}: %s1" $Str_ConfigHomeDir
						echo ""
                else
                        echo ""
                        printmessage "$CONFIG_HOME_DIR_PATH_ISSUE_STR" "${Str_ConfigHomeDir}"
                        echo ""
                        exit 2
                fi
        else
                echo ""
                printmessage "$CONFIG_HOME_DIR_PATH_ISSUE_STR" "${Str_ConfigHomeDir}"
                echo ""
                exit 2
        fi
fi


#remove the existing result.txt and result.xml files
outputDir=$PRS_BASE_DIR
Default_outputDir=$PRS_BASE_DIR
rm $outputDir/$Result_TXT_File $outputDir/$Result_XML_File 2>/dev/null

PREREQ_HOME=/$PRS_BASE_DIR/$tempDir

export PREREQ_HOME
chmod -R 777  $PREREQ_HOME/*
xmlFlag=$XML_Header
generateXmlReport
xmlFlag=$PRS_Info
if [ "$DetailFlag" = "True" -o "$xmlResult" = "True" ]; then
        Display_PRS_Info
fi

        echo "$PRS_Str" >> $TMP_DIR/$rep
        logDebug "$PRS_Str"
        echo "     $VER_STR: $PRS_Version" >> $TMP_DIR/$rep
        logDebug "     $VER_STR: $PRS_Version"
        echo "     $BLD_STR  : $PREREQ_BUILD" >> $TMP_DIR/$rep
        logDebug "     $BLD_STR  : $PREREQ_BUILD"
        echo "     $OSNAME_STR: $os_name" >> $TMP_DIR/$rep
        logDebug "     $OSNAME_STR: $os_name"

if [ "$os_name" = "SunOS" ]; then
echo "   $USRNM_STR: `id | cut -d')' -f1 | cut -d'(' -f2`" >> $TMP_DIR/$rep
logDebug "   $USRNM_STR: `id | cut -d')' -f1 | cut -d'(' -f2`"
else
echo "   $USRNM_STR: `whoami`" >> $TMP_DIR/$rep
logDebug "   $USRNM_STR: `whoami`"
fi

echo " "
echo " " >> $TMP_DIR/$rep

xmlFlag=$Machine_Info
ElementAsItIs "    <MachineInfo>"
if [ "$DetailFlag" = "True" ]; then
        echo " $MACHINEINFO_STR"
fi
logDebug " $MACHINEINFO_STR"
echo " $MACHINEINFO_STR" >> $TMP_DIR/$rep
logDebug " $MACHINEINFO_STR"
if [ "$DetailFlag" = "True" ]; then
        echo " $MACHINENM_STR: `hostname`"
fi
logDebug " $MACHINENM_STR: `hostname`"
generateXmlReport "$Indent Machine Name: `hostname`"
echo " $MACHINENM_STR: `hostname`" >> $TMP_DIR/$rep
logDebug " $MACHINENM_STR: `hostname`"

if [ "$os_name" = "SunOS" ]; then
        if [ "$DetailFlag" = "True" ]; then
                echo " $SERIALNUM_STR: $HostID"
        fi
        generateXmlReport "$Indent Machine Serial Number: $HostID"
        echo " $SERIALNUM_STR: $HostID" >> $TMP_DIR/$rep
        logDebug " $SERIALNUM_STR: $HostID"
elif [ "$os_name" = "AIX" ]; then
        ser=`lscfg -vp | grep "Machine/Cabinet Serial No" | sed -n 1p | cut -d'.' -f4`
        if [ "$DetailFlag" = "True" ]; then
                echo " $SERIALNUM_STR: $ser"
        fi
        generateXmlReport "$Indent Machine Serial Number: $ser"
        echo " $SERIALNUM_STR: $ser" >> $TMP_DIR/$rep
        logDebug " $SERIALNUM_STR: $ser"
else
        dmi_check=`which dmidecode 2>/dev/null`
        if [ "$dmi_check" != "" ]; then
           dmi_check_first=`which dmidecode | cut -d " " -f1`
           if [ "$dmi_check_first" = "no" ]; then
                if [ "$os_name" = "HP-UX" ]; then
                                MachineSNo=`getconf MACHINE_SERIAL`
                                generateXmlReport "$Indent Machine Serial Number: $MachineSNo"
                                logDebug " $SERIALNUM_STR: $MachineSNo"

                                if [ "$DetailFlag" = "True" ]; then
                                        if [ "$DetailFlag" = "True" ]; then
                                                echo " $SERIALNUM_STR: $MachineSNo"
                                        fi
                                        echo " $SERIALNUM_STR: $MachineSNo" >> $TMP_DIR/$rep
                                fi
                fi
            else
                dcode=`dmidecode 2>/dev/null | grep "Serial Number" | sed -n 1p | cut -d ':' -f2`
                if [ "$DetailFlag" = "True" ]; then
                        echo " $SERIALNUM_STR: $dcode"
                fi
                generateXmlReport "$Indent Machine Serial Number: $dcode"
                echo " $SERIALNUM_STR: $dcode" >> $TMP_DIR/$rep
                logDebug "$SERIALNUM_STR: $dcode"
            fi
        fi
fi
echo " "
echo " " >> $TMP_DIR/$rep
generateXmlReport "$Indent $Indent MachineOSName: $os_name"
ElementAsItIs "$Indent </MachineInfo>"

#Display user info only for "XML" report generations
xmlFlag=$User_Info
ElementAsItIs "    <UserInfo>"
userid=`id | cut -d " " -f1 | cut -d '(' -f2 | cut -d ')' -f1`
generateXmlReport "User Name: $userid"
ElementAsItIs "    </UserInfo>"

#Display scenario info only for "XML" report generations
# JC - quick fix, needs to be formalized during unix health check implementation
xmlFlag="$Scenario_Info"
Display_Scenario_Info
generateXmlReport ""


PREREQ_TRACE=$traceFlag
export PREREQ_TRACE
PREREQ_DEBUG=$debugFlag
export PREREQ_DEBUG

if [ "$debugFlag" = "True" ]; then
	logDebug "If debugFlage is True"
	logDebug "IBM Tivoli Prerequisite Scanner"
	logDebug "     $VER_STR: $PRS_Version"
	logDebug "     $BLD_STR  : $PREREQ_BUILD"
	logDebug "     $OSNAME_STR: $os_name"

fi

logInfo "Starting of the main function"

##########STARTING OF AUTO OS DETECTION CODE ##################
logInfo "==== Step 1: Detecting OS..."
Os_detected_output=`$PREREQ_HOME/lib/auto_os_detect.sh | wc -l`
kernel_bit="Kernel="
Os_detected=""
if [ $Os_detected_output -eq 2 ]; then
        kernel_bit=`$PREREQ_HOME/lib/auto_os_detect.sh | sed -n 2p`
        Os_detected=`$PREREQ_HOME/lib/auto_os_detect.sh | sed -n 1p | cut -d '=' -f2 | sed 's/(/{/g' | sed 's/)/}/g'`
	logDebug "kernel_bit=$kernel_bit ** Os_detected=$Os_detected"
else
        Os_detected=`$PREREQ_HOME/lib/auto_os_detect.sh | cut -d '=' -f2 | sed 's/(/{/g' | sed 's/)/}/g'`
	logDebug "Os_detected=$Os_detected"
fi

logInfo "OS Detected: $Os_detected"
pd=""
warn="True"
productCount=0
productCode=""
product_version=`echo $product_version | sed 's/ /+/g'`
logInfo "product_version: $product_version"

for Arg in `echo $product_version | tr "," "\n"`
do
        product_iversion=`echo $Arg | sed 's/+/ /g' | cut -d" " -f1`
        pd1=`AutoOsDetection "$Arg" "$Os_detected" "$kernel_bit"`
        #commented pd2 because of the defect 36656
        #pd2=`AutoOsDetection "$product_iversion" "$Os_detected" "$kernel_bit"`

        #####Checking for the Correct Code ######
        IstheCodeWrong=`echo $pd1 | grep -i "not" | cut -d " " -f1`
        IstheOsMatched=`echo $pd1 | grep -i "doesn't" | cut -d " " -f1`
        if [ $IstheOsMatched ]; then
                echo $pd1
                warn="False"
                exit
        else
                #echo "TPS detected : $Os_detected "
                echo ""
        fi

		#I'm not sure why need of pd2 hence commenting out
		#commented pd2 because of the defect 36656
        #if [ "$pd1" = "" -o "$pd2" = "" ]; then
        if [ "$pd1" = "" ]; then
                warn="False"
                productCode=$Arg
                ProdCode=$ProdCode,$product_iversion
        fi

        if [ $IstheCodeWrong ]; then
                echo $pd1
                warn="False"
        else
                #echo "Using the $pd1 config file"
                pd=$pd1","$pd
        fi
        productCount=`expr $productCount + 1`
done
##########ENDING OF AUTO OS DETECTION CODE ##################


logDebug "Product code  = $pd"
logInfo "====== Step 2: Handle Params"

#Detect if TEMP and TMP environment variables are defined
if [ -s "$TMP_DIR/envVarChecking.txt" ]; then
        CheckTEMPenv=`cat $TMP_DIR/envVarChecking.txt 2>/dev/null | awk '/TEMP=FALSE/ { print $0}'`
        if [ "$CheckTEMPenv" != "" ]; then
                TEMP="/tmp/"
                export TEMP
        else
                TEMP="$TEMP/"
                export TEMP
        fi
        CheckTMPenv=`cat $TMP_DIR/envVarChecking.txt 2>/dev/null | awk '/TMP=FALSE/ { print $0}'`
        if [ "$CheckTMPenv" != "" ]; then
                TMP="/tmp/"
                export TMP
        else
                TMP="$TMP/"
                export TMP
        fi
fi

plog=$Scn_Log_File

if [ "$spath" = "" ]; then
	spath="/opt/IBM/ITM"
	logDebug "You have not specify path paramter. It will use default value /opt/IBM/ITM"
fi

if [ "$flag" = "" ]; then
	logDebug "hint: You can specify detail parameter to get detail information on screen."
fi


if [ ! "$deliverPara" = "" ]; then
	logDebug "You will pass the parameters to the sub-script: $deliverPara"
fi

# step 1. specifiedan for the products codes
CFGHOME=$PREREQ_HOME/UNIX_Linux
execommon="common.sh"
rescommon="localhost_hw.txt"
rep=result2.txt
patt="%-40s%-16s%-43s%-20s\n"
spatt="%-36s%-10s%-39s%-20s\n"
tfe=tf_epds
tfi=tf_ipds
tft=tf_tipds
exei=exeinfo
tempd=$TMP_DIR
TMEMO="Memory"
TDISK="Disk"

ls -1 "$CFGHOME"/*.cfg | sed "s;${CFGHOME};\.;" | tr -d "\.\/" | awk -F"_" '{if(length($1)>=3){print $1}}' | sort | uniq > $TMP_DIR/$tfe
echo $pd | tr "[a-z]" "[A-Z]" |  sed 's/\s{2,}/ /g' | sed 's/, /,/g' |  tr "," "\n"  | sort | uniq  > $TMP_DIR/$tfi
cat $TMP_DIR/$tfi | awk '{print $1}' > $TMP_DIR/$tft

#	variable aaaa is for detail mode
logInfo "Variable aaaa is for detail mode"
aaaa=`sort $TMP_DIR/$tfe $TMP_DIR/$tft $TMP_DIR/$tfe | uniq -u | tr "\n" " "`
logDebug "Is detail mode is passed as argument : $aaaa"
if [ ! "$aaaa" = "" ]; then
	logWarning "some check will be ignored by no configuration files found: [ $aaaa ]"
fi

join $TMP_DIR/$tfe $TMP_DIR/$tfi > $TMP_DIR/$tft 

aaaa=`wc -l $TMP_DIR/$tft | awk '{print $1;}'`
logDebug "Detail Mode : aaaa=$aaaa"

IsConfigFileHasEntries  "$TMP_DIR/$tfi"


if [ "$warn" = "False" ]; then
	ProdCode=`echo $ProdCode | sed 's/,//' | cut -d" " -f1`
	printmessage "$PRODUCT_CODE_NOT_VALID_ERROR_STR" $ProdCode
	logError "$PRODUCT_CODE_NOT_VALID_ERROR_STR : $ProdCode"
	PRS_Usage
	exit 2
fi
if [ "$aaaa" = "0" ]; then
        if [ "$warn" = "True" ]; then
		printmessage "$PRODUCT_CODE_NOT_FOUND_ERROR_STR" 
		logDebug "$PRODUCT_CODE_NOT_FOUND_ERROR_STR"
		PRS_Usage
		exit 2
        else
		exit
        fi
fi

# Call this function if the Single Property is enabled
if [  "$TmpPropertyFlag" = "True" ]; then
	logDebug "User passed in Single Property argument"
	SinglePropertyCheck "$TMP_DIR/$tfi"
fi

cora=">"
logInfo "====== Step 3: Reading product config file and creating product shell script"

#	packagetest.sh -> takes the config file and path of the config home
#		for each line os.space and create a sh file with the same name of the config file except .cfg is replace with .sh 
#		and this .sh file invokes the script for each script 
#		ex: os.space is called with corrousponng poaramters and logged into ".sh" file for further running it. 
#			user will be able to open the ".sh" file to see the enteries
while read pp vv
do
	cfgfile=`ls -1 "$CFGHOME"/"$pp"_*$vv.cfg 2>/dev/null | sort -ir | sed -n "1p" `
	if [ -z "$cfgfile" ]; then
		cfgfile=`ls -1 "$CFGHOME"/"$pp"_*.cfg 2>/dev/null | sort -ir | sed -n "1p" `
		printmessage "$CONFIG_FILE_NOT_FOUND_STR" $vv $pp
		logWarning "Can not Find the specified version: $vv for $pp. Use $cfgfile instead"
		PRS_Usage
	fi
        logDebug "config file is $cfgfile" 

	chmod +x $CFGHOME/packageTest.sh
	tmpCfgfile=`basename $cfgfile`
	logDebug "Calling packageTest.sh script with parameters ** $CFGHOME ** $tmpCfgfile"
	$CFGHOME/packageTest.sh $CFGHOME $tmpCfgfile 1>/dev/null

	exefile=`echo $tmpCfgfile | sed 's/\.cfg/\.sh/g'`
	if [ ! -f "$CFGHOME/$exefile" ]; then
	        exefile=$execommon
	fi

	cfgfile=`echo $cfgfile | tr "\n" " "`
	logDebug "pp=$pp ** cfgfile=$cfgfile ** exefile=$exefile ** cora=$cora ** exei=$TMP_DIR/$exei"
	eval "echo $pp $cfgfile $exefile $cora $TMP_DIR/$exei" 
	cora=">>"

	logDebug "$pp will read:  $cfgfile and will execute: $exefile"
done < $TMP_DIR/$tft
	# remove the temp files
#clean_temp
# step 2. execute the commonds

logInfo "====== Step 4: Executing product shell scripts that collect information about checks"
cat $TMP_DIR/$exei | awk '{print $3}' | sort | uniq > $TMP_DIR/$tfe
echo $execommon > $TMP_DIR/$tft
sort $TMP_DIR/$tfe $TMP_DIR/$tft $TMP_DIR/$tft | uniq -u >> $TMP_DIR/$tft

#Check if the multiple config files are invoked
multipleConfigFileCount=`cat $TMP_DIR/$tfe | wc -l`
#Below line modification is to fix RTC defect 44640
multipleConfigFileCount=0
if [ $multipleConfigFileCount -gt 1 ]; then
	logDebug "Multiple config files are passed as a command line argument"
	while read fteFilenames
	do
		#Any excluded properties needs to be listed here in grep
		cat $CFGHOME/$fteFilenames 2> /dev/null | grep -v "os.space" >> $CFGHOME/tmpCommonCollectors.sh
		cat $CFGHOME/$fteFilenames 2> /dev/null | grep "os.space" >> $CFGHOME/excludeCommonCollectors.sh
		mv $CFGHOME/excludeCommonCollectors.sh $CFGHOME/$fteFilenames 2> /dev/null
	done < $TMP_DIR/$tfe
	CommonCollectorsCount=0
	if [ "`uname`" = "SunOS" ];then
		#awk command does not work on SunOS, -- removing the duplicate entries in the collector file.
		logDebug "Removing the duplicated entries in the config files"
		cat $CFGHOME/tmpCommonCollectors.sh 2> /dev/null | nawk '!x[$0]++' > $CFGHOME/CommonCollectors.sh
	else
		#Duplicate properties are removed, without sorting,
		logDebug "Removing the duplicated entries in the config files"
		cat $CFGHOME/tmpCommonCollectors.sh 2> /dev/null | awk '!x[$0]++' > $CFGHOME/CommonCollectors.sh
	fi
fi

ttsc=`wc -l $TMP_DIR/$tft | awk '{print $1}'`

logDebug "Calling Scripts: [$ttsc scripts will be called]"
i=1
while read execommand
do
	logDebug "Calling: $execommand [$i of $ttsc]"
	if [ "$execommand" = "$execommon" ]; then
		logDebug "Evaluating cd $CFGHOME;chmod +x $execommand;./$execommand $spath $deliverPara"
		eval "cd $CFGHOME;chmod +x $execommand;./$execommand $spath $deliverPara"
		cd $tempd
		crc=commonchange
		cat $TMP_DIR/$rescommon | sort | uniq > $TMP_DIR/$crc	2>/dev/null
		
		# if there should parse cpu Name
                iscpuname=`cat $TMP_DIR/$crc | grep "CPU Name"`
		logDebug "CPU name : $iscpuname"
                if [ "$iscpuname" != "" ]; then
                        eh=`cat $TMP_DIR/$crc | grep "CPU Name" | grep -i "intel"`
                        cu=`cat $TMP_DIR/$crc | grep "CPU Name" | sed 's/.*\s\{1,\}\([0-9\.,]\{1,\}\s*[g|G|m|M]\)[h|H][z|Z].*/\1/g'`
                        if [ -n "$eh" ]; then
                                echo intel.cpu=$cu"Hz" >> $TMP_DIR/$crc
                        else
                                echo risc.cpu=$cu"Hz" >> $TMP_DIR/$crc
                        fi
                fi

		# filter the xlC
		case `uname` in 
			AIX)
				echo "xlC lib version="`lslpp -L xlC.rte | grep xlC.rte | awk '{print $2}'` >> $TMP_DIR/$crc
			;;
		esac
		

		mv $TMP_DIR/$crc $TMP_DIR/$rescommon

		# execute the common plugins
		logDebug "Executing the common plugins"
		# parse out the parameters
		fdeliver=""
		for fde in `echo $deliverPara | tr "," "\n"`
		do
			fones="$fde"
			for exipd in `cat $TMP_DIR/$exei | awk '{print $1}'`
			do 
				if [ -n "$fones" ]; then
					fones=`echo $fones | grep -v "$exipd"`
				else
					break
				fi
			done

			if [ -n "$fones" ]; then
				if [ -n "$fdeliver" ]; then
					fdeliver="$fdeliver,$fones"
				else
					fdeliver="$fones"
				fi
			fi
		done

		# execute plugs
		#Connectivity Check,Parsing the Input Variables and getting the Config file for check
                #Parsing the Input Paratameters
		if [ "`uname`" = "SunOS" ];then
			
			IP1=`echo $pd | awk '{print $1}'`
			IP2=`echo $pd | awk '{print $2}'` 
			CheckVal1=`echo $IP1 | grep ","`
			if [ $CheckVal1 ]; then
				IP1=`echo $IP1 | sed 's/.$//g'`
			fi
			Checkval2=`echo $IP2 | grep ","`
			if [ $Checkval2 ]; then
				IP2=`echo $IP2 | sed 's/.$//g'`
			fi
			if [ "$HealthChkFlag" = "True" ]; then
                                cfgfile=`ls "$HealthChkHOME"/"$IP1"_"$IP2"*.cfg 2>/dev/null | sed "s/"$HealthChkHOME"\///g" 2>/dev/null | sort -ir | sed -n "1p" 2>/dev/null | cut -d '/' -f2`
				logDebug "If HealthCheck, then cfgfile=$cfgfile"
                        else
                                cfgfile=`ls "$CFGHOME"/"$IP1"_"$IP2"*.cfg 2>/dev/null | sed "s/"$CFGHOME"\///g" 2>/dev/null | sort -ir | sed -n "1p" 2>/dev/null | cut -d '/' -f2`
				logDebug "If not HealthCheck, then cfgfile=$cfgfile"
                        fi
			if [ -f "$CFGHOME/$cfgfile" ]; then
				check=`cat $CFGHOME/$cfgfile | grep "Connectivity" | cut -d '=' -f2` 2>/dev/null
				logDebug "check=$check"
			fi
                        if [ "$check" = "True" ]; then
				logDebug "Calling $CFGHOME/connectivity_plug.sh $spath $fdeliver"
                                $CFGHOME/connectivity_plug.sh $spath $fdeliver >> $TMP_DIR/$rescommon 2>> $TMP_DIR/$plog
                        fi

		else
 
			if [ -f "$cfgfile" ]; then
				check=`cat $cfgfile | grep "Connectivity" | cut -d '=' -f2`
                	fi
 
			if [ "$check" = "True" ]; then
				$CFGHOME/connectivity_plug.sh $spath $fdeliver >> $TMP_DIR/$rescommon 2>>$TMP_DIR/$plog
                	fi	
		fi

                cd $PREREQ_HOME/lib
		for exeplug in `ls *plug*.sh 2>/dev/null`
		do
			logDebug "Calling plugin : ./$exeplug $spath $fdeliver  "
			eval "chmod +x $exeplug; ./$exeplug $spath $fdeliver >> $TMP_DIR/$rescommon  2>>$TMP_DIR/$plog"
		done
		
	else
		orstfile=`echo $execommand | sed 's/\.sh/\.txt/g'`
		cp -f $TMP_DIR/$rescommon $TMP_DIR/$orstfile
		# filter the parameters
		fdeliver=""
		fpd=`echo $execommand | awk -F_ '{print $1;}'`
		for fde in `echo $deliverPara | tr "," "\n"`
		do
			jjj=`echo $fde | grep $fpd`
			if [ "$fdeliver" = "" ]; then
				fdeliver="`echo $fde | grep $fpd | awk -F. '{print $2;}'`"
			elif [ "$jjj" != "" ]; then
				fdeliver="$fdeliver,""`echo $fde | grep $fpd | awk -F. '{print $2;}'`"
			fi
		done
		logDebug "Evaluating $CFGHOME/$execommand ** $spath ** $fdeliver"
                if [ $multipleConfigFileCount -gt 1 ]; then
                        if [ $CommonCollectorsCount = 0 ]; then
                                eval "cd $CFGHOME;chmod +x $execommand;$CFGHOME/$execommand $spath $fdeliver >> $TMP_DIR/$orstfile 2>>/dev/null"
                                eval "cd $CFGHOME;chmod +x CommonCollectors.sh;$CFGHOME/CommonCollectors.sh $spath $fdeliver > $TMP_DIR/CommonOrstfile 2>>/dev/null"
                                CommonCollectorsCount=`expr $CommonCollectorsCount + 1`
                                cat $TMP_DIR/$orstfile $TMP_DIR/CommonOrstfile >> $TMP_DIR/$orstfile 2> /dev/null
                        else
                                eval "cd $CFGHOME;chmod +x $execommand;$CFGHOME/$execommand $spath $fdeliver >> $TMP_DIR/$orstfile 2>>/dev/null"
                                cat $TMP_DIR/$orstfile $TMP_DIR/CommonOrstfile >> $TMP_DIR/$orstfile 2> /dev/null
                        fi
                else
                        eval "cd $CFGHOME;chmod +x $execommand;$CFGHOME/$execommand $spath $fdeliver >> $TMP_DIR/$orstfile 2>>/dev/null"
                fi
	fi

	cd ..
	i=`expr $i + 1`
done < $TMP_DIR/$tft

logDebug "End call commands"

	# remove the temp files
rm -f $TMP_DIR/$tfe $TMP_DIR/$tft 2>/dev/null

# write the common plugs information to result.txt
# here is the port connection
cat $TMP_DIR/$rescommon | sed -n '/[C|c]onnectivity/p' > $TMP_DIR/$rep
cat $TMP_DIR/$rescommon | sed -n '/OS Patch/p' >> $TMP_DIR/$rep

# step 3. analysis and generate reports
logDebug "====== Step 5: Comparing/evaluating the information collected for each check with the values in config file and generating reports"
cat $TMP_DIR/$exei | awk '{print $2}' | sed 's/\.cfg$//' > $TMP_DIR/$tfi
aaaa=`echo $flag | grep -i "detail" | wc -l | sed 's/[ ]*//g'` 
if [ "$aaaa" != "0" ]; then
	cat $TMP_DIR/$rescommon | sed -n '/[C|c]onnectivity/p' | sed 's/[ ]\{8,8\}/    /g'
	cat $TMP_DIR/$rescommon | sed -n '/OS Patch/p'
fi

GetCodenameAndVersion "$TMP_DIR/$tfi"

xmlFlag=$Detailed_Result
ElementAsItIs "    <DetailedResults>"


head=">>"
	total_memory=0
	total_disk=0
exec 4<&0 0< $TMP_DIR/$tfi
while read cf
do
	baserst=`basename $cf`
	rstfile=`ls "$tempd"/"$baserst"*.txt 2>/dev/null | sort -ir | sed -n "1p"`
	logDebug "baserst=$baserst ** rstfile=$rstfile"
	if [ -z "$rstfile" ]; then
		rstfile=$TMP_DIR/$rescommon
	fi

	# deal with the rstfile

	# begin to compare
	
	logDebug "Deal with $cf"

	# write head of report 
	#code=`echo $cf | sed "s/\(.*\)_.*/\1/g"`
	#version=`echo $cf | sed "s/.*_\(.*\)/\1/g"`

	code=`echo $baserst | sed "s/\(.*\)_.*/\1/g"`
	version=`echo $baserst | sed "s/.*_\(.*\)/\1/g"`
        codename=$code
	logDebug "code=$code ** version=$version ** codename=$codename"

	if [ "$HealthChkFlag" = "True" ]; then
                numCodename=`ls $PREREQ_HOME/codename.cfg 2>/dev/null | wc -l`
		logDebug "numCodename=$numCodename"
        else
                numCodename=`ls $PREREQ_HOME/*codename.cfg 2>/dev/null | wc -l`
		logDebug "numCodename=$numCodename"
        fi

	if [ $numCodename -ge 1 ]; then 
		if [ "$HealthChkFlag" = "True" ]; then
			codename=`cat $PREREQ_HOME/codename.cfg | grep "$code=" | sed "s/$code=//g" | tr -d "\015"g`
			logDebug "codename=$codename"
		else
			codename=`cat $PREREQ_HOME/*codename.cfg | grep "$code=" | sed "s/$code=//g" | tr -d "\015"`
			logDebug "codename=$codename"
		fi
        else
       		 codename=$code
	fi

	if [ "$codename" = "" ]; then
		codename=`cat product.cfg | grep "$code=" | sed "s/$code=//g" | sed 's/^M//g'`
		logDebug "If codename is null : $codename"
	fi

    # The below block is specific to ITM agent to find the directory path to determine whether ITM cmd cinfo exists
    # "Cinfo" command is run to determine whether this is a fresh or upgrade install
    # Code names KUD -> ud, KUX -> ux, KLZ -> lz are the Monitoring agent product codes, 
    # Monitoring Agent Product codes "ud/ux/lz" are determined from the cinfo command  
	# # deal with the upgrate or fresh
	# copy and filter the items from $CFGHOME to $tempd
        nfsstatus_check=`NFScheck $spath`
        if [ "$nfsstatus_check" = "TRUE" ]; then
                cinfopath=`find "$spath" -name cinfo -print  2>/dev/null | sed -n 1p 2>/dev/null`
                fresh="yes"
                lcode=`echo $code | sed 's/K//g'`
                if [ -n "$cinfopath" ]; then
			#Check if the agent is installed 
                        IsAgentInstalled=`$cinfopath -i 2>> $TMP_DIR/$Scn_Log_File | grep -wi "$lcode"`
                        if [ -n "$IsAgentInstalled" ]
                        then
                           fresh=no
                        fi
                        isfre=`$cinfopath -r 2>> $TMP_DIR/$Scn_Log_File | grep -wi "$lcode"`
                        if [ -n "$isfre" ]; then
                                IsAgentRunning="yes"
                        fi
                fi
        fi

    # To sync with Windows implementation, we are considering only FRESH.Memory and Memory Property
    # Ignore UPGRADE.Memory property from the config files
    # config file entries looks like 
    # FRESH.Memory=30MB
	# UPGRADE.Memory=30MB
	# FRESH.Disk=135MB
	# UPGRADE.Disk=263MB
	
	#If the Agent installed, Get inside the if loop
	if [ -n "$IsAgentInstalled" ]; then
		#Get the version of the old config file
		iclcode=`echo "$lcode" | awk '{print tolower($0)}'`
		AgentVersion=`$cinfopath -i | awk "/^$iclcode/{linecount=NR+3}(NR<=linecount){print}" | grep "Version:" | tail -1 | awk -F"Version:" '{print $2}' | sed 's/\.//g' | sed 's/ //g'`

		OldAgentConfigFile="$CFGHOME/K${lcode}_${AgentVersion}.cfg"
		NewAgentConfigFile="$cf.cfg"

		OldAgentConfigFileExists="No"
		if [ -s "$OldAgentConfigFile" ]; then
			OldAgentConfigFileExists="Yes"
		fi
		#If the Agent is running ?
		if [ "$IsAgentRunning" = "yes" ]; then
			#Agent is running
			logDebug "Agent is found and it is Running"
			#Is the old config file exists ?
			if [ "$OldAgentConfigFileExists" = "Yes" ]; then
				#get the FRESH.Memory value
				OldUpgradeMemoryValue=`grep "^FRESH.Memory" $OldAgentConfigFile | cut -d'=' -f2`
				if [ ! "$OldUpgradeMemoryValue" ]; then
					OldUpgradeMemoryValue=`grep "^Memory" $OldAgentConfigFile | cut -d'=' -f2`
				fi
				NewUpgradeMemoryValue=`grep "^FRESH.Memory" $NewAgentConfigFile | cut -d'=' -f2`
				if [ ! "$NewUpgradeMemoryValue" ]; then
                                        NewUpgradeMemoryValue=`grep "^Memory" $NewAgentConfigFile | cut -d'=' -f2`
                                fi


				if [ "$NewUpgradeMemoryValue" ]; then
					if [ "$OldUpgradeMemoryValue" ]; then
						logDebug "Memory property found in both the New and Old config files"
						#convert both old and new value in MB's
						OldUpgradeMemoryValue=`Convert_GB_to_MB "$OldUpgradeMemoryValue"`
						NewUpgradeMemoryValue=`Convert_GB_to_MB "$NewUpgradeMemoryValue"`

						#Convert floating values to integer values
						OldUpgradeMemoryValue=`echo "$OldUpgradeMemoryValue" | awk '{printf "%.0f",$1}'`
						NewUpgradeMemoryValue=`echo "$NewUpgradeMemoryValue" | awk '{printf "%.0f",$1}'`

						if [ $NewUpgradeMemoryValue -ge $OldUpgradeMemoryValue ]; then
							UpgradeMemory=`expr $NewUpgradeMemoryValue - $OldUpgradeMemoryValue`
						else
							UpgradeMemory=$NewUpgradeMemoryValue
						fi
						UpgradeMemory="${UpgradeMemory}MB"
						logDebug "Upgrade Memory = $UpgradeMemory"
					else
						logDebug "No Memory property is found in the old config file"
						UpgradeMemory=$NewUpgradeMemoryValue
						logDebug "Upgrade Memory = $UpgradeMemory"
					fi
				else
					logDebug "Memory Property is not found in the New config file"
				fi
			else
				NewUpgradeMemoryValue=`grep "^FRESH.Memory" $NewAgentConfigFile | cut -d'=' -f2`
				if [ "$NewUpgradeMemoryValue" ]; then
					UpgradeMemory=$NewUpgradeMemoryValue
				else
					NewUpgradeMemoryValue=`grep "^Memory" $NewAgentConfigFile | cut -d'=' -f2`
					if [ "$NewUpgradeMemoryValue" ]; then
						UpgradeMemory=$NewUpgradeMemoryValue
					fi
				fi
			fi
		else
			#Agent is not running
			logDebug "Agent is found But not Running"
			#Is the old config file exists ?
			if [ "$OldAgentConfigFileExists" = "Yes" ]; then
                                #get the FRESH.Memory value
                                OldUpgradeMemoryValue=`grep "^FRESH.Memory" $OldAgentConfigFile | cut -d'=' -f2`
                                if [ ! "$OldUpgradeMemoryValue" ]; then
                                        OldUpgradeMemoryValue=`grep "^Memory" $OldAgentConfigFile | cut -d'=' -f2`
                                fi
                                NewUpgradeMemoryValue=`grep "^FRESH.Memory" $NewAgentConfigFile | cut -d'=' -f2`
                                if [ ! "$NewUpgradeMemoryValue" ]; then
                                        NewUpgradeMemoryValue=`grep "^Memory" $NewAgentConfigFile | cut -d'=' -f2`
                                fi
				
				if [ "$NewUpgradeMemoryValue" ]; then
                                        if [ "$OldUpgradeMemoryValue" ]; then
                                                logDebug "Memory property found in both the New and Old config files"
                                                #convert both old and new value in MB's
                                                OldUpgradeMemoryValue=`Convert_GB_to_MB "$OldUpgradeMemoryValue"`
                                                NewUpgradeMemoryValue=`Convert_GB_to_MB "$NewUpgradeMemoryValue"`

                                                #Convert floating values to integer values
												OldUpgradeMemoryValue=`echo "$OldUpgradeMemoryValue" | awk '{printf "%.0f",$1}'`
												NewUpgradeMemoryValue=`echo "$NewUpgradeMemoryValue" | awk '{printf "%.0f",$1}'`

                                                if [ $NewUpgradeMemoryValue -ge $OldUpgradeMemoryValue ]; then
                                                        UpgradeMemory=`expr $NewUpgradeMemoryValue - $OldUpgradeMemoryValue`
                                                else
                                                        UpgradeMemory=$NewUpgradeMemoryValue
                                                fi
                                                UpgradeMemory="${UpgradeMemory}MB"
                                                logDebug "Upgrade Memory = $UpgradeMemory"
                                        else
                                                logDebug "No Memory property is found in the old config file"
                                                UpgradeMemory=$NewUpgradeMemoryValue
                                                logDebug "Upgrade Memory = $UpgradeMemory"
                                        fi
                                else
                                        logDebug "Memory Property is not found in the New config file"
                                fi
                        else
                                NewUpgradeMemoryValue=`grep "^FRESH.Memory" $NewAgentConfigFile | cut -d'=' -f2`
                                if [ "$NewUpgradeMemoryValue" ]; then
                                        UpgradeMemory=$NewUpgradeMemoryValue
				else
					NewUpgradeMemoryValue=`grep "^Memory" $NewAgentConfigFile | cut -d'=' -f2`
					if [ "$NewUpgradeMemoryValue" ]; then
						UpgradeMemory=$NewUpgradeMemoryValue
					fi
                                fi
                        fi
		fi
	fi
        tmpcfg=`basename $cf`

        if [ "$fresh" = "yes" ]; then
           logDebug "Agent is not found, Fresh Installation, Not taking any actions on Memory Property"
           cat $cf.cfg | while read tmpcfgLINE;
           do
                   if [ `echo "$tmpcfgLINE" | grep "^UPGRADE.Memory"` ]; then
                           continue
                   elif [ `echo "$tmpcfgLINE" | grep "^FRESH.Memory"` ]; then
                           echo "$tmpcfgLINE" | sed 's/FRESH\.//g'  >> $tempd/$tmpcfg.cfg
                   elif [ `echo "$tmpcfgLINE" | grep "^FRESH.Disk"` ]; then
                           echo "$tmpcfgLINE" | sed 's/FRESH\.//g'  >> $tempd/$tmpcfg.cfg
                   elif [ `echo "$tmpcfgLINE" | grep "^UPGRADE.Disk"` ]; then
                           continue
                   elif [ `echo "$tmpcfgLINE" | grep "^Memory"` ]; then
                           echo "$tmpcfgLINE" >> $tempd/$tmpcfg.cfg
                   else
                           echo "$tmpcfgLINE" >> $tempd/$tmpcfg.cfg
                   fi
           done
        else
           # Agent upgrade install
           logDebug " Agent upgrade install"
           cat $cf.cfg | while read tmpcfgLINE;
           do
                   if [ `echo "$tmpcfgLINE" | grep "^FRESH.Memory"` ]; then
                           echo "Memory=${UpgradeMemory}"  >> $tempd/$tmpcfg.cfg
                   elif [ `echo "$tmpcfgLINE" | grep "^FRESH.Disk"` ]; then
                           continue
                   elif [ `echo "$tmpcfgLINE" | grep "^Memory"` ]; then
                           echo "Memory=${UpgradeMemory}"  >> $tempd/$tmpcfg.cfg
                   elif [ `echo "$tmpcfgLINE" | grep "^UPGRADE.Disk"` ]; then
                           echo "$tmpcfgLINE" | sed 's/UPGRADE\.//g'  >> $tempd/$tmpcfg.cfg
                   elif [ `echo "$tmpcfgLINE" | grep "^UPGRADE.Memory"` ]; then
                           continue
                   else
                           echo "$tmpcfgLINE" >> $tempd/$tmpcfg.cfg
                   fi
           done
        fi

	ElementAsItIs "	<DetailedProductResultsElement>"
	ElementAsItIs "		<ProductCode>$code</ProductCode>"

	eval "echo "$code - $codename" "[version $version]:" $head $TMP_DIR/$rep"
	if [ ! "$aaaa" = "0" ]; then
		echo "$code - $codename [version $version]:"
		MainNumEntriesInFile=`sed '/^ *$/ d' $cf.cfg | wc -l`
		if [ $MainNumEntriesInFile -lt 1 ]; then
			printmessage "$NO_CHECKS_APPLY_INFO_STR" "[$code $version]"
			logInfo "$NO_CHECKS_APPLY_INFO_STR ** $code ** $version"
			echo "" >> $TMP_DIR/$rep
			printmessage "$NO_CHECKS_APPLY_INFO_STR" "[$code $version]" >> $TMP_DIR/$rep
		fi
	fi
	head=">>"

		####This is for Displaying Valid Checks,Based on the,Based on the Id's#####
		logInfo "Ignoring the NOT_REQ_CHECK_ID"
		NofValues=`cat $rstfile | grep -c "NOT_REQ_CHECK_ID"`
		logDebug "NofValues=$NofValues"
        LineNo=1
        if [ $NofValues -gt 0 ]; then
		logDebug "NOT_REQ_CHECK_ID count is more than Zero"
                while [ $LineNo -le $NofValues ]
                do
                        CommentValue=`cat $rstfile | grep NOT_REQ_CHECK_ID | cut -d '=' -f1 | sed -n "$LineNo"p`
                        if [ $CommentValue ]; then
                                        sed "s/"$CommentValue"/#"$CommentValue"/g" $cf.cfg >> $TMP_DIR/test
                                        mv $TMP_DIR/test $cf.cfg
                        fi
                        LineNo=`expr $LineNo + 1`
                done
        fi
	###End of this Section###	

	subhead="TRUE"
	Consolesubhead="TRUE"

	# Keep the copy of the results file
	# Commeting this function for the time being, this needs to be implemented later
	logDebug "Keep the copy of Result file"
	cat $TMP_DIR/$rep >> $TMP_DIR/tmp_$rep
	logDebug "Contents of the Result are truncated, Fresh results will be written to Result file"
	echo "" > $TMP_DIR/$rep
	
	logDebug "Delete lines which do not have = sign in the $tempd/$tmpcfg.cfg file"
    cat $tempd/$tmpcfg.cfg | sed '/=/!d' > $tempd/$tmpcfg.cfg.new
    mv $tempd/$tmpcfg.cfg.new $tempd/$tmpcfg.cfg
	
	OLDIFS=$IFS
	IFS==
	exec 4<&0 0< $tempd/$tmpcfg.cfg
	while read item value
	do
        IFS=$OLDIFS        
		logDebug "Evaluating $item..."
                r="$FAIL_STR"
                xlCFlag="False"
		
		logDebug "Delete if any control char"
		value=`echo $value | tr -d "\015"`
		valueStatus=`echo "$value" | grep "-"`
		if [ "$valueStatus" != "" ]; then
			Act_value=$value
			value=`echo "$value" | cut -d "-" -f2-`
		else
			Act_value=$value
		fi
                #This is to Make the result.txt More Readable for Connectivity test
               	Val1=`echo $item | grep "Connectivity"`
                if [ $Val1 ]; then
                        break
                fi

		# skip to compare xlC lib version if not AIX
		if [ "$item" = "xlC lib version" ]; then
			case `uname` in
				AIX)
                                   res=0
                                        rstvalue=`cat $rstfile | grep  "xlC" | cut -d= -f2`
                                        tmpArg=`versionCompare $value $rstvalue`
                                         if [ $tmpArg -eq -1 -o $tmpArg -eq 0 ]; then
                                                res=1
                                        fi
                                         if [ $res -eq 1 ]; then
                                                 r="$PASS_STR"
                                                 else
                                                 r="$FAIL_STR"
                                         fi
                                        xlCFlag="True"
				;;
				*)
					IFS==
					continue
				;;
			esac
		fi

		if [ "$item" = "$TMEMO" ]; then
			if [ "$total_memory" = "0" ]; then
				total_memory="0MB"
			fi
			totMemRangeStatus=`echo "$total_memory" | grep "-"`
			Act_valueRangeStatus=`echo "$Act_value" | grep "-"`
			totMem_unit=`echo "$total_memory" | grep "GB"`
			tt_unit=`echo "$Act_value" | grep "GB"`
			if [ "$totMemRangeStatus" = "" -a "$Act_valueRangeStatus" = "" ]; then
				total_memory=`AddMG $total_memory $value`
				if [ "$tt_unit" = "" ]; then
					total_memory=`echo "${total_memory}MB"`
				else
					total_memory=`echo "${total_memory}GB"`
				fi
			elif [ "$totMemRangeStatus" = "" -a "$Act_valueRangeStatus" != "" ]; then
				Act_valueRangeVal1=`echo "$Act_value" | cut -d"-" -f1`
				Act_valueRangeVal2=`echo "$Act_value" | cut -d"-" -f2`
				if [ "$tt_unit" = "" ]; then
					tVal1=`AddMGwithUnitVal $total_memory "${Act_valueRangeVal1}MB"`
				else
					tVal1=`AddMGwithUnitVal $total_memory "${Act_valueRangeVal1}GB"`
				fi
				tVal2=`AddMGwithUnitVal $total_memory $Act_valueRangeVal2`
				total_memory=`echo "$tVal1-${tVal2}GB"`
			elif [ "$totMemRangeStatus" != "" -a "$Act_valueRangeStatus" = "" ]; then
				totMemRangeVal1=`echo "$total_memory" | cut -d"-" -f1`
				totMemRangeVal2=`echo "$total_memory" | cut -d"-" -f2`
				if [ "$totMem_unit" = "" ]; then
					nVal1=`AddMGwithUnitVal "${totMemRangeVal1}MB" $Act_value`
				else
					nVal1=`AddMGwithUnitVal "${totMemRangeVal1}GB" $Act_value`
				fi
				nVal2=`AddMGwithUnitVal $totMemRangeVal2 $Act_value`
				total_memory=`echo "$nVal1-$nVal2"`
				total_memory=`echo "$nVal1-${nVal2}GB"`
			elif [ "$totMemRangeStatus" != "" -a "$Act_valueRangeStatus" != "" ]; then
				Act_valueRangeVal1=`echo "$Act_value" | cut -d"-" -f1`
                                Act_valueRangeVal2=`echo "$Act_value" | cut -d"-" -f2`

				totMemRangeVal1=`echo "$total_memory" | cut -d"-" -f1`
                                totMemRangeVal2=`echo "$total_memory" | cut -d"-" -f2`

				if [ "$tt_unit" = "" ]; then
					if [ "$totMem_unit" = "" ]; then
						ntVal1=`AddMGwithUnitVal "${totMemRangeVal1}MB" "${Act_valueRangeVal1}MB"`
						ntVal2=`AddMGwithUnitVal "${totMemRangeVal2}MB" "${Act_valueRangeVal2}MB"`
					else
						ntVal1=`AddMGwithUnitVal "${totMemRangeVal1}GB" "${Act_valueRangeVal1}MB"`
						ntVal2=`AddMGwithUnitVal "${totMemRangeVal2}GB" "${Act_valueRangeVal2}MB"`
					fi
                                else
					if [ "$totMem_unit" = "" ]; then
						ntVal1=`AddMGwithUnitVal "${totMemRangeVal1}MB" "${Act_valueRangeVal1}GB"`
						ntVal2=`AddMGwithUnitVal "${totMemRangeVal2}MB" "${Act_valueRangeVal2}GB"`
					else
						ntVal1=`AddMGwithUnitVal "${totMemRangeVal1}GB" "${Act_valueRangeVal1}GB"`
						ntVal2=`AddMGwithUnitVal "${totMemRangeVal2}GB" "${Act_valueRangeVal2}GB"`
					fi
                                fi
				total_memory=`echo "$ntVal1-${ntVal2}GB"`
			fi
		elif [ "$item" = "$TDISK" ]; then
			          	if [ "$total_disk" = "0" ]; then
                                total_disk="0MB"
                        fi
                        totDiskRangeStatus=`echo "$total_disk" | grep "-"`
                        Act_valueRangeStatus=`echo "$Act_value" | grep "-"`
                        totDisk_unit=`echo "$total_disk" | grep "GB"`
                        tt_unit=`echo "$Act_value" | grep "GB"`
                        if [ "$totDiskRangeStatus" = "" -a "$Act_valueRangeStatus" = "" ]; then
                                total_disk=`AddMG $total_disk $value`
                                if [ "$tt_unit" = "" ]; then
                                        total_disk=`echo "${total_disk}MB"`
                                else
                                        total_disk=`echo "${total_disk}GB"`
                                fi
                        elif [ "$totDiskRangeStatus" = "" -a "$Act_valueRangeStatus" != "" ]; then
                                Act_valueRangeVal1=`echo "$Act_value" | cut -d"-" -f1`
                                Act_valueRangeVal2=`echo "$Act_value" | cut -d"-" -f2`
                                if [ "$tt_unit" = "" ]; then
                                        tVal1=`AddMGwithUnitVal $total_disk "${Act_valueRangeVal1}MB"`
                                else
                                        tVal1=`AddMGwithUnitVal $total_disk "${Act_valueRangeVal1}GB"`
                                fi
                                tVal2=`AddMGwithUnitVal $total_disk $Act_valueRangeVal2`
                                total_disk=`echo "$tVal1-${tVal2}GB"`
                        elif [ "$totDiskRangeStatus" != "" -a "$Act_valueRangeStatus" = "" ]; then
                                totDiskRangeVal1=`echo "$total_disk" | cut -d"-" -f1`
                                totDiskRangeVal2=`echo "$total_disk" | cut -d"-" -f2`
                                if [ "$totDisk_unit" = "" ]; then
                                        nVal1=`AddMGwithUnitVal "${totDiskRangeVal1}MB" $Act_value`
                                else
                                        nVal1=`AddMGwithUnitVal "${totDiskRangeVal1}GB" $Act_value`
                                fi
                                nVal2=`AddMGwithUnitVal $totDiskRangeVal2 $Act_value`
                                total_disk=`echo "$nVal1-$nVal2"`
                                total_disk=`echo "$nVal1-${nVal2}GB"`
                        elif [ "$totDiskRangeStatus" != "" -a "$Act_valueRangeStatus" != "" ]; then
                                Act_valueRangeVal1=`echo "$Act_value" | cut -d"-" -f1`
                                Act_valueRangeVal2=`echo "$Act_value" | cut -d"-" -f2`

                                totDiskRangeVal1=`echo "$total_disk" | cut -d"-" -f1`
                                totDiskRangeVal2=`echo "$total_disk" | cut -d"-" -f2`

                                if [ "$tt_unit" = "" ]; then
                                        if [ "$totDisk_unit" = "" ]; then
                                                ntVal1=`AddMGwithUnitVal "${totDiskRangeVal1}MB" "${Act_valueRangeVal1}MB"`
                                                ntVal2=`AddMGwithUnitVal "${totDiskRangeVal2}MB" "${Act_valueRangeVal2}MB"`
                                        else
                                                ntVal1=`AddMGwithUnitVal "${totDiskRangeVal1}GB" "${Act_valueRangeVal1}MB"`
                                                ntVal2=`AddMGwithUnitVal "${totDiskRangeVal2}GB" "${Act_valueRangeVal2}MB"`
                                        fi
                                else
                                        if [ "$totDisk_unit" = "" ]; then
                                                ntVal1=`AddMGwithUnitVal "${totDiskRangeVal1}MB" "${Act_valueRangeVal1}GB"`
                                                ntVal2=`AddMGwithUnitVal "${totDiskRangeVal2}MB" "${Act_valueRangeVal2}GB"`
                                        else
                                                ntVal1=`AddMGwithUnitVal "${totDiskRangeVal1}GB" "${Act_valueRangeVal1}GB"`
                                                ntVal2=`AddMGwithUnitVal "${totDiskRangeVal2}GB" "${Act_valueRangeVal2}GB"`
                                        fi
                                fi
                                total_disk=`echo "$ntVal1-${ntVal2}GB"`
                        fi
		fi

                ###Checking for Os.ulimit####
                IsUlimitFound=`echo $item | grep "ulimit"`
                if [ $IsUlimitFound ]; then
                      if [ "$value" != "Available" ]; then
                        limit=`echo $value | cut -d '[' -f2 | cut -d ']' -f1 | cut -d ':' -f2`
                        item=$item.$limit
                        fi
                fi

		tmpItem=`echo $item | sed -e 's/\[[^)]*\]//'`
		logDebug "Removing the [] contents from the $item"
		#Modify the "os.package" lines in a rstfile
		#modify lines containing "gtk[0-8].i686" line to "gtk.i686"

		cat $rstfile | grep "os.package" > $TMP_DIR/ospackagelines.txt
		cat $rstfile | grep -v "os.package" > $TMP_DIR/nonospackagelines.txt
		cat $TMP_DIR/ospackagelines.txt | sed -e "s/\(\[[^]]*]\)//" >> $TMP_DIR/nonospackagelines.txt

		rm -rf $rstfile 2>/dev/null
		cat $TMP_DIR/nonospackagelines.txt > $rstfile

		rstvalue=`cat $rstfile | grep "$tmpItem=" | tail -1 | cut -d= -f2`
		logDebug "rstvalue=$rstvalue"

		  tmp_item=`echo $item | sed "s/ /_/g" | sed  's/\[/\*/' | sed 's/\]/\*/'`
                  lenrstvalue=`cat $rstfile | grep -c "$tmp_item"`
                   if [ $lenrstvalue -gt 1 ]; then
         	      rstvalue=`echo $rstvalue | awk '{print $1}'`
                   fi

                      if [ -n "$rstvalue" ]; then
			# compare, it's the compare between $value and $rstvalue
			# $value is from configuration file
			# $rstvalue is from result file
			# if there exists user defined comparison file, use it
			# else use the compare function
			
			ridcode=`echo $code | sed "s/ /_/g"`
			riditem=`echo $item | sed "s/ /_/g" | sed  's/\[/\*/' | sed 's/\]/\*/'`
			ls "$CFGHOME"/"$ridcode"_*$riditem*_compare* > $TMP_DIR/tmpFileHolder 2>/dev/null

			comparefile=`cat $TMP_DIR/tmpFileHolder | sed "s;${CFGHOME};\.;" | sed 's/^..//' | sort -ir | sed -n "1p"` 
			logDebug "compare file name $comparefile"
			if [ -z "$comparefile" ]; then
				ls "$CFGHOME"/$riditem*_compare* > $TMP_DIR/tmpFileHolder 2>/dev/null
				comparefile=`cat $TMP_DIR/tmpFileHolder  | sed "s;${CFGHOME};\.;" | sed 's/^..//' | sort -ir | sed -n "1p"` 
				logDebug "compare file name $comparefile"
				GetEnvVar=`echo "$riditem" | grep "env.var.set"`
				logDebug "GetEnvVar=$GetEnvVar"
				if [ $GetEnvVar ]; then 
					comparefile=`ls "$CFGHOME"/env.var.set_compare* 2>/dev/null  | sed "s;${CFGHOME};\.;" | sed 's/^..//' | sort -ir | sed -n "1p"` 
				fi
				GetEnvVar=`echo "$riditem" | grep "env.JRE.version"`
				logDebug "look for env.JRE.version_compare GetEnvVar=$GetEnvVar"
				if [ $GetEnvVar ]; then 
					comparefile=`ls "$CFGHOME"/env.JRE.version_compare* 2>/dev/null  | sed "s;${CFGHOME};\.;" | sed 's/^..//' | sort -ir | sed -n "1p"` 
				fi
			fi
                        #echo $comparefile		
			if [ -n "$comparefile" ]; then
				logDebug "[$comparefile] used as comparison for [$item] of [$codename]"
				eval "cd $CFGHOME;chmod +x \"$comparefile\";"
			
                                PackageName=""
                                ISPackageFound=`echo $item | grep "os.package"`
                                if [ "$ISPackageFound" != "" ]; then
                                    PackageName=`echo $item | cut -d'.' -f3-`
                                    #echo $PackageName
                                 fi
                                
                          	CompareRetVal=`$PREREQ_HOME/UNIX_Linux/$comparefile "$rstvalue" "$Act_value" "$PackageName"`	
				CompareStatusPASS=`echo "$CompareRetVal" | grep -i "$PASS_STR"`
				CompareStatusWARN=`echo "$CompareRetVal" | grep -i "$WARN_STR"`
				if [ "$CompareStatusPASS" != "" ]; then
					r="$PASS_STR"
				elif [ "$CompareStatusWARN" != "" ]; then
					r="$WARN_STR"
				else
					r="$FAIL_STR"
				fi
				cd ..
			else
			         if [ "$rstvalue" = "NFS_NOT_AVAILABLE" -o "$rstvalue" = "NOT_A_VALID_PATH" -o "$rstvalue" = "Not Found" ]; then
                                 r="$FAIL_STR"
                                else
                                  if [ $xlCFlag = "False" ]; then
										Hz_rstvalue=`echo "$rstvalue" | grep "Hz$"`
                                        if [ "$Hz_rstvalue" ]; then
                                        		logDebug "[Hz_compare()] used as comparison for [$rstvalue] of [$value]"
                                                r=`Hz_compare "$rstvalue" "$value"`
                                        else
                                                logDebug "[compare()] used as comparison for [$item] of [$codename]"
                                                r=`compare "$rstvalue" "$value"`
                                        fi
                                   fi 
		                fi
                	fi

			logDebug "    [$r] $item expect $value while get $rstvalue"
			if [ "$ShortArgFlag" = "True" ]; then
			    if [ "$r" != "PASS" ]; then
					if [ "$Consolesubhead" = "TRUE" ]; then
						if [ "$subhead" = "TRUE" ]; then
							myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR " >> $TMP_DIR/$rep
							myprintf "$patt" "========" "======"  "=====" '========= ' >> $TMP_DIR/$rep
						fi
						if [ ! "$aaaa" = "0" ]; then
							smyprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR"
							smyprintf "$patt" "========" "======"  "=====" '========'
						fi
						subhead="FALSE"
						Consolesubhead="FALSE"
					fi
					mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
					if [ "$mord" = "" ]; then
						###Checking for Ulimit values####
						 IsUlimitFound=`echo $item | grep "ulimit"`
						 if [ $IsUlimitFound ]; then
							item=`echo "$item" | cut -d '.' -f1-2`
						 fi
						NewTmpConfigFile="$TMP_DIR/TMP_${tmpcfg}.cfg"
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
						myprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value" >> $TMP_DIR/$rep
					else
						rstvalue=`changeMG "$rstvalue"`
						value=`changeMG "$value"`
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
						myprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value" >> $TMP_DIR/$rep
					fi
					if [ ! "$aaaa" = "0" ]; then
						mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
						if [ "$mord" = "" ]; then
							r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
							smyprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value" 
						else
							rstvalue=`changeMG "$rstvalue"`
							value=`changeMG "$value"`
							r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
							smyprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value"
						fi
					fi
			    else
                                if [ "$subhead" = "TRUE" ]; then
                                        myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR " >> $TMP_DIR/$rep
                                        myprintf "$patt" "========" "======"  "=====" '========= ' >> $TMP_DIR/$rep
                                        subhead="FALSE"
                                fi
				mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
				if [ "$mord" = "" ]; then
					###Checking for Ulimit values####
					 IsUlimitFound=`echo $item | grep "ulimit"`
					 if [ $IsUlimitFound ]; then
						item=`echo "$item" | cut -d '.' -f1-2`
					 fi
					NewTmpConfigFile="$TMP_DIR/TMP_${tmpcfg}.cfg"
					r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
					myprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value" >> $TMP_DIR/$rep
				else
					rstvalue=`changeMG "$rstvalue"`
					value=`changeMG "$value"`
					r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
					myprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value" >> $TMP_DIR/$rep
				fi
			    fi
			else
				if [ "$subhead" = "TRUE" ]; then
					myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR " >> $TMP_DIR/$rep
					myprintf "$patt" "========" "======"  "=====" '========= ' >> $TMP_DIR/$rep
					if [ ! "$aaaa" = "0" ]; then
						smyprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR"
						smyprintf "$patt" "========" "======"  "=====" '========'
					fi
					subhead="FALSE"
				fi
					mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
					if [ "$mord" = "" ]; then
						###Checking for Ulimit values####
						 IsUlimitFound=`echo $item | grep "ulimit"`
						 if [ $IsUlimitFound ]; then
							item=`echo "$item" | cut -d '.' -f1-2`
						 fi
						NewTmpConfigFile="$TMP_DIR/TMP_${tmpcfg}.cfg"
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
						myprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value" >> $TMP_DIR/$rep
					else
						rstvalue=`changeMG "$rstvalue"`
						value=`changeMG "$value"`
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
						myprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value" >> $TMP_DIR/$rep
					fi
				if [ ! "$aaaa" = "0" ]; then
					mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
					if [ "$mord" = "" ]; then
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
						smyprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value" 
					else
						rstvalue=`changeMG "$rstvalue"`
						value=`changeMG "$value"`
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "$rstvalue" "$Act_value"`
						smyprintf "$patt" "$item" "$r" "$rstvalue" "$Act_value"
					fi
				fi
			fi
		else
			if [ "$ShortArgFlag" = "True" ]; then
			     if [ "$r" != "PASS" ]; then
				if [ "$subhead" = "TRUE" ]; then
					myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR " >> $TMP_DIR/$rep
					myprintf "$patt" "========" "======"  "=====" '========= ' >> $TMP_DIR/$rep
					if [ ! "$aaaa" = "0" ]; then
						smyprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR"
						smyprintf "$patt" "========" "======"  "=====" '========'
					fi
					subhead="FALSE"
				fi
				ss=`echo $item | grep -i "cpu"`
				if [ -z "$ss" ];then
					logWarning "it's empty for  $item"
					mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
					if [ "$mord" = "" ]; then
					 check=`echo $item | cut -c 1`

					if [ "$item" != "Connectivity" ]; then
					     if [  "$check" != "#" ]; then
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$Act_value"`
						myprintf "$patt" "$item" "$r" "[Not Found]" "$value" >> $TMP_DIR/$rep
					    fi
					fi
				else
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$value"`
						myprintf "$patt" "$item" "$r" "[Not Found]" `changeMG "$value"` >> $TMP_DIR/$rep
					fi
					if [ ! "$aaaa" = "0" ]; then
						mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
						if [ "$mord" = "" ]; then
							r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$Act_value"`
							smyprintf "$patt" "$item" "$r" "[Not Found]" "$Act_value"
						else
							r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$value"`
							smyprintf "$patt" "$item" "$r" "[Not Found]" `changeMG "$value"`
						fi
					fi
				fi
			    else
                                if [ "$subhead" = "TRUE" ]; then
                                        myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR " >> $TMP_DIR/$rep
                                        myprintf "$patt" "========" "======"  "=====" '========= ' >> $TMP_DIR/$rep
                                        subhead="FALSE"
                                fi
                                ss=`echo $item | grep -i "cpu"`
                                if [ -z "$ss" ];then
                                        logWarning "it's empty for  $item"
                                        mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
                                        if [ "$mord" = "" ]; then
						check=`echo $item | cut -c 1`

						if [ "$item" != "Connectivity" ]; then
						     if [  "$check" != "#" ]; then
							r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$Act_value"`
							myprintf "$patt" "$item" "$r" "[Not Found]" "$value" >> $TMP_DIR/$rep
						    fi
						fi
					else
                                                r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$value"`
                                                myprintf "$patt" "$item" "$r" "[Not Found]" `changeMG "$value"` >> $TMP_DIR/$rep
                                        fi
                                fi
			    fi
			else
				if [ "$subhead" = "TRUE" ]; then
					myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR " >> $TMP_DIR/$rep
					myprintf "$patt" "========" "======"  "=====" '========= ' >> $TMP_DIR/$rep
					if [ ! "$aaaa" = "0" ]; then
						smyprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR"
						smyprintf "$patt" "========" "======"  "=====" '========'
					fi
					subhead="FALSE"
				fi
				ss=`echo $item | grep -i "cpu"`
				if [ -z "$ss" ];then
					logWarning "it's empty for  $item"
					mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
					if [ "$mord" = "" ]; then
					 check=`echo $item | cut -c 1`

					if [ "$item" != "Connectivity" ]; then
					     if [  "$check" != "#" ]; then
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$Act_value"`
						myprintf "$patt" "$item" "$r" "[Not Found]" "$value" >> $TMP_DIR/$rep
					    fi
					fi
				else
						r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$value"`
						myprintf "$patt" "$item" "$r" "[Not Found]" `changeMG "$value"` >> $TMP_DIR/$rep
					fi
					if [ ! "$aaaa" = "0" ]; then
						mord=`echo "$item" | awk '{if($1 ~  /Memory/){print $1}if($1 ~ /Disk/){print $1}}'`
						if [ "$mord" = "" ]; then
							r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$Act_value"`
							smyprintf "$patt" "$item" "$r" "[Not Found]" "$Act_value"
						else
							r=`CheckSeverityOfProperty "$r" "$item" "$tmpcfg" "[Not Found]" "$value"`
							smyprintf "$patt" "$item" "$r" "[Not Found]" `changeMG "$value"`
						fi
					fi
				fi
			fi
                fi
                IFS== 
	done
	exec 0<&4
	IFS=$OLDIFS
	# Commeting this function for the time being, this needs to be implemented later
	#Refer Task 31970 for More Details
	#Keep the copy of the rep file
	logDebug "keep the copy of the Result file before going in the loop"
	cat $TMP_DIR/$rep > $TMP_DIR/tmp1_$rep

	if [ "`cat $TMP_DIR/$rep | grep "$FAIL_STR"`" != "" ]; then
	#grep "FAIL" $TMP_DIR/$rep > /dev/null 2>&1
	#if [ $? -eq 0 ]; then
		echo "$code $version: $FAIL_STR" >> $TMP_DIR/result_$rep
		logDebug "Overall Result of the product code $code is FAILED"
	elif [ "`cat $TMP_DIR/$rep | grep "$WARN_STR"`" != "" ]; then
		echo "$code $version: $WARNING_STR" >> $TMP_DIR/result_$rep
                logDebug "Overall Result of the product code $code is FAILED"
	else
		echo "$code $version: $PASS_STR" >> $TMP_DIR/result_$rep
		logDebug "Overall Result of the product code $code is PASSED"
	fi
	
	 
	printf "\n" >> $TMP_DIR/$rep
			if [ ! "$aaaa" = "0" ]; then
				printf "\n"
			fi
	ElementAsItIs "	</DetailedProductResultsElement>"
done
exec 0<&4
#For BUG 141808

ElementAsItIs "    </DetailedResults>"
mv $TMP_DIR/tmp_$rep $TMP_DIR/$rep 2>/dev/null
cat $TMP_DIR/tmp1_$rep >> $TMP_DIR/$rep 2>/dev/null

# to sort the path
# if the agent want to collect space on another path, it does contains in his product code .txt in temp
totaltf="$tempd/disk_total_temp"
totalsw="$tempd/disk_total_swap"
totalre="$tempd/disk_total_rest"
IP_Fs_Mounts="$tempd/Filesystems_list"
###This is for Adding the Disk value to total according to the Configuration value###
ref_product_version=`echo $product_version | sed 's/ /+/g'`
for Arg in `echo "$ref_product_version" | tr "," " "`
do
        cfgval=`echo $Arg | cut -d '+' -f1`

        total_disk_unitGB=`echo "$total_disk" | grep "GB"`
        total_disk_unitMB=`echo "$total_disk" | grep "MB"`

        if [ "$total_disk_unitGB" != "" ]; then
                echo `mes4Path $spath`" $total_disk" `cat $TMP_DIR/$rescommon | grep $TDISK | cut -d= -f2` > $totaltf
        elif [ "$total_disk_unitMB" != "" ]; then
                echo `mes4Path $spath`" $total_disk" `cat $TMP_DIR/$rescommon | grep $TDISK | cut -d= -f2` > $totaltf
        else
                echo `mes4Path $spath`" $total_disk""GB" `cat $TMP_DIR/$rescommon | grep $TDISK | cut -d= -f2` > $totaltf
        fi
done


for ftotal in `echo $deliverPara | tr "," "\n"`
do
	# parse the deliver parameters, it should contains value, key and product code
	pval=`echo $ftotal | awk -F= '{print $2}' | sed -n '/^\//p'`
	if [ -n "$pval" ]; then
		pkey=`echo $ftotal | awk -F= '{print $1}'`
		#pd_pkey=`echo "$pkey" | sed 's/\(^[a-zA-Z0-9]\{3,3\}\)\..*/\1/g'`
                pd_pkey=`echo "$pkey" | tr "." "\n" | sed -n '1p'`
                #nm_pkey=`echo "$pkey" | sed "s/$pd_pkey\.//g"`
                nm_pkey=`echo "$pkey" |  tr "." "\n" | sed -n '2p'`


		# find the result value and total value
		ff_want=`ls $tempd | grep -i "$pd_pkey" | grep -i .cfg`
		pp_want=`cat $tempd/$ff_want | grep "^$nm_pkey" | cut -d= -f2`


		ff_result=`ls $tempd | grep -i "$pd_pkey" | grep -i .txt`
		pp_result=`cat $tempd/$ff_result | grep "^$nm_pkey" | cut -d= -f2`
		echo `mes4Path "$pval"`" $pp_want $pp_result" >> $totaltf
		echo `mes4Path1 "$pval"`" $pp_want $pp_result" >> $IP_Fs_Mounts
	fi 
done
#####This is for Adding the Disk Value for TOTAL SPECIFIED COMPONENTS#######
if [ "`uname`" = "SunOS" ]; then
	if [ -f $tempd/$ff_want ]; then
		pp_want_disk=`cat $tempd/$ff_want | grep "Disk" | cut -d= -f2` 2>/dev/null
		pp_result_disk=`cat $tempd/$ff_result | grep "Disk" | cut -d= -f2` 2>/dev/null
		echo `mes4Path1 "$spath"`" $pp_want_disk $pp_result_disk" >>$IP_Fs_Mounts
		logDebug "pp_want_disk=$pp_want_disk ** pp_result_disk=$pp_result_disk"
	fi
fi
#####For Adding the Os.space values to temp/disk_total_temp file for getting consolidated calculations ####
logDebug "Adding the Os.space values to temp/disk_total_temp file for getting consolidated calculations"
DirAdd $PREREQ_HOME
####END OF THE SECTION######
# Remove the char's start with space till hyphen, Ex "/tmp 60-90GB" -> "/tmp 90GB" for range values
sort $totaltf  > $totalsw
mv $totalsw $totaltf

# NOT REQ entries are been removed from the totaltf file as the total component shuld not display results RTC Defect 26220
logDebug "remove the NOT_REQ_CHECK_ID's from the total components "
cat  $totaltf | grep -v NOT_REQ_CHECK_ID > $totalsw
mv $totalsw $totaltf


# calculate the disks
if [ -f "$totalre" ]; then
	rm -f $totalre
fi
touch $totalre
for naa in `cat $totaltf | awk '{print $1}' | sort | uniq`
do
		echo $naa > $totalsw
		tttttt="0G"
        for nbb in `join $totaltf $totalsw | awk '{print $2}'`
        do
		nbbRangeStatus=`echo "$nbb" | grep "-"`
                ttttttRangeStatus=`echo "$tttttt" | grep "-"`
                nbb_unit=`echo "$nbb" | grep "GB"`
                tt_unit=`echo "$tttttt" | grep "GB"`
                if [ "$nbbRangeStatus" = "" -a "$ttttttRangeStatus" = "" ]; then
                        tttttt=`AddMG $nbb $tttttt`
                elif [ "$nbbRangeStatus" != "" -a "$ttttttRangeStatus" = "" ]; then
			if [ "$nbb_unit" = "" ]; then
				nbbRangeVal1=`echo "$nbb" | cut -d"-" -f1 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g'`
				nbbRangeVal2=`echo "$nbb" | cut -d"-" -f2 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g'`
				ConnbbVal1=`Convert_MB_to_GB "${nbbRangeVal1}MB"`
				ConnbbVal2=`Convert_MB_to_GB "${nbbRangeVal2}MB"`
			else
				nbbRangeVal1=`echo "$nbb" | cut -d"-" -f1 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g'`
                                nbbRangeVal2=`echo "$nbb" | cut -d"-" -f2 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g'`
                                ConnbbVal1="${nbbRangeVal1}"
                                ConnbbVal2="${nbbRangeVal2}"
			fi
			nVal1=`AddMGwithUnitVal "${ConnbbVal1}GB" $tttttt`
			nVal2=`AddMGwithUnitVal "${ConnbbVal2}GB" $tttttt`
			tttttt=`echo "${nVal1}-${nVal2}"`
                elif [ "$nbbRangeStatus" = "" -a "$ttttttRangeStatus" != "" ]; then
			#Asuming tttttt value is always in GB's
			ContVal1=`echo "$tttttt" | cut -d"-" -f1 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g' | sed 's/G//g'`
			ContVal2=`echo "$tttttt" | cut -d"-" -f2 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g' | sed 's/G//g'`
			tVal1=`AddMGwithUnitVal "${ContVal1}GB" "$nbb"`
			tVal2=`AddMGwithUnitVal "${ContVal2}GB" "$nbb"`
			tttttt=`echo "${tVal1}-${tVal2}"`
		elif [ "$nbbRangeStatus" != "" -a "$ttttttRangeStatus" != "" ]; then
			if [ "$nbb_unit" = "" ]; then
                                nbbRangeVal1=`echo "$nbb" | cut -d"-" -f1 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g'`
                                nbbRangeVal2=`echo "$nbb" | cut -d"-" -f2 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g'`
                                ConnbbVal1=`Convert_MB_to_GB "${nbbRangeVal1}MB"`
                                ConnbbVal2=`Convert_MB_to_GB "${nbbRangeVal2}MB"`
                        else
                                nbbRangeVal1=`echo "$nbb" | cut -d"-" -f1 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g'`
                                nbbRangeVal2=`echo "$nbb" | cut -d"-" -f2 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g'`
                                ConnbbVal1="${nbbRangeVal1}"
                                ConnbbVal2="${nbbRangeVal2}"
                        fi
			#Asuming tttttt value is always in GB's
                        ContVal1=`echo "$tttttt" | cut -d"-" -f1 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g' | sed 's/G//g'`
                        ContVal2=`echo "$tttttt" | cut -d"-" -f2 | sed 's/unit=//g' | sed 's/GB//g' | sed 's/MB//g' | sed 's/G//g'`

			nbbtVal1=`AddMGwithUnitVal "${ContVal1}GB" "${ConnbbVal1}GB"`
			nbbtVal2=`AddMGwithUnitVal "${ContVal2}GB" "${ConnbbVal2}GB"`
			tttttt=`echo "${nbbtVal1}-${nbbtVal2}"`
                fi
        done

	echo "$naa $tttttt""GB "`join $totaltf $totalsw | sed -n '1p' | awk '{print $3}'` >> $totalre
done

# For Zfs Fix 
#======================
istep="1"
numbertotal=`wc -l $totalre | awk '{print $1}'`

while [ $istep -le $numbertotal ]
do
	rstdisk=`cat $totalre | sed -n "$istep""p" | awk '{print $3}'`
	total_disk=`cat $totalre | sed -n "$istep""p" | awk '{print $2}'`
	echo "$rstdisk $total_disk" >> $TMP_DIR/disk_sac1 
	istep=`expr $istep + 1`
done

istep="1"
numbertotal=`wc -l $totalre | awk '{print $1}'`
check_zpool=False

xmlFlag=$Overall_Result

while [ $istep -le $numbertotal ]
do
        rstdisk=`cat $totalre | sed -n "$istep""p" | awk '{print $3}'`
        total_disk=`cat $totalre | sed -n "$istep""p" | awk '{print $2}'`
        totalpat=`cat $totalre | sed -n "$istep""p" | awk '{print $1}'`
	logDebug "rstdisk=$rstdisk ** total_disk=$total_disk ** totalpat"

if [ "`uname`" = "SunOS" ]; then
	zfslist="$tempd/Zfs_filesystems"

	#For fixing the issue with "zpool"command in Solaris 10 and above
	IsOracleSolaris=`cat /etc/release |grep -i oracle`
	if [ "$IsOracleSolaris" = "" ]; then
		solaris_version=`cat /etc/release |grep Solaris | head -1 | nawk -F " " '{print $2}'`
	else
		solaris_version=`cat /etc/release |grep Solaris | head -1 | nawk -F " " '{print $3}'`
	fi

    # Currently we are not supporting checking zfile system
    # Based on requirement from the adaptor team will support this functionlity
    # Commented based on the defect 39262
    #if [ $solaris_version -ge 10 ]; then
	if [ $solaris_version -gt 11 ]; then
                #zpool status >/dev/null
		ZpoolcmdFound=`which zpool 2>/dev/null | cut -d " " -f1`
		if [ $ZpoolcmdFound != "no" ]; then
                        check_zpool=`zpool status | grep state | cut -d':' -f2 | uniq`
        
			#Getting the Zpool Variable & Getting the Zfs filesystems

        		Zpools=`zpool list | awk '{print $1}'| sed '1d'`
        		Zfs_mounts=`zfs list | awk '{print $5}' | sed '1d' | sed '/-/d'`
        		for line in $Zfs_mounts 
        		do
                		FirstChar=`echo $line | cut -c 1`
                		if [ "$FirstChar" = "/" ]; then
                        		zfs list $line | sed '1d' | nawk '{print $1}' >> $zfslist 2>/dev/null
                		fi
        		done
		fi
	fi
fi
 
 if [ "$check_zpool" = " ONLINE" ]; then

        check_istep=1
        fs=`df -k "$totalpat" | sed '1d' | awk '{print $1}'`
        Validate_zfs=`grep "$fs" $zfslist | sed -n '1p' | cut -c 1-3`
        if [ $Validate_zfs ]; then
		fs1=`echo $fs | nawk -F "/" '{print $1}'`
		Total="0G"
			touch $TMP_DIR/Sorted_IP_Fs_Mounts
			for Zpool in $Zpools 
			do
				if [ -s $IP_Fs_Mounts ]; then	
					grep -i "$Zpool" $IP_Fs_Mounts | sed 's/'$Zpool'\//'$Zpool' \//g' | sort  > $TMP_DIR/Sorted_IP_Fs_Mounts
				fi
				echo $fs1 > $TMP_DIR/temp3
                               	for Fsize in `join $TMP_DIR/Sorted_IP_Fs_Mounts $TMP_DIR/temp3 | sed 's/'$Zpool' \//'$Zpool'\//g' | awk '{print $2}'`
                               	do
                                	Total=`AddMG $Fsize $Total`
                               	done
			done
                                total_disk=$Total"GB"
				check_istep=`expr $check_istep + 1`

        else
                	for Fsystem in $fs 
                	do
                        	if [ -s $IP_Fs_Mounts ]; then	
					cat $IP_Fs_Mounts | sort > $TMP_DIR/Sorted_IP_Fs_Mounts
				fi
                        	Total="0G"
                        	echo $Fsystem > $TMP_DIR/temp5
                        	for Fsize in `join $TMP_DIR/Sorted_IP_Fs_Mounts $TMP_DIR/temp5 | awk '{print $2}'`
                        	do
                                	Total=`AddMG $Fsize $Total`
                        	done
                                	total_disk=$Total"GB"
                	done

        fi

 fi
        tot_diskRangeStatus=`echo "$total_disk" | grep "-"`
        if [ "$tot_diskRangeStatus" = "" ]; then
                ifTotalDiskZero=`changeMG $total_disk`
        else
                tot_disk_unit=`echo "$total_disk" | grep "GB"`
                tot_diskVal1=`echo "$total_disk" | cut -d"-" -f1`
                tot_diskVal2=`echo "$total_disk" | cut -d"-" -f2`
                if [ "$tot_disk_unit" = "" ]; then
                        ifTotalDiskVal1=`changeMG_GB "${tot_diskVal1}MB"`
                        ifTotalDiskVal2=`changeMG $tot_diskVal2`
                else
                        type=`uname`
                        if [ "$type" = "SunOS" ]; then
                                ifTotalDiskVal1=`echo "${tot_diskVal1}GB" | nawk '{printf "%.2f", $1}'`
                                ifTotalDiskVal2=`echo "${tot_diskVal2}GB" | nawk '{printf "%.2f", $1}'`
                        else
                                ifTotalDiskVal1=`echo "${tot_diskVal1}GB" | awk '{printf "%.2f", $1}'`
                                ifTotalDiskVal2=`echo "${tot_diskVal2}GB" | awk '{printf "%.2f", $1}'`
                        fi
                fi

                ifTotalDiskVal1=`echo "$ifTotalDiskVal1" | sed 's/GB//g' | sed 's/MB//g'`
				ifTotalDiskVal2=`echo "$ifTotalDiskVal2" | sed 's/GB//g' | sed 's/MB//g'`
                ifTotalDiskZero=`echo "${ifTotalDiskVal1}-${ifTotalDiskVal2}GB"`
        fi
        if [ "$ifTotalDiskZero" = "0MB" -o "$ifTotalDiskZero" = "0M" ]; then
                ifTotalDiskZero="N\/A"
		TotalComp=$True
	else
		TotalComp=$False
        fi
	if [ $TotalComp -eq $False ]; then
		aggRange=`echo "$total_disk" | grep "-"`
		if [ "$aggRange" = "" ]; then
			aggResult=`compare $rstdisk $total_disk`
		else
			aggResult=`CompareRangeValues "$rstdisk" "$total_disk"`
		fi		
		if [ "$ShortArgFlag" = "True" ]; then
		     if [ "$aggResult" != "PASS" ]; then
			# Print Only Once 
			if [ $LoopCount -eq 0 ]; then 
				# deal the total memory and disk
				ElementAsItIs "    <AggregatedResults>"
				printf "\n" >> $TMP_DIR/$rep
				printf "$ALL_COMPONENTS_STR:\n" >> $TMP_DIR/$rep
				#printf "\n" >> $TMP_DIR/$rep
				if [ ! "$aaaa" = "0" ]; then
					printf "$ALL_COMPONENTS_STR:\n"
				fi
				myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR">> $TMP_DIR/$rep
				myprintf "$patt" "========" "======"  "=====" '========'>> $TMP_DIR/$rep
				if [ ! "$aaaa" = "0" ]; then
					smyprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR"
					smyprintf "$patt" "========" "======"  "=====" '========'
				fi
			fi
			if [ ! "$aaaa" = "0" ]; then
				if [ "$rstdisk" = "NotAvailable" ]; then
					smyprintf "$patt" "$totalpat" "$Msg_FAIL" `changeMG $rstdisk` $ifTotalDiskZero
				else
					smyprintf "$patt" "$totalpat" "$aggResult"  `changeMG $rstdisk` $ifTotalDiskZero
				fi
			fi
			LoopCount=1
			myprintf "$patt" "$totalpat" "$aggResult"  `changeMG $rstdisk` $ifTotalDiskZero >> $TMP_DIR/$rep
		    else
                        if [ $LoopCount -eq 0 ]; then
                                # deal the total memory and disk
                                ElementAsItIs "    <AggregatedResults>"
                                printf "\n" >> $TMP_DIR/$rep
                                printf "$ALL_COMPONENTS_STR:\n" >> $TMP_DIR/$rep
                                #printf "\n" >> $TMP_DIR/$rep
                                myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR">> $TMP_DIR/$rep
                                myprintf "$patt" "========" "======"  "=====" '========'>> $TMP_DIR/$rep
                        fi
                        LoopCount=1
                        myprintf "$patt" "$totalpat" "$aggResult"  `changeMG $rstdisk` $ifTotalDiskZero >> $TMP_DIR/$rep
		    fi
		else
			# Print Only Once 
			if [ $LoopCount -eq 0 ]; then 
				# deal the total memory and disk
				ElementAsItIs "    <AggregatedResults>"
				printf "\n" >> $TMP_DIR/$rep
				printf "$ALL_COMPONENTS_STR:\n" >> $TMP_DIR/$rep
				#printf "\n" >> $TMP_DIR/$rep
				if [ ! "$aaaa" = "0" ]; then
					printf "$ALL_COMPONENTS_STR:\n"
				fi
				myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR">> $TMP_DIR/$rep
				myprintf "$patt" "========" "======"  "=====" '========'>> $TMP_DIR/$rep
				if [ ! "$aaaa" = "0" ]; then
					smyprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR"
					smyprintf "$patt" "========" "======"  "=====" '========'
				fi
			fi
			if [ ! "$aaaa" = "0" ]; then
                                if [ "$rstdisk" = "NotAvailable" ]; then
                                        smyprintf "$patt" "$totalpat" "$Msg_FAIL" `changeMG $rstdisk` $ifTotalDiskZero
                                else
                                        smyprintf "$patt" "$totalpat" "$aggResult"  `changeMG $rstdisk` $ifTotalDiskZero
                                fi
                        fi
                        LoopCount=1
                        myprintf "$patt" "$totalpat" "$aggResult"  `changeMG $rstdisk` $ifTotalDiskZero >> $TMP_DIR/$rep
		fi
	fi
        istep=`expr $istep + 1`
        rm -rf $tempd/Zfs_filesystems
done
# For 141808
####For Bug 159072 ###
###Displaying the results based on the Memory Values###
#IsZero=`changeMG $total_memory`
tot_MemoryRangeStatus=`echo "$total_memory" | grep "-"`
        if [ "$tot_MemoryRangeStatus" = "" ]; then
                IsZero=`changeMG $total_memory`
        else
                tot_memory_unit=`echo "$total_memory" | grep "GB"`
                tot_memoryVal1=`echo "$total_memory" | cut -d"-" -f1`
                tot_memoryVal2=`echo "$total_memory" | cut -d"-" -f2`
                if [ "$tot_memory_unit" = "" ]; then
                        ifTotalmemoryVal1=`changeMG_GB "${tot_memoryVal1}MB"`
                        ifTotalmemoryVal2=`changeMG_GB "$tot_memoryVal2"`
                else
                        type=`uname`
                        if [ "$type" = "SunOS" ]; then
                                ifTotalmemoryVal1=`echo "${tot_memoryVal1}GB" | nawk '{printf "%.2f", $1}'`
                                ifTotalmemoryVal2=`echo "${tot_memoryVal2}GB" | nawk '{printf "%.2f", $1}'`
                        else
                                ifTotalmemoryVal1=`echo "${tot_memoryVal1}GB" | awk '{printf "%.2f", $1}'`
                                ifTotalmemoryVal2=`echo "${tot_memoryVal2}GB" | awk '{printf "%.2f", $1}'`
                        fi
                fi

                ifTotalmemoryVal1=`echo "$ifTotalmemoryVal1" | sed 's/GB//g' | sed 's/MB//g'`
                ifTotalmemoryVal2=`echo "$ifTotalmemoryVal2" | sed 's/GB//g' | sed 's/MB//g'`
                IsZero=`echo "${ifTotalmemoryVal1}-${ifTotalmemoryVal2}GB"`
        fi
if [ "$IsZero" != "0" ]; then
	rstmemory=`cat $TMP_DIR/$rescommon | grep $TMEMO | cut -d= -f2`
	rstmemory1=`echo $rstmemory | cut -d ' ' -f1`

	MemaggRange=`echo "$IsZero" | grep "-"`
	if [ "$MemaggRange" = "" ]; then
			MemaggResult=`compare $rstmemory1 $IsZero`
	else
			MemaggResult=`CompareRangeValues "$rstmemory1" "$IsZero"`
	fi
	if [ "$ShortArgFlag" = "True" ]; then
	     if [ "$aggResult" != "PASS" ]; then
		if [ $LoopCount -eq 0 ]; then
			 # deal the total memory and disk
			 ElementAsItIs "    <AggregatedResults>"
			 printf "\n\n" >> $TMP_DIR/$rep
			 printf "$ALL_COMPONENTS_STR:\n" >> $TMP_DIR/$rep
			 if [ ! "$aaaa" = "0" ]; then
				printf "$ALL_COMPONENTS_STR:\n"
				#printf "\n" >> $TMP_DIR/$rep
			 fi
			 myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR">> $TMP_DIR/$rep
			 myprintf "$patt" "========" "======"  "=====" '========'>> $TMP_DIR/$rep
			 if [ ! "$aaaa" = "0" ]; then
				smyprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR"
				smyprintf "$patt" "========" "======"  "=====" '========'
			 fi
			LoopCount=1
		fi
		if [ ! "$aaaa" = "0" ]; then
			smyprintf "$patt" "$TMEMO" "$MemaggResult"  `changeMG $rstmemory` $IsZero
		fi
		myprintf "$patt" "$TMEMO" "$MemaggResult" `changeMG $rstmemory` $IsZero >> $TMP_DIR/$rep
	    else
                if [ $LoopCount -eq 0 ]; then
                         # deal the total memory and disk
                         ElementAsItIs "    <AggregatedResults>"
                         printf "\n\n" >> $TMP_DIR/$rep
                         printf "$ALL_COMPONENTS_STR:\n" >> $TMP_DIR/$rep
                         if [ ! "$aaaa" = "0" ]; then
                                printf "$ALL_COMPONENTS_STR:\n"
                                #printf "\n" >> $TMP_DIR/$rep
                         fi
                         myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR">> $TMP_DIR/$rep
                         myprintf "$patt" "========" "======"  "=====" '========'>> $TMP_DIR/$rep
                         if [ ! "$aaaa" = "0" ]; then
                                smyprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR"
                                smyprintf "$patt" "========" "======"  "=====" '========'
                         fi
                        LoopCount=1
                fi
                myprintf "$patt" "$TMEMO" "$MemaggResult" `changeMG $rstmemory` $IsZero >> $TMP_DIR/$rep
	    fi
	else
		if [ $LoopCount -eq 0 ]; then
                         # deal the total memory and disk
                         ElementAsItIs "    <AggregatedResults>"
                         printf "\n\n" >> $TMP_DIR/$rep
                         printf "$ALL_COMPONENTS_STR:\n" >> $TMP_DIR/$rep
                         if [ ! "$aaaa" = "0" ]; then
                                printf "$ALL_COMPONENTS_STR:\n"
                                #printf "\n" >> $TMP_DIR/$rep
                         fi
                         myprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR">> $TMP_DIR/$rep
                         myprintf "$patt" "========" "======"  "=====" '========'>> $TMP_DIR/$rep
                         if [ ! "$aaaa" = "0" ]; then
                                smyprintf "$patt" "$PROPERTY_STR" "$RESULT_STR"  "$FOUND_STR" "$EXPECT_STR"
                                smyprintf "$patt" "========" "======"  "=====" '========'
                         fi
                        LoopCount=1
                fi
		if [ ! "$aaaa" = "0" ]; then
			smyprintf "$patt" "$TMEMO" "$MemaggResult"  `changeMG $rstmemory` $IsZero
		fi
		myprintf "$patt" "$TMEMO" "$MemaggResult" `changeMG $rstmemory` $IsZero >> $TMP_DIR/$rep
	fi
fi
if [ $LoopCount -eq 1 ]; then
	ElementAsItIs "    </AggregatedResults>"
fi
return_code=0

#XML results for ResultSummary
ElementAsItIs "    <ResultSummary>"


if [ "$ShortArgFlag" = "True" ]; then
	individualResult=""
else
	tmpirinput=`cat $TMP_DIR/result_$rep | sed '/^$/d' | sed 's/$/,/g'`
	individualResult=`echo $tmpirinput | sed 's/, $//' | sed 's/,$//'`
	individualResult=`echo "($individualResult)"`
fi

if [ "`cat $TMP_DIR/$rep | grep "$FAIL_STR"`" != "" ]; then
        if [ ! "$aaaa" = "0" ]; then
                echo
                ElementAsItIs "$Indent$Indent<OverallResult>$FAIL_STR</OverallResult>"
                echo "$OVERALL_RESULT_STR:   $FAIL_STR  $individualResult"
                echo "" >> $TMP_DIR/$rep
                echo "$OVERALL_RESULT_STR:   $FAIL_STR  $individualResult" >> $TMP_DIR/$rep
                logDebug "$OVERALL_RESULT_STR:   $FAIL_STR"
        else
                echo "" >> $TMP_DIR/$rep
                echo "$OVERALL_RESULT_STR:   $FAIL_STR  $individualResult" >> $TMP_DIR/$rep
                ElementAsItIs "$Indent$Indent<OverallResult>$FAIL_STR</OverallResult>"
                echo "$FAIL_STR"
        fi
    return_code=1
elif [ "`cat $TMP_DIR/$rep | grep "$WARN_STR"`" != "" ]; then
        if [ ! "$aaaa" = "0" ]; then
                echo
                ElementAsItIs "$Indent$Indent<OverallResult>$WARNING_STR</OverallResult>"
                echo "$OVERALL_RESULT_STR:   $WARNING_STR  $individualResult"
                echo "" >> $TMP_DIR/$rep
                echo "$OVERALL_RESULT_STR:   $WARNING_STR  $individualResult" >> $TMP_DIR/$rep
                logDebug "$OVERALL_RESULT_STR:   $WARNING_STR"

        else
                ElementAsItIs "$Indent$Indent<OverallResult>$WARNING_STR</OverallResult>"
                echo "" >> $TMP_DIR/$rep
                echo "$OVERALL_RESULT_STR:   $WARNING_STR  $individualResult" >> $TMP_DIR/$rep
                logDebug "$OVERALL_RESULT_STR:   $WARNING_STR  $individualResult"
                echo "$WARNING_STR"
        fi
        return_code=3
else
        if [ ! "$aaaa" = "0" ]; then
                echo
                ElementAsItIs "$Indent$Indent<OverallResult>$PASS_STR</OverallResult>"
                echo "$OVERALL_RESULT_STR:   $PASS_STR  $individualResult"
                echo "" >> $TMP_DIR/$rep
                echo "$OVERALL_RESULT_STR:   $PASS_STR  $individualResult" >> $TMP_DIR/$rep
                logDebug "$OVERALL_RESULT_STR:   $PASS_STR"

        else
                ElementAsItIs "$Indent$Indent<OverallResult>$PASS_STR</OverallResult>"
                echo "" >> $TMP_DIR/$rep
                echo "$OVERALL_RESULT_STR:   $PASS_STR  $individualResult" >> $TMP_DIR/$rep
                logDebug "$OVERALL_RESULT_STR:   $PASS_STR  $individualResult"
                echo "$PASS_STR"
        fi
fi
#read the lines by lines from the product results files
while read varCode varVersion varResult
do
	ElementAsItIs "$Indent$Indent<ProductResult>"
	ElementAsItIs "$Indent$Indent$Indent<ProductCode>$varCode</ProductCode>"
	ElementAsItIs "$Indent$Indent$Indent<Result>$varResult</Result>"
	ElementAsItIs "$Indent$Indent</ProductResult>"
done < $TMP_DIR/result_$rep
ElementAsItIs "    </ResultSummary>"

# Call this function if the Single Property is enabled
logDebug "Enter the if statement if SingleProperty is True"
if [  "$TmpPropertyFlag" = "True" ]; then
	if [ "$DetailFlag" = "True" ]; then
		if [ -s $TMP_DIR/$WarningMsgFile ]; then
			echo ""
			WarningMsgString1=`cat $TMP_DIR/$WarningMsgFile | tr "\n" ","`
			WarningMsgString=`echo "$WarningMsgString1" | sed s'/.$//'`
			printmessage "$PASSINPROP_NOTVALID_WARN1_STR" "[$varCode $varVersion]" "$WarningMsgString"
			logDebug "$PASSINPROP_NOTVALID_WARN1_STR $WarningMsgString"
			echo ""
		fi
	fi
	if [ -s $TMP_DIR/$WarningMsgFile ]; then
		xmlFlag=$SinglePropWarn
		WarningMsgString1=`cat $TMP_DIR/$WarningMsgFile | tr "\n" ","`
		WarningMsgString=`echo "$WarningMsgString1" | sed s'/.$//'`
		generateXmlReport "$PASSINPROP_NOTVALID_WARN_STR $WarningMsgString"
		logDebug "$PASSINPROP_NOTVALID_WARN_STR $WarningMsgString"
		echo "" >> $TMP_DIR/result2.txt
		echo "$PASSINPROP_NOTVALID_WARN_STR $WarningMsgString" >> $TMP_DIR/result2.txt
	fi
fi
#Display status of the environment variables if any
if [ -s $TMP_DIR/ENV_VARIABLE_SETTINGS_STR.txt ]; then
        InfoMsgString2=`cat $TMP_DIR/ENV_VARIABLE_SETTINGS_STR.txt | sort | uniq | sed '/^$/d' | awk '{printf("%s, ", $0)}'`
        InfoMsgString=`echo "$InfoMsgString2" | sed -e 's/^ *//g;s/ *$//g' | sed s'/,$//'`
        if [ "$DetailFlag" = "True" ]; then
                echo ""
                echo "" >> $TMP_DIR/result2.txt
                echo "${ENV_VARIABLE_SETTINGS_STR}: [ $InfoMsgString ]"
                echo "${ENV_VARIABLE_SETTINGS_STR}: [ $InfoMsgString ]" >> $TMP_DIR/result2.txt
        else
                echo "" >> $TMP_DIR/result2.txt
                echo "${ENV_VARIABLE_SETTINGS_STR}: [ $InfoMsgString ]" >> $TMP_DIR/result2.txt
        fi
fi


logDebug "====== Step 6: Cleanup"

# clean the temp files and folder
ls $PREREQ_HOME/UNIX_Linux/*-Master > $TMP_DIR/master 2>/dev/null

for masterFile in `cat $TMP_DIR/master`
do
  origFile=`echo $masterFile | sed 's/-Master//g'`
  rm -f $origFile
  mv $masterFile $origFile
done 
cat $TMP_DIR/result1.txt $TMP_DIR/result2.txt >> $TMP_DIR/$Result_TXT_File
cat $TMP_DIR/SectionWarningMsg.txt 2>/dev/null
cat $TMP_DIR/SectionWarningMsg.txt >> $TMP_DIR/$Result_TXT_File 2>/dev/null

if [ -s $TMP_DIR/SectionWarningMsg.txt ]; then
        ElementAsItIs "$Indent"
        ElementAsItIs "$Indent<Warnings>"
        while read readline
        do
                isWarningMsg=`echo "$readline" | grep -i "CTGPR"`
                if [ "$isWarningMsg" ]; then
                        ElementAsItIs "$Indent$Indent<Message>$readline</Message>"
                fi
        done < $TMP_DIR/SectionWarningMsg.txt 2>/dev/null
        ElementAsItIs "$Indent</Warnings>"
        ElementAsItIs "$Indent"
fi
ElementAsItIs "</Results>"

logDebug "Exiting main function"
logDebug "Exiting main function"
if [ $return_code -eq 0 ]; then
        logDebug "Returning exit code 0"
        clean_temp_Directory
        exit 0
elif [ $return_code -eq 3 ]; then
        logDebug "Returning exit code 3"
        clean_temp_Directory
        exit 3
else
        logDebug "Returning exit code 1"
        clean_temp_Directory
        exit 1
fi
