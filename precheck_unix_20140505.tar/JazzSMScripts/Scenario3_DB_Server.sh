#!/bin/sh
#********************* Begin Copyright - Do not add comments here *********************************
#  Licensed Materials - Property of IBM
# "Restricted Materials of IBM"
#
#  5725-C13
#
# (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#
#  US Government Users Restricted Rights - Use, duplication, or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#************************************ End Standard Header *****************************************

###################################################################################################
# Prerequisite Scanner quick start script for Jazz for Service Management
#
# Run this script to check prerequisites for the following type of deployment:
# 	Distributed deployment - Database server installation only
# 
# Detailed scan results are displayed in the command window and written to both text and XML file
# The output directory for scan results and log files is $HOME/prslogs
#
# Optional parameter can be passed in to this script in order to properly set the environment variable: JazzSM_FreshInstall
#    "update"        - when planning to run update of existing JazzSM Database server installation
# If "update" is specified the env variable setting will be      : JazzSM_FreshInstall=False
# If anything else other than "update" is specified              : JazzSM_FreshInstall=True
# Default env variable setting if no parameter is specified      : JazzSM_FreshInstall=True
###################################################################################################


# get current directory (script running directory)
OLDDIR=$PWD

if [ "`uname`" = "SunOS" ];then
        SCRIPT_HOME=`echo $0`
        SCRIPT_HOME_FP=`dirname $PRS_HOME`
        if [ "$SCRIPT_HOME_FP" = "." ]; then
                SCRIPT_HOME_FP=`echo $PWD`
                PREREQ_HOME=$SCRIPT_HOME_FP/..
        else
                cd $SCRIPT_HOME_FP
                PREREQ_HOME=$SCRIPT_HOME_FP/..
                PREREQ_HOME=`pwd`
        fi
else
        SCRIPT_HOME_FP=`dirname $0`
        cd $SCRIPT_HOME_FP/..
        PREREQ_HOME=$PWD
        cd - > /dev/null 2>&1
fi

# Check if optional parameter was passed in and set the install type.
# Expected optional parameter can be "update" or "freshInstall".
if [ $# -gt 0 ] ; then
   installType=$1
else
   installType="freshInstall"
fi
# Ignore case sensitivity of installType string
installType=`echo $installType | tr '[:upper:]' '[:lower:]'`

# Set proper environment variables
# Set FRS_DBSERVER env var to indicate this is a Registry Service database server
FRS_DBSERVER=True
export FRS_DBSERVER
# Set env var Include_TCR to False to satisfy temp disk space requirement
Include_TCR=False
export Include_TCR
# Set env var JazzSM_FreshInstall based on optional parameter passed in to this script.
# If "update" set JazzSM_FreshInstall=False
# Else set JazzSM_FreshInstall=True
if [ "$installType" = "update" ] ; then
   JazzSM_FreshInstall=False
   export JazzSM_FreshInstall
else
   JazzSM_FreshInstall=True
   export JazzSM_FreshInstall
fi

$PREREQ_HOME/prereq_checker.sh "ODP,FRS" detail xmlResult outputDir=$HOME/prslogs

PRS_RC=$?
echo " "
echo "Prerequisite Scanner completed with return code $PRS_RC"

# Set environment variables back to empty
FRS_DBSERVER=
Include_TCR=
JazzSM_FreshInstall=
export FRS_DBSERVER Include_TCR JazzSM_FreshInstall

# go back to script running directory
cd $OLDDIR
OLDDIR=

exit $PRS_RC
