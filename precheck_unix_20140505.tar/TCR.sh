#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

# RTC Defect 20889
#       Find the working directory for all the supported platforms
#       Working directory "PREREQ_HOME" is available throughout the execution of PRS

if [ "`uname`" = "SunOS" ];then
        PRS_HOME=`echo $0`
        PREREQ_HOME=`dirname $PRS_HOME`
        if [ "$PREREQ_HOME" = "." ]; then
                PREREQ_HOME=`pwd`
        else
                cd $PREREQ_HOME
                PREREQ_HOME=`pwd`
        fi
else
        PRS_HOME=`dirname $0`
        cd $PRS_HOME
        PREREQ_HOME=$PWD
        cd - > /dev/null 2>&1
fi

# Check if optional parameter was passed in and set the install type.
# Expected optional parameter can be "update" or "freshInstall".
if [ $# -gt 0 ] ; then
   installType=$1
else
   installType="freshInstall"
fi
# Ignore case sensitivity of installType string
installType=`echo $installType | tr '[:upper:]' '[:lower:]'`

# Set proper environment variables
# Set env var JazzSM_FreshInstall based on optional parameter passed in to this script.
# If "update" set JazzSM_FreshInstall=False
# Else set JazzSM_FreshInstall=True
if [ "$installType" = "update" ] ; then
   JazzSM_FreshInstall=False
else
   JazzSM_FreshInstall=True
fi
export JazzSM_FreshInstall
$PREREQ_HOME/prereq_checker.sh TCR detail outputDir=/tmp/prs

PRS_RC=$?
echo " "
echo "Prerequisite Scanner completed with return code $PRS_RC"

# Set environment variables back to empty
JazzSM_FreshInstall=
export JazzSM_FreshInstall
exit $PRS_RC
