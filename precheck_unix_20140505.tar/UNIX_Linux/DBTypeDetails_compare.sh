#!/bin/sh
# Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh
logDebug "Comparing the DBType Details"
type=`uname`
if [ "$1" = "$UNAVAILABLE_STR" ]; then
  echo "$FAIL_STR"
  exit
else
   if [ "$2" = "Any" -o "$2" = "any" ]; then
   echo "$PASS_STR"
   exit
   fi
fi

regexFound=`echo $2 | grep "regex{"`
if [ "$regexFound" != "" ]; then
  if [ "$type" = "AIX" ]; then
        prod=`echo $1 | awk -F"," '{print $1}'`
        toSearch=`echo $2 | sed 's/regex{//g' | sed 's/}//g'`
        isFound=`echo $prod | egrep  $toSearch`
  else
        toSearch=`echo $2 | sed 's/regex{//g' | sed 's/}//g' | sed 's/|/\\\|/g'`
        isFound=`echo $1 | grep  $toSearch`
  fi

  if [ "$isFound" != "" ]; then
    echo "$PASS_STR"
    exit
  fi
else
   toSearch=$2
   isFound=`echo $1 | grep  $toSearch`
  if [ "$isFound" != "" ]; then
    echo "$PASS_STR"
    exit
  fi
fi  
echo "$FAIL_STR"
