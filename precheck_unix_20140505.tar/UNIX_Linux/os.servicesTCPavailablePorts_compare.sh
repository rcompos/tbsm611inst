#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

. ../lib/common_function.sh

logInfo "os.servicesTCPavailablePorts Evaluator is called with parameter : $1 and $2"
if [ "$1" = "PortsInUse:None" ]; then
	echo "$PASS_STR"
	logInfo "os.servicesTCPavailablePorts Evaluator exiting with value $PASS_STR"
else
	echo "$FAIL_STR"
	logInfo "os.servicesTCPavailablePorts Evaluator exiting with value $FAIL_STR"
fi
