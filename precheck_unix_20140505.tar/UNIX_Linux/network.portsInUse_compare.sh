#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh


PortStatus=""
#Save the old IFS and Modify the IFS to ","
OLDIFS=$IFS
IFS=","


for port in `echo "$2" | sed 's/ //g'`
do
        logDebug "Checking for port $port"
        range="$port"
        check_range=`echo $range | grep -`

	if [ $check_range ]; then 
		range_start=`echo "$port" | cut -d '-' -f1`
		range_end=`echo "$port" | cut -d '-' -f2`
		#echo $range_start
		#echo $range_end

		rm -f /$TMP_DIR/prs.res
		if [ -s "/$TMP_DIR/prs.net" ]; then
			logDebug "File /$TMP_DIR/prs.net does not exists"
		else
			type=`uname`
			if [ "$type" = "SunOS" ]; then
				netstat -an | grep LISTEN > /$TMP_DIR/prs.net
			elif [ "$type" = "HP-UX" ]; then
				netstat -an | grep LISTEN > /$TMP_DIR/prs.net
			else
				netstat -ant | grep LISTEN > /$TMP_DIR/prs.net
			fi
		fi
	    while [ $range_start -le $range_end ]
	    do
		#echo $range_start
		res=`grep -w $range_start /$TMP_DIR/prs.net`
		res=`echo $res | cut -d' ' -f1`

		if [ $res ]; then
		      echo  "$TRUE_STR" >> /$TMP_DIR/prs.res
		else
		      echo "$FAIL_STR" >> /$TMP_DIR/prs.res
		      exit
		fi
		range_start=`expr $range_start + 1`
	    done

	    if [ $res ]; then
		PortStatus="$PASS_STR"
	    else
		PortStatus="$FAIL_STR"
		break ;
	    fi

	else
		if [ -s "/$TMP_DIR/prs.net" ]; then
			logDebug "File /$TMP_DIR/prs.net does not exists"
		else
			type=`uname`
			if [ "$type" = "SunOS" ]; then
				netstat -an | grep LISTEN > /$TMP_DIR/prs.net
			elif [ "$type" = "HP-UX" ]; then
				netstat -an | grep LISTEN > /$TMP_DIR/prs.net
			else
				netstat -ant | grep LISTEN > /$TMP_DIR/prs.net
			fi
		fi
		res=`grep -w "$port" /$TMP_DIR/prs.net`
		res=`echo $res | cut -d' ' -f1`
		if [ $res ]; then
			PortStatus="$PASS_STR"
		else
			PortStatus="$FAIL_STR"
			break ;
		fi
	fi
done

echo "$PortStatus"
#Revert back the IFS value
IFS=$OLDIFS

