#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

. $PREREQ_HOME/lib/common_function.sh

isQualifierExists(){
        line=$1
        isQualifierExists=`echo $line| grep "]"`
        if [ $isQualifierExists ]; then
                rc="1"
        else
                rc="0"
        fi
        echo "$rc" 
       
        
}

getPreReqScanParamValue(){
        cfgLine=$1
        isQualFound=`isQualifierExists "$cfgLine"`
         if [ "$isQualFound" -eq "1" ]; then
                scanParamValue=`echo "$cfgLine" | cut -d "]" -f2`
	else
                scanParamValue=`echo "$cfgLine" | cut -d "=" -f2`
        fi
        echo "$scanParamValue"
}
generateScanCmd(){

        scriptCmd=$1
        scriptParams=$2
        checkName=$3
        checkSpec=$4
        generic=$5
        
        if [ $generic="True" ]; then
                key=`echo $checkSpec |cut -d"=" -f1 |cut -d"." -f3`
                checkName="$checkName.$key"
        fi
         
      # IsQualFound=`echo $checkSpec | grep "]"`
        #isQualFound=`isQualifierExists "$checkSpec"`
      
        ExpValue=`getPreReqScanParamValue "$checkSpec"`
        echo "ss=\`$PREREQ_HOME/UNIX_Linux/$scriptCmd $scriptParams\`" >> /$TMP_DIR/prs.check
        #echo "ss=\`./os.level\`" >>/$TMP_DIR/prs.check
	
	
	echo "echo \"$checkName=\$ss\"" >> /$TMP_DIR/prs.check
}
rm -f /$TMP_DIR/prs.check
# fix for Bug 142865
if [ "$2" = "LCM_02300000.cfg" -o "$2" = "TAD_07200000.cfg" -o "$2" = "TAD_07220000.cfg" -o "$2" = "LCM_01000000.cfg" -o "$2" = "DA1_09010000.cfg" -o "$2" = "FTA_09010000.cfg"  -o "$2" = "DA1_09020000.cfg" -o "$2" = "FTA_09020000.cfg" ]; then
echo "Using existing sh " >>/$TMP_DIR/prs1.check
else    
echo "#!/bin/sh" >>/$TMP_DIR/prs.check
type=`uname`
if [ "$type" != "SunOS" ]; then
echo cd $1>>/$TMP_DIR/prs.check
fi
echo "set -x" >>/$TMP_DIR/prs.check
#echo "ptrace=\"../prs.trc\"" >>/$TMP_DIR/prs.check
#echo "pdbg=\"../prs.debug\"" >>/$TMP_DIR/prs.check
if [ "$3" = "debugFlag" ]; then
echo "debugFlag=\"True\"" >>/$TMP_DIR/prs.check
fi
if [ "$4" = "traceFlag" ]; then
echo "traceFlag=\"True\"" >>/$TMP_DIR/prs.check
fi

#echo ". ../lib/common_function.sh" >>/$TMP_DIR/prs.check
echo ". $PREREQ_HOME/lib/common_function.sh" >>/$TMP_DIR/prs.check
#echo " if [ \"$traceFlag\" = \"True\" ]; then" >>/$TMP_DIR/prs.check
#echo " printf "[%-20s] %-8s: %-s\n" "`date '+%Y.%m.%d %H.%M.%S'`" "$1" \"$2\""
#echo ". ./lib/common_function.sh" >>/$TMP_DIR/prs.check

while read line
do
  file1=`echo $line | grep package | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.package.perl_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.package.perl_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi
echo $line

  file1=`echo $line | grep "os.ibmLibraryVersion" | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.ibmLibraryVersion_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.ibmLibraryVersion_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi
echo $line

  file1=`echo $line | grep "os.networkTuningParameter" | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.networkTuningParameter_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.networkTuningParameter_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi
echo $line

  file1=`echo $line | grep "db2.home" | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/db2.home_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/db2.home_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi
echo $line

  file1=`echo $line | grep "os.kernelTuningParameter" | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.kernelTuningParameter_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.kernelTuningParameter_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi
echo $line

  file1=`echo $line | grep "os.virtualMemoryTuningParameter" | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.virtualMemoryTuningParameter_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.virtualMemoryTuningParameter_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi
echo $line

file1=`echo $line | grep availablePorts | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/network.availablePorts.app_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/network.availablePorts.app_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi

file1=`echo $line | grep UDPavailablePorts | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
	  cp $1/network.UDPavailablePorts.app_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
	  cp $1/network.UDPavailablePorts.app_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi

file1=`echo $line | grep portsInUse | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/network.portsInUse_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/network.portsInUse_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi
  
  file1=`echo $line | grep ServicePack | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
          cp $1/os.ServicePack $1/os.servicePack 2>/dev/null
          cp $1/os.ServicePack_compare.sh $1/os.servicePack_compare.sh 2>/dev/null
  else
          cp $1/os.ServicePack $1/os.servicePack 2>/dev/null
          cp $1/os.ServicePack_compare.sh $1/os.servicePack_compare.sh 2>/dev/null
  fi
  

file1=`echo $line | grep UDPportsInUse | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
	  cp $1/network.UDPportsInUse_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
	  cp $1/network.UDPportsInUse_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi

file1=`echo $line | grep servicesTCPavailablePorts | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
          cp $1/os.servicesTCPavailablePorts_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
          cp $1/os.servicesTCPavailablePorts_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi

file1=`echo $line | grep servicesUDPavailablePorts | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
          cp $1/os.servicesUDPavailablePorts_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
          cp $1/os.servicesUDPavailablePorts_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi

file1=`echo $line | grep os.lib | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.lib_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.lib_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi

file1=`echo $line | grep os.LibPatch | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.LibPatch_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.LibPatch_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi
  
  file1=`echo $line | grep os.strings | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.strings_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.strings_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi

file1=`echo $line | grep os.space | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.space_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.space_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi

file1=`echo $line | grep os.dir | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.dir_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.dir_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi

file1=`echo $line | grep os.fileInfo | cut -d'=' -f1 | sed 's/ //g'`
  if [ "$type" = "SunOS" ]; then
  cp $1/os.fileInfo_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.fileInfo_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi


file=`echo $line | grep os.ulimit | cut -d'=' -f1 | sed 's/ //g'`
key=`echo $line | grep os.ulimit | cut -d "[" -f2 | cut -d "]" -f1 | cut -d ":" -f2`
file1=$file.$key
  if [ "$type" = "SunOS" ]; then
  cp $1/os.ulimit_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  else
  cp $1/os.ulimit_compare.sh $1/"$file1"_compare.sh 2>/dev/null
  fi


res=`echo $line | grep os.servicesTCPavailablePorts`
if [ "$res" != "" ]; then
   ports=`echo $line | cut -d'.' -f3 |cut -d'=' -f1 | sed 's/ //g'`
   ePort=`echo "$line" | awk -F"=" '{print $2}'`
##TRACE AND DEBUG##

        echo "ss=\`./os.servicesTCPavailablePorts $ports \"$ePort\" \`" >>/$TMP_DIR/prs.check

        echo "echo \"os.servicesTCPavailablePorts.$ports=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.servicesUDPavailablePorts`
if [ "$res" != "" ]; then
   ports=`echo $line | cut -d'.' -f3 |cut -d'=' -f1 | sed 's/ //g'`
   ePort=`echo "$line" | awk -F"=" '{print $2}'`
##TRACE AND DEBUG##

        echo "ss=\`./os.servicesUDPavailablePorts $ports \"$ePort\"\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.servicesUDPavailablePorts.$ports=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep network.availablePorts`
if [ "$res" != "" ]; then
   ports=`echo $line | cut -d'.' -f3 |cut -d'=' -f1 | sed 's/ //g'`
##TRACE AND DEBUG##

 	echo "ss=\`./network.port $ports\`" >>/$TMP_DIR/prs.check

 	
	echo "echo \"network.availablePorts.$ports=\$ss\"" >>/$TMP_DIR/prs.check
	
fi

res=`echo $line | grep network.UDPavailablePorts`
if [ "$res" != "" ]; then
   ports=`echo $line | cut -d'.' -f3 |cut -d'=' -f1 | sed 's/ //g'`
##TRACE AND DEBUG##

        echo "ss=\`./network.UDPport $ports\`" >>/$TMP_DIR/prs.check


        echo "echo \"network.UDPavailablePorts.$ports=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep network.portsInUse`
if [ "$res" != "" ]; then
   	ports=`echo $line | cut -d'.' -f3 |cut -d'=' -f1 | sed 's/ //g'`
##TRACE AND DEBUG##

	echo "ss=\`./network.port $ports\`" >>/$TMP_DIR/prs.check
	
	
	echo "echo \"network.portsInUse.$ports=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep network.UDPportsInUse`
if [ "$res" != "" ]; then
        ports=`echo $line | cut -d'.' -f3 |cut -d'=' -f1 | sed 's/ //g'`
##TRACE AND DEBUG##

        echo "ss=\`./network.UDPport $ports\`" >>/$TMP_DIR/prs.check


        echo "echo \"network.UDPportsInUse.$ports=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep os.ulimit`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
	

        ####CHECKING FOR QUALIFIER####
        IsQualFound=`echo "$res" | grep "]" | cut -d "=" -f1`
        prod=`echo "$res" | cut -d "=" -f2-`
        if [ $IsQualFound ]; then
                echo "ss=\`./os.ulimit "$prod"\`" >>/$TMP_DIR/prs.check
        else
                echo "ss=\`./os.ulimit\`" >>/$TMP_DIR/prs.check
        fi
	
        key=`echo "$res" | cut -d "[" -f2 | cut -d "]" -f1 | cut -d ":" -f2`
        if [ $IsQualFound ]; then
                echo "echo \"os.ulimit.$key=\$ss\"" >>/$TMP_DIR/prs.check
        else
                echo "echo \"os.ulimit=\$ss\"" >>/$TMP_DIR/prs.check
        fi


fi

res=`echo $line | grep os.level`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
	


	echo "ss=\`./os.level\`" >>/$TMP_DIR/prs.check
	
	
	echo "echo \"os.level=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.sshdConfig`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.sshdConfig\`" >>/$TMP_DIR/prs.check


	echo "echo \"os.sshdConfig=\$ss\"" >>/$TMP_DIR/prs.check
	
fi

res=`echo $line | grep os.sshdConfig.UseLogin`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.sshdConfig.UseLogin\`" >>/$TMP_DIR/prs.check


	echo "echo \"os.sshdConfig.UseLogin=\$ss\"" >>/$TMP_DIR/prs.check
	
fi

res=`echo $line | grep os.userLimits`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`



	echo "ss=\`./os.userLimits\`" >>/$TMP_DIR/prs.check
	echo "echo \"os.userLimits=\$ss\"" >>/$TMP_DIR/prs.check
fi

res=`echo $line | grep env.classpath.derbyJAR`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./env.classpath.derbyJAR\`" >>/$TMP_DIR/prs.check
	echo "echo \"env.classpath.derbyJAR=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.ftpusers`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.ftpusers\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.ftpusers=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.loginVariable`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.loginVariable\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.loginVariable=\$ss\"" >>/$TMP_DIR/prs.check



fi


res=`echo $line | grep os.kernelMode`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.kernelMode\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.kernelMode=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.maximumProcesses`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.maximumProcesses\`" >>/$TMP_DIR/prs.check
	echo "echo \"os.maximumProcesses=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.MozillaVersion`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.MozillaVersion\`" >>/$TMP_DIR/prs.check
	echo "echo \"os.MozillaVersion=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.SeaMonkeyVersion`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./os.SeaMonkeyVersion\`" >>/$TMP_DIR/prs.check
        echo "echo \"os.SeaMonkeyVersion=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo "$line" | grep "DB2 Version"`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

	echo "ss=\`./DB2_Version.sh \`" >>/$TMP_DIR/prs.check

	echo "echo \"DB2 Version=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.iFix`
if [ "$res" != "" ]; then
	ExpValue=`echo $res | cut -d "]" -f2`
	prod=`echo $res | cut -d "=" -f2`
	echo "ss=\`./os.iFix "$prod"\`" >>/$TMP_DIR/prs.check
	echo "echo \"os.iFix=\$ss\"" >>/$TMP_DIR/prs.check
fi


res=`echo $line | grep os.largeFile`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.largeFile\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.largeFile=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.windowManager`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.windowManager\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.windowManager=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.RAMSize`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.RAMSize\`" >>/$TMP_DIR/prs.check


	echo "echo \"os.RAMSize=\$ss\"" >>/$TMP_DIR/prs.check



fi

res=`echo $line | grep os.automaticCleanup`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.automaticCleanup\`" >>/$TMP_DIR/prs.check
	echo "echo \"os.automaticCleanup=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep os.swapSize`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
 prod=`echo $line |cut -d"=" -f2`


	echo "ss=\`./os.swapSize "$prod"\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.swapSize=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.ibmLibraryVersion`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
prod=`echo "$line" |cut -d"=" -f2-`
prodname=`echo "$line" | cut -d"=" -f1 | sed 's/os.ibmLibraryVersion.//'`


        echo "ss=\`./os.ibmLibraryVersion "$prod"\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.ibmLibraryVersion.$prodname=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.CompizVar`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.CompizVar\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.CompizVar=\$ss\"" >>/$TMP_DIR/prs.check


fi



res=`echo $line | grep os.umask`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.umask\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.umask=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.locale`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.locale\`" >>/$TMP_DIR/prs.check


	echo "echo \"os.locale=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep db2.home.space`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./db2.home.space\`" >>/$TMP_DIR/prs.check

	echo "echo \"db2.home.space=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.expectLink`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.expectLink\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.expectLink=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.maximoDirectory`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.maximoDirectory\`" >>/$TMP_DIR/prs.check


	echo "echo \"os.maximoDirectory=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.maximoDirOwner`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.maximoDirOwner\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.maximoDirOwner=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.kernelversion`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.kernelversion\`" >>/$TMP_DIR/prs.check


	echo "echo \"os.kernelversion=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.kernelParameters`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

	echo "ss=\`./os.kernelParameters\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.kernelParameters=\$ss\"" >>/$TMP_DIR/prs.check
fi

res=`echo $line | grep os.version`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        echo "ss=\`./os.version\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.version=\$ss\"" >>/$TMP_DIR/prs.check
fi



res=`echo $line | grep oracle.Server`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./oracle.Server\`" >>/$TMP_DIR/prs.check

	echo "echo \"oracle.Server=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep oracle.Server.Location`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./oracle.Server.Location\`" >>/$TMP_DIR/prs.check


	echo "echo \"oracle.Server.Location=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep oracle.Client`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./oracle.Client\`" >>/$TMP_DIR/prs.check

	echo "echo \"oracle.Client=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep oracle.Client.Location`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./oracle.Client.Location\`" >>/$TMP_DIR/prs.check


	echo "echo \"oracle.Client.Location=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep env.var`

if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        prod=`echo $line |cut -d"=" -f2`
        key=`echo $line |cut -d"=" -f1 |cut -d"." -f3-8`

        echo "ss=\`./env.var "\"$prod\"" "$key"\`" >>/$TMP_DIR/prs.check

        echo "echo \"env.var.$key=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep env.JRE`

if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        prod=`echo $line |cut -d"=" -f2`
        key=`echo $line |cut -d"=" -f1 |cut -d"." -f3-8`

        echo "ss=\`./env.JRE "\"$prod\"" "$key"\`" >>/$TMP_DIR/prs.check

        echo "echo \"env.JRE.$key=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.localhostInHostsFile`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./os.localhostInHostsFile\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.localhostInHostsFile=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep network.pingLocalhost`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./network.ping localhost\`" >>/$TMP_DIR/prs.check

	echo "echo \"network.pingLocalhost=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.gnu.tar`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.cmd gtar\`" >>/$TMP_DIR/prs.check
	
	echo "echo \"os.gnu.tar=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep HWType`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./HWType\`" >>/$TMP_DIR/prs.check

        echo "echo \"HWType=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep VMHypervisor`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./VMHypervisor\`" >>/$TMP_DIR/prs.check

        echo "echo \"VMHypervisor=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep network.firewallEnabled`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./network.firewallEnabled\`" >>/$TMP_DIR/prs.check

        echo "echo \"network.firewallEnabled=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.tar`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.cmd tar\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.tar=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.nslookup`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.cmd nslookup\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.nslookup=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep numLogicalCPU`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./numLogicalCPU\`" >>/$TMP_DIR/prs.check

        echo "echo \"numLogicalCPU=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.architecture`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.architecture 32 bit\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.architecture=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep network.DHCPEnabled`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./network.DHCPEnabled\`" >>/$TMP_DIR/prs.check

	echo "echo \"network.DHCPEnabled=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep network.dns`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./network.dns\`" >>/$TMP_DIR/prs.check

	echo "echo \"network.dns=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.tmpdir`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.tmpdir\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.tmpdir=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo "$line" | grep -i "browser.Version"`
if [ "$res" != "" ]; then
ExpValue=`echo "$res" | cut -d "=" -f2-`
PropValue=`echo "$res" | cut -d "=" -f1 | sed 's/ //g'`
        echo "ss=\`./browser.Version \"$ExpValue\"\`" >>/$TMP_DIR/prs.check
        echo "echo \"$PropValue=\$ss\"" >>/$TMP_DIR/prs.check
fi


res=`echo $line | grep os.networkTuningParameter`

if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        package=`echo $line | cut -d"=" -f2`
        prod=`echo $line |cut -d"=" -f1 |cut -d"." -f3-7 | sed 's/ //g'`
        echo "ss=\`./os.networkTuningParameter $prod\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.networkTuningParameter.$prod=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.kernelTuningParameter`

if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        package=`echo $line | cut -d"=" -f2`
        prod=`echo $line |cut -d"=" -f1 |cut -d"." -f3-7 | sed 's/ //g'`
        echo "ss=\`./os.kernelTuningParameter $prod\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.kernelTuningParameter.$prod=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.virtualMemoryTuningParameter`

if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
        logDebug "In Meti, os.virtualMemoryTuningParameter=$ExpValue"


        package=`echo $line | cut -d"=" -f2`
        prod=`echo $line |cut -d"=" -f1 |cut -d"." -f3-7 | sed 's/ //g'`
        echo "ss=\`./os.virtualMemoryTuningParameter $prod\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.virtualMemoryTuningParameter.$prod=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.diskquota`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.diskquota\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.diskquota=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.hostformat`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.hostformat\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.hostformat=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.SELinux`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

	###Checking for Qualifier####
	IsQualFound=`echo "$res" | grep "]" | cut -d "=" -f1 | sed 's/ //g'`
	prod=`echo "$res" | cut -d "=" -f2-8`
	if [ $IsQualFound ]; then
		echo "ss=\`./os.SELinux "$prod"\`" >>/$TMP_DIR/prs.check
	else
		echo "ss=\`./os.SELinux\`" >>/$TMP_DIR/prs.check
	fi

	echo "echo \"os.SELinux=\$ss\"" >>/$TMP_DIR/prs.check


fi



res=`echo $line | grep os.pagesize`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.pagesize\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.pagesize=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.commandPrompt`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.commandPrompt\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.commandPrompt=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep user.isAdmin`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

	echo "ss=\`./os.user\`" >>/$TMP_DIR/prs.check
	echo "echo \"user.isAdmin=\$ss\"" >>/$TMP_DIR/prs.check
fi

res=`echo $line | grep network.ipv4Available`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

	echo "ss=\`./network.ipv4Available\`" >>/$TMP_DIR/prs.check
	echo "echo \"network.ipv4Available=\$ss\"" >>/$TMP_DIR/prs.check
fi

res=`echo $line | grep os.pageSizeEnabled`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
prod=`echo "$line" |cut -d"=" -f2`


        echo "ss=\`./os.pageSizeEnabled "$prod"\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.pageSizeEnabled=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep 'os\.file\.'`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

	prod=`echo $line |cut -d"=" -f1 |cut -d"." -f3-7 | sed 's/ //g'`
	echo "ss=\`./os.filepath "$prod"\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.file."$prod"=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.automount`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.automount\`" >>/$TMP_DIR/prs.check
	
	echo "echo \"os.automount=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.Firefox`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	echo "ss=\`./os.Firefox\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.Firefox=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.package`

if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	package=`echo $line | cut -d"=" -f2`
	prod=`echo $line |cut -d"=" -f1 |cut -d"." -f3-7`
	echo "ss=\`./os.package $prod\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.package.$prod=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.lib`

if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	prod=`echo $line |cut -d"=" -f2`
	key=`echo $line |cut -d"=" -f1 |cut -d"." -f3-8`
	
	echo "ss=\`./os.lib "\"$prod\"" "$key"\`" >>/$TMP_DIR/prs.check

	echo "echo \"os.lib.$key=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.isUnixServiceRunning`

if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


	prod=`echo $line | cut -d'.' -f3 |cut -d'=' -f1 | sed 's/ //g'`
        key=`echo $line |cut -d"=" -f1 |cut -d"." -f3-8`

        echo "ss=\`./os.isUnixServiceRunning "\"$prod\"" "$key"\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.isUnixServiceRunning.$key=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.fileInfo`

if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        prod=`echo $line | awk -F"=" '{print $2}'`
        key=`echo $line | awk -F"=" '{print $1}' | cut -d"." -f3-8`

        echo "ss=\`./os.fileInfo "\"$prod\"" "$key"\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.fileInfo.$key=\$ss\"" >>/$TMP_DIR/prs.check


fi


res=`echo $line | grep os.space`
Qual=`echo $line | grep "]" | cut -d "=" -f1 | sed 's/ //g'`
if [ $Qual ]; then
        Valid=FALSE
        Validate_ID=`id | awk '{print $1}'| cut -d "(" -f1 | cut -d "=" -f2`
        if [ $Validate_ID -eq 0 ]; then
                IsRootValue=`echo $line | grep -w root`
                if [ $IsRootValue ]; then
                        Valid=TRUE
                fi
        else
                IsNon_RootValue=`echo $line | grep non_root`
                if [ $IsNon_RootValue ]; then
                        Valid=TRUE
                fi
        fi
        ###Handling both Root And NonRoot case###
        BothFound=`echo "$line" | grep "non_root" | grep -w "root" | cut -d "=" -f1`
        if [ $BothFound ]; then
                Valid=TRUE
        fi
else
        Valid=TRUE
fi
if [ "$res" != "" ]; then
        if [ "$Valid" = "TRUE" ]; then
                ExpValue=`echo $res | cut -d "=" -f2`

                if [ $Qual ]; then
                        prod=`echo $line | cut -d "=" -f2-8 | sed 's/;/#/g'`
                else
                        prod=`echo $line | cut -d "=" -f1 | cut -d "." -f3`
                fi
                key=`echo $line |cut -d"=" -f1 |cut -d"." -f3`
                echo "ss=\`./os.space "$prod"\`" >>/$TMP_DIR/prs.check

                echo "echo \"os.space.$key=\$ss\"" >>/$TMP_DIR/prs.check


        else
                CheckValue=`echo "$res" | cut -d "=" -f1`
                echo "echo \"$CheckValue=NOT_REQ_CHECK_ID\"" >>/$TMP_DIR/prs.check
        fi
fi


res=`echo $line | grep network.pingSelf`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2` 
 

 echo "ss=\`./network.pingSelf\`" >>/$TMP_DIR/prs.check
 echo "echo \"network.pingSelf=\$ss\"" >>/$TMP_DIR/prs.check



fi

res=`echo $line | grep os.dir`
if [ "$res" != "" ]; then
scriptCmd="os.dir"
scriptParams=`echo $res | cut -d "=" -f2`
checkName="os.dir"
checkSpec="$res"
generic="True"

`generateScanCmd "$scriptCmd" "$scriptParams" "$checkName" "$checkSpec" "$generic"`
#ExpValue=`echo $res | cut -d "=" -f2-8`


 #       prod=`echo $res | cut -d "=" -f2-8`
#        echo "ss=\`./os.dir "$prod"\`" >>/$TMP_DIR/prs.check
#	key=`echo $line |cut -d"=" -f1 |cut -d"." -f3` 
#        echo "echo \"os.dir.$key=\$ss\"" >>/$TMP_DIR/prs.check


fi

res=`echo $line | grep os.ksh`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        echo "ss=\`./os.ksh\`" >>/$TMP_DIR/prs.check
        echo "echo \"os.ksh=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep os.iodevicestatus`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        echo "ss=\`./os.iodevicestatus\`" >>/$TMP_DIR/prs.check
        echo "echo \"os.iodevicestatus=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.mountcheck`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        prod=`echo $res | cut -d "=" -f2-8`
        echo "ss=\`./os.mountcheck "$prod"\`" >>/$TMP_DIR/prs.check
        echo "echo \"os.mountcheck=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep os.shell.default`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        prod=`echo $res | cut -d "=" -f2-8`
        echo "ss=\`./os.shell.default "$prod"\`" >>/$TMP_DIR/prs.check
        echo "echo \"os.shell.default=\$ss\"" >>/$TMP_DIR/prs.check
fi


res=`echo $line | grep os.ldLibPath`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        prod=`echo $res | cut -d "=" -f2-8`
        echo "ss=\`./os.ldLibPath "$prod"\`" >>/$TMP_DIR/prs.check
        echo "echo \"os.ldLibPath=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep network.fqdn`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./network.fqdn\`" >>/$TMP_DIR/prs.check
        echo "echo \"network.fqdn=\$ss\"" >>/$TMP_DIR/prs.check



fi

res=`echo $line | grep Key_Library`
#res=""
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        prod=`echo $res | cut -d "=" -f2-8`
        echo "ss=\`./Key_Library.sh "$prod"\`" >>/$TMP_DIR/prs.check
        echo "echo \"Key_Library=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.ServicePack`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        prod=`echo $res | cut -d "=" -f2-8`
        echo "ss=\`./os.ServicePack "$prod"\`" >>/$TMP_DIR/prs.check
        echo "echo \"os.ServicePack=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.servicePack`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        prod=`echo $res | cut -d "=" -f2-8`
        echo "ss=\`./os.servicePack "$prod"\`" >>/$TMP_DIR/prs.check
        echo "echo \"os.servicePack=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep os.FreePagingSpace`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./os.FreePagingSpace\`" >>/$TMP_DIR/prs.check
        echo "echo \"os.FreePagingSpace=\$ss\"" >>/$TMP_DIR/prs.check



fi
res=`echo $line | grep CpuArchitecture`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./CpuArchitecture\`" >>/$TMP_DIR/prs.check
        echo "echo \"CpuArchitecture=\$ss\"" >>/$TMP_DIR/prs.check



fi

res=`echo $line | grep de.isInstalled`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./de.isInstalled\`" >>/$TMP_DIR/prs.check

        echo "echo \"de.isInstalled=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep de.installationUnit`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./de.installationUnit\`" >>/$TMP_DIR/prs.check

        echo "echo \"de.installationUnit=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep de.installationUnit.version`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`

        #expUUIDStr=`echo $ExpValue | cut -d ";" -f1 | cut -d ":" -f2`
        #expVersionStr=`echo $ExpValue | cut -d ";" -f2 | cut -d ":" -f2`

        #echo "ss=\`./de.installationUnit.version $expUUIDStr $expVersionStr\`" >>/$TMP_DIR/prs.check
        echo "ss=\`./de.installationUnit.version \"$ExpValue\"\`" >>/$TMP_DIR/prs.check

        echo "echo \"de.installationUnit.version=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep DBType`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./DBType\`" >>/$TMP_DIR/prs.check

        echo "echo \"DBType=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep DBTypeDetails`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./DBTypeDetails\`" >>/$TMP_DIR/prs.check

        echo "echo \"DBTypeDetails=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.patch`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./os.patch\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.patch=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.strings`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
        key=`echo $line |cut -d"=" -f1 |cut -d"." -f3-8`
        echo "ss=\`./os.strings $ExpValue\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.strings.$key=\$ss\"" >>/$TMP_DIR/prs.check
fi

res=`echo $line | grep os.LibPatch`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
        key=`echo $line |cut -d"=" -f1 |cut -d"." -f3-8`
        echo "ss=\`./os.LibPatch $key\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.LibPatch.$key=\$ss\"" >>/$TMP_DIR/prs.check

fi

res=`echo $line | grep os.itmInstalled`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`


        echo "ss=\`./os.itmInstalled\`" >>/$TMP_DIR/prs.check

        echo "echo \"os.itmInstalled=\$ss\"" >>/$TMP_DIR/prs.check

fi


res=`echo $line | grep installedSoftware.WMB.version`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
        echo "ss=\`./installedSoftware.WMB.version\`" >>/$TMP_DIR/prs.check
        echo "echo \"installedSoftware.WMB.version=\$ss\"" >>/$TMP_DIR/prs.check
fi

res=`echo $line | grep installedSoftware.WMQ.version`
if [ "$res" != "" ]; then
ExpValue=`echo $res | cut -d "=" -f2`
        echo "ss=\`./installedSoftware.WMQ.version\`" >>/$TMP_DIR/prs.check
        echo "echo \"installedSoftware.WMQ.version=\$ss\"" >>/$TMP_DIR/prs.check
fi
done < "$1/$2" 2>/dev/null

exefile=`echo $2 | sed 's/\.cfg/\.sh/g'`
cp -f /$TMP_DIR/prs.check $1/$exefile
fi
rm -f /$TMP_DIR/prs.check
