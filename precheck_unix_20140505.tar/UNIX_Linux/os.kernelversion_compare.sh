#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh
logDebug " Comparing the results for the kernel version "
# Evaluator for the following property:
#     Kernel Verion
# where
#     KVerion received from the os.kernelversion collctor
#     Eversion got from the config file
#     special characters, +, *, are supported for the version
# Examples:
#     os.kernelversion=2.6
#     os.kernelversion=2.6+
#     os.kernelversion=2.*
#
# Arguments passed in to this evaluator:
# arg1 : Kernel Verion representing the Kernel version found by the collector
#        Example: 2.6
# arg2 : expected value as specified in the os.kernelversion property in the cfg file (See examples above)
#        Example: os.kernelversion=2.6

##### Helper functions #####


versionCompare() {
   #Handle special cases
   if [ "$1" = "" ] ; then
      if [ "$2" = "" ] ; then
         echo 0
         exit
      fi
   fi

   if [ "$1" = "" ] ; then
      if [ "$2" != "" ] ; then
         echo -1
         exit
      fi
   fi

   if [ "$1" != "" ] ; then
      if [ "$2" = "" ] ; then
         echo 0
         exit
      fi
   fi
   
   #if both are equal
   if [ "$1" = "$2" ] ; then
      echo 0
      exit
   fi

   expectedResult=$1
   actualResult=$2


   FirstVal=$expectedResult
   SecondVal=$actualResult 

   if [ "${FirstVal}" = "" -o "${SecondVal}" = "" ]; then
      if [ "${FirstVal}" = "" ] ; then
         if [ "$SecondVal" != "" ] ; then
            echo -1
         fi
      fi
      if [ "$FirstVal" != "" ] ; then
         if [ "$SecondVal" = "" ] ; then
            echo 0
         fi
      fi
      echo 1
   fi
   
   # which one is bigger ?
   echo ${FirstVal} >/$TMP_DIR/versioncompare.txt
   echo ${SecondVal}>>/$TMP_DIR/versioncompare.txt
   LowerValue=`cat /$TMP_DIR/versioncompare.txt | uniq | sort -n| head -1 2>/dev/null`
   rm -f /$TMP_DIR/versioncompare.txt
   if [ "$LowerValue" = "$FirstVal" ]; then
      echo "0"
   else
      echo "-1"
   fi
}


Plus_Version_Checking() {
   expectedResult=`echo "$1" | sed 's/ $//' | sed 's/+$//'`
   actualResult=$2
   Count=1

	if [ "${expectedResult}" = "" ] ; then
		if [ "$actualResult" != "" ] ; then
			echo "$PASS_STR"
			exit 
		fi
	fi
	if [ "$expectedResult" != "" ] ; then
		if [ "$actualResult" = "" ] ; then
			echo "$FAIL_STR"
			exit
		fi
	fi
	if [ "${expectedResult}" = "" ] ; then
		if [ "$actualResult" = "" ] ; then
			echo "$PASS_STR"
			exit
		fi
	fi
	if [ "${expectedResult}" = "${actualResult}" ]; then
		echo "$PASS_STR"
		exit
	fi
	tmpArg=`versionCompare $expectedResult $actualResult`
	if [ $tmpArg -eq 0 ] ; then
		echo "$PASS_STR"
		exit
	else
		echo "$FAIL_STR"
		exit
	fi
}

Star_Version_Checking() {
   expVersion=$1
   foundVersion=$2
   var1=$3 # $2 of the main argument
   expVersion=`echo $1 | sed 's/*//g'`
   tmpArg=`echo "$foundVersion" | grep "$expVersion"`
   if [ "$tmpArg" != "" ] ; then
      res=1
   fi
   if [ $res -eq 1 ] ; then
      echo "$PASS_STR"
      exit
   fi
}

Strict_Version_Checking() {
   var1=$1
   var2=$2
   if [ "$var1" = "$var2" ]; then
      echo "$PASS_STR"
   else
      echo "$FAIL_STR"
   fi
}



##### Start of main logic #####
foundValue=$1
expValue=$2

if [ "$foundValue" = "$NOTFOUND_STR" ] ; then
   foundVer="$foundValue"
fi

result="$FAIL_STR"
res=0

if [ "$foundVer" = "$NOTFOUND_STR" ]; then
   result="$FAIL_STR"
elif [ "$foundValue" = "$expValue" ]; then
   result="$PASS_STR"
else
   for expVer in `echo $expValue | sed 's/,/ /g'`
   do
      option=`echo "$expVer" | sed -e "s/^.*\(.\)$/\1/"`
      if [ "$option" = "+" ]; then
         RC=`Plus_Version_Checking "$expValue" "$foundValue"`
         if [ "$RC" = "$PASS_STR" ]; then
            result="$PASS_STR"
            break
         fi
      elif [ "$option" = "*" ]; then
         RC=`Star_Version_Checking "$expValue" "$foundValue"`
         if [ "$RC" = "$PASS_STR" ]; then
            result="$PASS_STR"
            break
         fi
      else
         RC=`Strict_Version_Checking "$expValue" "$foundValue"`
         if [ "$RC" = "$PASS_STR" ]; then
            result="$PASS_STR"
            break
         fi
      fi
   done
fi

echo "$result"
