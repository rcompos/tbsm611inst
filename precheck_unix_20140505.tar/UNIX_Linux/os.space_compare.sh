#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. $PREREQ_HOME/lib/common_function.sh


item="$2"
value=""

if [ "$1" = "$UNAVAILABLE_STR" ]; then
	echo "$FAIL_STR"
	exit
fi

if [ "$1" = "NOT_REQ_CHECK_ID" ]; then
        echo "$PASS_STR"
        exit
fi

SqBrkExist=`echo $item | grep "]"`
if [  "$SqBrkExist" = "" ]; then
	value=$item
else
	UnitCheck=`echo $item | grep -i unit`
	if [ $UnitCheck ]; then
		Unit=`echo $item | cut -d "]" -f1 | cut -d "," -f2 | cut -d ":" -f2 | cut -d "=" -f2`
		Size=`echo $item | cut -d "]" -f2`
		value=$Size$Unit
	else
		value=`echo $item | cut -d "]" -f2`
	fi
fi

valueStatus=`echo "$value" | grep "-"`
if [ "$valueStatus" != "" ]; then
	#Found range values
	RangeValStatus=`CompareRangeValues "$1" "$value"`
	echo "$RangeValStatus"
	logInfo "Evaluator os.space returning $RangeValStatus"
else
	OutPutValue=`compare $1 $value`
	if [ "$OutPutValue" = "$FAIL_STR" ]; then
		echo "$FAIL_STR"
	else
		echo "$PASS_STR"
	fi
fi
