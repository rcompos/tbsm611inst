#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

#This Evaluator identify only Mozilla, Firefox and SeaMonkey browsers
#First argument $1 contans the expected value from the configuration file
#This Evaluator returns installed browser and it's vesion
#Example : Mozilla 2.0, Firefox 1.7

. ../lib/common_function.sh

versionCompare() {

#Handle special cases
if [ "$1" = "" ]; then
        if [ "$2" = "" ]; then
                echo 0
                exit
        fi
fi

if [ "$1" = "" ]; then
        if [ "$2" != "" ]; then
                echo -1
                exit
        fi
fi

if [ "$1" != "" ]; then
        if [ "$2" = "" ]; then
                echo 1
                exit
        fi
fi

check1=`echo $1 | sed 's/*/#/g' | sed 's/+//g'`
check2=`echo $2 | sed 's/*/#/g' | sed 's/+//g'`


ver1Parts=`echo $check1 | awk -F"." '{print $1,$2,$3,$4,$5,$6}'`
ver2Parts=`echo $check2 | awk -F"." '{print $1,$2,$3,$4,$5,$6}'`
set -- $ver1Parts
set -- $ver2Parts
lenver1Parts=`echo $ver1Parts | wc -w`
lenver2Parts=`echo $ver2Parts | wc -w`

if [ $lenver1Parts -ge $lenver2Parts ]; then
        len=`echo $ver2Parts | wc -m`
        tmplen=`expr $len - 1`
        last=`echo $ver2Parts | cut -c $tmplen`
        if [ $last = "#" ]; then
                 i=$lenver2Parts
                 tmplenver1Parts=`expr $lenver1Parts - 1`
                 while [ $i -le $tmplenver1Parts ]
                 do
                         ver2Parts=$ver2Parts" #"
                         i=`expr $i + 1`
                 done
        fi
elif [ $lenver2Parts -ge $lenver1Parts ]; then
        len1=`echo $ver1Parts | wc -m`
        tmplen1=`expr $len1 - 1`
        last=`echo $ver1Parts | cut -c $tmplen1`
        if [ $last = "#" ]; then
                i=$lenver1Parts
                tmplenver2Parts=`expr $lenver2Parts - 1`
                while [ $i -le $tmplenver2Parts ]
                do
                        ver1Parts=$ver1Parts" #"
                        i=`expr $i + 1`
                done
        fi
fi

j=1
while [ $j -le $lenver2Parts -o $j -le $lenver1Parts ]
do
        v1Str="UNASSIGNED"
        v2Str="UNASSIGNED"

        if [ $j -le $lenver1Parts ]; then
                v1=`echo $ver1Parts | cut -d ' ' -f$j`
                res=`echo $v1 | tr -d '[0-9]' | tr -d '.'`
                if [ $res ]; then
                        v1Str=$v1
                        if [ $j -le $lenver2Parts ]; then
                                v2Str=`echo $ver2Parts | cut -d ' ' -f$j`
                        else
                                v2Str="0"
                        fi
                fi
        else
                v1=0
        fi

        if [ $j -le $lenver2Parts ]; then
                v2=`echo $ver2Parts | cut -d ' ' -f$j`
                res=`echo $v2 | tr -d '[0-9]' | tr -d '.'`
                if [ $res ]; then
                        if [ $j -le $lenver1Parts ]; then
                                v1Str=`echo $ver1Parts | cut -d ' ' -f$j`
                        else
                                v1Str="0"
                        fi
                        v2Str=$v2
                fi
        else
                v2=0
        fi

        if [ "$v1Str" != "UNASSIGNED" -o "$v2Str" != "UNASSIGNED" ]; then
                if [ "$v1Str" = "" ]; then
                        v1Str="0"
                fi
        if [ "$v2Str" = "" ]; then
                v2Str="0"
        fi

        #Comparing as string
        if [ "$v1Str" != "#" -a "$v2Str" != "#" ]; then
                if [ "$v1Str" != "$v2Str" ]; then
                        if [ "$v1Str" > "$v2Str" ]; then
                                versionCompare=1
                        else
                                versionCompare=-1
                        fi
                        echo $versionCompare
                        exit
                  fi
        fi
   else
        #Comparing as number
        if [ "$v1" -gt "$v2" ]; then
                versionCompare=1
                echo $versionCompare
                exit
        fi
        # echo "compared number2"
        if [ "$v2" -gt "$v1" ]; then
                versionCompare=-1
                echo $versionCompare
                exit
        fi
   fi
        j=`expr $j + 1`
        done
        # if we reach here,versions must be equal
        versionCompare=0
        echo $versionCompare
}

#Initialize local Variables below
logInfo "browser.Version Evaluator is called with parameter : $1 and $2"
MozillaBrowser=""
MozillaVersion=""
FirefoxBrowser=""
FirefoxVersion=""
SeaMonkeyBrowser=""
SeaMonkeyVersion=""
FinalDispStr=""

#Save the old IFS and Modify the IFS to ","
OLDIFS=$IFS
IFS=","

if [ "$2" = "" ]; then
	logDebug "browser.Version property missing the expected value ..."
	echo "$NOTFOUND_STR"
	exit
fi


for browser in `echo "$2"`
do
	#Identify Browsers from the expected value
	BrowserType=""
	BrowserVer=""
	BrowserType=`echo "$browser" | awk  -F" " '{print $1}'`
	BrowserVer=`echo "$browser" | awk  -F" " '{print $2}'`
	if [ "$BrowserType" = "Mozilla" ]; then
		MozillaBrowser="$BrowserType"
		MozillaVersion="$BrowserVer"
		logDebug "Checking for  browser  $MozillaBrowser $MozillaVersion"
	elif [ "$BrowserType" = "Firefox" ]; then
		FirefoxBrowser="$BrowserType"
		FirefoxVersion="$BrowserVer"
		logDebug "Checking for  browser  $FirefoxBrowser $FirefoxVersion"
	elif [ "$BrowserType" = "SeaMonkey" ]; then
		SeaMonkeyBrowser="$BrowserType"
		SeaMonkeyVersion="$BrowserVer"
		logDebug "Checking for  browser  $SeaMonkeyBrowser $SeaMonkeyVersion"
	else
		logDebug "browser.Version Evaluator does not support checking Browser = $BrowserType"
		echo "$FAIL_STR"
		exit
	fi
done

#Revert back the IFS value
IFS=$OLDIFS

if [ "$MozillaBrowser" != "" ]; then
	#Check if the Mozilla Browser is installed in the system
	if [ `which mozilla >/dev/null 2>&1` ]; then
		logDebug "Mozilla browser is installed in the system, checking version"
		res=`mozilla -version`
		firefixStr=`echo $res | grep -i "mozilla"`
		if [ "$firefixStr" ]; then
			SystemMozillaVersion=`echo $res | awk '{print $2}' | sed 's/,$//'`
			if [ "$MozillaVersion" != "" ]; then
				PlusFound=`echo $MozillaVersion | grep "+$"`
				if [ "$PlusFound" = "" ]; then
					if [ "$MozillaVersion" = "$SystemMozillaVersion" ]; then
						echo "$PASS_STR"
						exit
					fi
				else
					#Compare Browser version
					RetStatus=`versionCompare $SystemMozillaVersion $MozillaVersion`
					logDebug "Mozilla browser Version Compare : RetStatus=$RetStatus**$SystemFirefoxVersion**$FirefoxVersion"
					if [ "$RetStatus" != "-1" ]; then
						echo "$PASS_STR"
                                                exit
					fi
				fi
			else
				logDebug "Mozilla Browser Version is missing ..."
				echo "$FAIL_STR"
				exit
			fi
		fi

	else
		logDebug "Mozilla Browser is not found installed in the system"
	fi 
fi
if [ "$FirefoxBrowser" != "" ]; then
        #Check if the Firefox Browser is installed in the system
        if [ `which firefox  >/dev/null 2>&1` ]; then
		logDebug "Firefox browser is installed in the system, checking version"
                FirefoxCmd=`which firefox`
                res=`$FirefoxCmd -version`
                firefixStr=`echo $res | grep -i "Firefox"`
                if [ "$firefixStr" ]; then
                        SystemFirefoxVersion=`echo $res | awk '{print $3}' | sed 's/,$//'`
                        if [ "$FirefoxVersion" != "" ]; then
                                PlusFound=`echo $FirefoxVersion | grep "+$"`
                                if [ "$PlusFound" = "" ]; then
                                        if [ "$FirefoxVersion" = "$SystemFirefoxVersion" ]; then
                                                echo "$PASS_STR"
                                                exit
                                        fi
                                else
                                        #Compare Browser version
                                        RetStatus=`versionCompare $SystemFirefoxVersion $FirefoxVersion`
					logDebug "Firefox browser Version Compare : RetStatus=$RetStatus**$SystemFirefoxVersion**$FirefoxVersion"
                                        if [ "$RetStatus" != "-1" ]; then
						echo "$PASS_STR"
                                                exit
                                        fi
                                fi
                        else
				logDebug "Firefox Browser Version is missing ..."
				echo "$FAIL_STR"
				exit                        
			fi
                fi

        else
                logDebug "Firefox Browser is not found installed in the system"
        fi
fi
if [ "$SeaMonkeyBrowser" != "" ]; then
	#Check if the SeaMonkey Browser is installed in the system
        if [ `which seamonkey  >/dev/null 2>&1` ]; then
		logDebug "SeaMonkey browser is installed in the system, checking version"
                res=`seamonkey -v`
                firefixStr=`echo $res | grep -i "SeaMonkey"`
                if [ "$firefixStr" ]; then
                        SystemSeaMonkeyVersion=`echo $res | awk '{print $3}' | sed 's/,$//'`
                        if [ "$SeaMonkeyVersion" != "" ]; then
                                PlusFound=`echo $SeaMonkeyVersion | grep "+$"`
                                if [ "$PlusFound" = "" ]; then
                                        if [ "$SeaMonkeyVersion" = "$SystemSeaMonkeyVersion" ]; then
						echo "$PASS_STR"
                                                exit
                                        fi
                                else
                                        #Compare Browser version
                                        RetStatus=`versionCompare $SystemSeaMonkeyVersion $SeaMonkeyVersion`
					logDebug "SeaMonkey browser Version Compare : RetStatus=$RetStatus**$SystemFirefoxVersion**$FirefoxVersion"
                                        if [ "$RetStatus" != "-1" ]; then
						echo "$PASS_STR"
                                                exit
                                        fi
                                fi
                        else
				logDebug "SeaMonkey Browser Version is missing ..."
				echo "$FAIL_STR"
				exit
                        fi
                fi

        else
                logDebug "SeaMonkey Browser is not found installed in the system"
        fi
fi

#Fail if it come here
logDebug "No browser found installed in the system."
echo "$FAIL_STR"

