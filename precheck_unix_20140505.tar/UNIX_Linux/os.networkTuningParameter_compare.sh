#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

. ../lib/common_function.sh
# Arguments passed in to this evaluator:
# arg1 : Network Tuning Parameter value  got from the collector 
#        Example: 619200
# arg2 : expected value as specified in the config file
#        Example: 6192000+

#Compare function compares any 2 integer values.
#Returns/echo 0 on success
#Returns/echo -1 on failure
versionCompare() {
   #Handle special cases
   if [ "$1" = "" ] ; then
      if [ "$2" = "" ] ; then
         echo 0
	   logDebug "Exit status of function versionCompare = 0"
         exit
      fi
   fi

   if [ "$1" = "" ] ; then
      if [ "$2" != "" ] ; then
         echo -1
	   logDebug "Exit status of function versionCompare = -1"
         exit
      fi
   fi

   if [ "$1" != "" ] ; then
      if [ "$2" = "" ] ; then
         echo 0
	   logDebug "Exit status of function versionCompare = 0"
         exit
      fi
   fi
   
   #if both are equal
   if [ "$1" = "$2" ] ; then
      echo 0
	logDebug "Exit status of function versionCompare = 0"
      exit
   fi

   expectedResult=$1
   actualResult=$2

   ExpCount=1
   ActCount=1

   FirstVal=$expectedResult
   SecondVal=$actualResult 

   if [ "${FirstVal}" = "" -o "${SecondVal}" = "" ]; then
      if [ "${FirstVal}" = "" ] ; then
         if [ "$SecondVal" != "" ] ; then
	      logDebug "Exit status of function versionCompare = -1"
            echo -1
         fi
      fi
      if [ "$FirstVal" != "" ] ; then
         if [ "$SecondVal" = "" ] ; then
            echo 0
	      logDebug "Exit status of function versionCompare = 0"
         fi
      fi
      echo 1
   fi
   
   # which one is bigger ?
   echo ${FirstVal} >/$TMP_DIR/versioncompare.txt
   echo ${SecondVal}>>/$TMP_DIR/versioncompare.txt
   LowerValue=`cat /$TMP_DIR/versioncompare.txt | uniq | sort -n| head -1 2>/dev/null`
   rm -f /$TMP_DIR/versioncompare.txt
   if [ "$LowerValue" = "$FirstVal" ]; then
      echo "0"
      logDebug "version compare exiting with success"
   else
      logDebug "version compare exiting with failure"
      echo "-1"
   fi
}

#compare any 2 integer values, example 1.2.3.4 and 1.2.3.5
#Network Tuning Parameter type Value should not have the alphabets in the version number
#Returns PASS on success and FAIL on failure
Plus_Value_Checking() {
   expVersion=$1
   foundVersion=$2
   Count=1
   ExpCount=1
   ActCount=1
   while [ true ] 
   do
      FirstVal=`echo $expVersion | awk -v count=$ExpCount, -F'.' '{ print $(count) }'`
      SecondVal=`echo $foundVersion | awk -v count=$ExpCount, -F'.' '{ print $(count) }'`
      ExpCount=`expr $ExpCount + 1`
      ActCount=`expr $ActCount + 1`
      if [ "${FirstVal}" = "" ] ; then
         if [ "$SecondVal" != "" ] ; then
            echo "$PASS_STR"
	      logDebug "Exit status of function  Plus_Version_Checking = PASS"
            break ;
         fi
      fi
      if [ "$FirstVal" != "" ] ; then
         if [ "$SecondVal" = "" ] ; then
            echo "$FAIL_STR"
	      logDebug "Exit status of function  Plus_Version_Checking = FAIL"
            break ;
         fi
      fi
      if [ "${FirstVal}" = "" ] ; then
         if [ "$SecondVal" = "" ] ; then
            echo "$PASS_STR"
	      logDebug "Exit status of function  Plus_Version_Checking = PASS"
            break ;
         fi
      fi
      if [ ${FirstVal} -eq ${SecondVal} ]; then
         continue ;
      fi
      option=`echo "$FirstVal" | sed -e "s/^.*\(.\)$/\1/"`
      if [ "+" = "$option" ] ; then
         FirstVal=`echo "$FirstVal" | sed 's/+//g' | sed 's/-/./g' | sed 's/_/./g'`
         SecondVal=`echo "$SecondVal" | sed 's/+//g' | sed 's/-/./g' | sed 's/_/./g'`	
         tmpArg=`versionCompare $FirstVal $SecondVal`
	 logDebug "Sub function versionCompare : FirstVal=$FirstVal ** SecondVal=$SecondVal **tmpArg=$tmpArg"
         if [ $tmpArg -eq 0 ] ; then
            echo "$PASS_STR"
	      logDebug "Exit status of function  Plus_Version_Checking = PASS"
            exit
         fi
      else
	    tmpArg=`versionCompare $FirstVal $SecondVal`
	    if [ $tmpArg -eq 0 ] ; then
		echo "$PASS_STR"
	      logDebug "Exit status of function  Plus_Version_Checking = PASS"
		exit
	    fi
      fi
      exit
   done
}


##### Start of main logic #####
logInfo "Invoking evaluator os.networkTuningParameter_compare.sh with command line options $1 ** $2"

if [ "$1" = "$NOTFOUND_STR" ] ; then
	logWarning "Evaluator os.networkTuningParameter exiting with result : $FAIL_STR"
	echo "$FAIL_STR"
	exit
fi

foundValue=`echo $1 | sed 's/-/./g' | sed 's/_/./g' | sed 's/	/./g' | sed 's/ /./g'`
expValue=`echo $2 | sed 's/-/./g' | sed 's/_/./g' | sed 's/	/./g' | sed 's/ /./g'`


foundVer="$foundValue"
expVerStr="$expValue"
option=`echo "$expValue" | sed -e "s/^.*\(.\)$/\1/"`
if [ "+" = "$option" ]; then
        expVerStr=`echo "$expValue" | sed 's/+//g'`
fi

### Process the 1st argument and set the found version ###
# If an network Tuning Parameter Type value was found by the collector, then it will be part of the found value (arg1) 

if [ "$expValue" = "" ]; then
	logWarning "Network Tuning Parameter Type value string is not found in the property, expected value found in config file = $expValue"
	result="$FAIL_STR"
else
	logInfo "comparing the versions $foundVer and $expVerStr "
	result="$FAIL_STR"
	res=0

	# If the found Network Tuning Parameter Type value equals to the expected Network Tuning Parameter Type value then PASS the check
	# else process the Network Tuning Parameter Type value string for plus version checking, star value checking or strict value checking

	if [ "$foundVer" = "$expVerStr" ]; then
		result="$PASS_STR"
	else
                if [ "+" = "$option" ]; then
                        echo "Sub function Plus_Value_Checking : $expVerStr ** $foundVer"
                        RC=`Plus_Value_Checking "$expVerStr" "$foundVer"`
                        if [ "$RC" = "PASS" ]; then
                                result="PASS"
                        fi
                else
                                result="FAIL"
                fi
	fi
fi

logInfo "Evaluator os.networkTuningParameter_compare.sh exiting with result : $result"
echo "$result"
