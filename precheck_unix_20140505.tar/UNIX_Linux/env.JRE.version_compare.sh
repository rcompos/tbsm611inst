# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh
logDebug " Comparing the JRE Version "
versionCompare() {

#Handle special cases
if [ "$1" = "" ]; then
   if [ "$2" = "" ]; then
        echo 0
        exit
  fi
fi

if [ "$1" = "" ]; then
   if [ "$2" != "" ]; then
        echo -1
        exit
   fi
fi

if [ "$1" != "" ]; then
    if [ "$2" = "" ]; then
        echo 0
        exit
 fi
fi
#if both are equal
if [ "$1" = "$2" ]; then
        echo 0
        exit
fi

expectedResult=$1
actualResult=$2

ExpCount=1
ActCount=1

        FirstVal=$expectedResult
        SecondVal=$actualResult 

        if [ "${FirstVal}" = "" -o "${SecondVal}" = "" ]; then
                if [ "${FirstVal}" = "" ]; then
                    if [ "$SecondVal" != "" ]; then
                        echo -1
                    fi
                fi
                if [ "$FirstVal" != "" ]; then
                    if [ "$SecondVal" = "" ]; then
                        echo 0
                    fi
                fi
                echo 1
        fi
        #which one is bigger ?
        echo ${FirstVal} >/$TMP_DIR/versioncompare.txt
        echo ${SecondVal}>>/$TMP_DIR/versioncompare.txt

        LowerValue=`cat /$TMP_DIR/versioncompare.txt | uniq | sort -n| head -1 2>/dev/null`
                rm -rf /$TMP_DIR/versioncompare.txt
        if [ "$LowerValue" = "$FirstVal" ]; then
                echo "0"
        else
                echo "-1"
        fi
}

Strict_Version_Checking() {
	var1=$1
	var2=$2
	if [ "$var1" = "$var2" ]; then
		echo "$PASS_STR"
	else
		echo "$FAIL_STR"
	fi
}
Plus_Version_Checking() {

	eversion=$1
	version=$2
	Count=1
	
        while [ true ]; do

                FirstVal=`echo $eversion | awk -F"." '{print $'''$Count'''}'`
                SecondVal=`echo $version | awk -F"." '{print $'''$Count'''}'`

                Count=`expr $Count + 1`

		if [ "${FirstVal}" = "" ]; then
                    if [ "$SecondVal" != "" ]; then
                        echo "$PASS_STR"
                        break ;
                    fi
                fi
                if [ "$FirstVal" != "" ]; then
                    if [ "$SecondVal" = "" ]; then
                        echo "$FAIL_STR"
                        break ;
                    fi
                fi
                if [ "${FirstVal}" = "" ]; then
                    if [ "$SecondVal" = "" ]; then
                        echo "$PASS_STR"
                        break ;
                    fi
                fi
                if [ "${FirstVal}" = "${SecondVal}" ]; then
                        continue ;
                fi

		option=`echo "$FirstVal" | sed -e "s/^.*\(.\)$/\1/"`
                if [ "+" = "$option" ]; then
			FirstVal=`echo "$FirstVal" | sed 's/+//g' | sed 's/-/./g' | sed 's/_/./g'`
                        SecondVal=`echo "$SecondVal" | sed 's/+//g' | sed 's/-/./g' | sed 's/_/./g'`
			
			tmpArg=`versionCompare $FirstVal $SecondVal`
			if [ $tmpArg -eq 0 ]; then
				echo "$PASS_STR"
				exit
			fi
		fi
		exit
        done
}
Star_Version_Checking() {

        eversion=$1
	version=$2
        var1=$3 # $2 of the main argument

	eversion=`echo $1 | sed 's/*//g'`
	tmpArg=`echo "$version" | grep "$eversion"`
	if [ "$tmpArg" != "" ]; then
		res=1
	fi
	if [ $res -eq 1 ]; then
		echo "$PASS_STR"
		exit
	fi
}

version=`echo $1 | sed 's/-/./g' | sed 's/_/./g'`
eversion=`echo $2 | sed 's/-/./g' | sed 's/_/./g'`
res=0

if [ "$version" = "$eversion" ]; then
	echo "$PASS_STR"
	exit
fi
if [ "$1" = "$UNAVAILABLE_STR" ]; then
	echo "$FAIL_STR"
	exit
fi
for JREver in `echo $2 | sed 's/,/ /g'`
do
	option=`echo "$JREver" | sed -e "s/^.*\(.\)$/\1/"`
	if [ "+" = "$option" ]; then
		RC=`Plus_Version_Checking "$JREver" "$1"`
		if [ "$RC" = "$PASS_STR" ]; then
			echo "$PASS_STR"
			exit
		fi
	elif [ "*" = "$option" ]; then
                RC=`Star_Version_Checking $JREver $version`
                if [ "$RC" = "$PASS_STR" ]; then
                        echo "$PASS_STR"
                        exit
                fi
	else
		RC=`Strict_Version_Checking $JREver $version`
                if [ "$RC" = "$PASS_STR" ]; then
                        echo "$PASS_STR"
                        exit
                fi
	fi
done
echo "$FAIL_STR"
exit
