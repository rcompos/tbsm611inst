#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

. ../lib/common_function.sh
ExpectedVal=$2
ActualVal=$1

logInfo "network.ipv4Available evaluator is called with parameter : $1 and $2"

#If Actual value is "True", then return True
if [ "$ActualVal" = "$TRUE_STR" ]; then
        echo "$PASS_STR"
	logInfo "network.ipv4Available evaluator is exiting with value : $PASS_STR "
#If Actual value is "Not Found", then return False
elif [ "$ActualVal" = "$NOTFOUND_STR" ]; then
        echo "$FAIL_STR"
	logInfo "network.ipv4Available evaluator is exiting with value : $FAIL_STR "
#If Actual value is "False", then return False
else
	echo "$FAIL_STR"
	logInfo "network.ipv4Available evaluator is exiting with value : $FAIL_STR "
fi

