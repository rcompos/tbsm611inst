#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

. ../lib/common_function.sh
logDebug " Comparing the Oracle Server Location"

if [ "$1" = "$UNAVAILABLE_STR" ]; then
  echo "$FAIL_STR"
else
  echo "$PASS_STR"
fi 
