#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh
logDebug " Comparing the results for the locale "
versionCompare() {

#Handle special cases
if [ "$1" = "" ]; then
   if [ "$2" = "" ]; then
echo 0
exit 
  fi 
fi

if [ "$1" = "" ]; then
   if [ "$2" != "" ]; then
echo -1
exit
   fi
fi

if [ "$1" != "" ]; then
    if [ "$2" = "" ]; then
echo 1
exit   
 fi
fi

check1=`echo $1 | sed 's/*/#/g'`
check2=`echo $2 | sed 's/*/#/g'`


ver1Parts=`echo $check1 | awk -F"." '{print $1,$2,$3,$4,$5,$6}'`
ver2Parts=`echo $check2 | awk -F"." '{print $1,$2,$3,$4,$5,$6}'`
set -- $ver1Parts
set -- $ver2Parts
lenver1Parts=`echo $ver1Parts | wc -w`
lenver2Parts=`echo $ver2Parts | wc -w`


if [ $lenver1Parts -ge $lenver2Parts ]; then
     len=`echo $ver2Parts | wc -m`
      len1=`expr $len - 1`
      last=`echo $ver2Parts | cut -c $len1`
      if [ $last = "#" ]; then
         i=$lenver2Parts
	 len2=`expr $lenver1Parts - 1`
         while [ $i -le $len2 ]
         do
                 ver2Parts=$ver2Parts" #"
                 i=`expr $i + 1`
         done
      fi
elif [ $lenver2Parts -ge $lenver1Parts ]; then
      len1=`echo $ver1Parts | wc -m`
      len3=`expr $len1 - 1`
       last=`echo $ver1Parts | cut -c $len3`
      if [ $last = "#" ]; then
        i=$lenver1Parts
	len4=`expr $lenver2Parts - 1`
        while [ $i -le $len4 ]
        do
                ver1Parts=$ver1Parts" #"
                i=`expr $i + 1`
        done
      fi

fi



j=1
while [ $j -le $lenver2Parts -o $j -le $lenver1Parts ]
do 
  v1Str="UNASSIGNED"
  v2Str="UNASSIGNED"

   if [ $j -le $lenver1Parts ]; then
   v1=`echo $ver1Parts | cut -d ' ' -f$j`
   
  	 res=`echo $v1 | tr -d '[0-9]' | tr -d '.'`
	if [ $res ]; then
        v1Str=$v1
           if [ $j -le $lenver2Parts ]; then
           v2Str=`echo $ver2Parts | cut -d ' ' -f$j`
           else
           v2Str="0"
           fi
	fi




   else
     v1=0
   fi


   if [ $j -le $lenver2Parts ]; then
    v2=`echo $ver2Parts | cut -d ' ' -f$j` 
       res=`echo $v2 | tr -d '[0-9]' | tr -d '.'`
        if [ $res ]; then
           if [ $j -le $lenver1Parts ]; then
           v1Str=`echo $ver1Parts | cut -d ' ' -f$j`
           else
           v1Str="0"
           fi
           v2Str=$v2
        fi
    

   else
     v2=0
   fi

   if [ "$v1Str" != "UNASSIGNED" -o "$v2Str" != "UNASSIGNED" ]; then
       if [ "$v1Str" = "" ]; then
           v1Str="0"
       fi
       if [ "$v2Str" = "" ]; then
            v2Str="0"
       fi

     if [ "$v1Str" != "#" -a "$v2Str" != "#" ]; then
            if [ "$v1Str" != "$v2Str" ]; then 
	      if [ "$v1Str" > "$v2Str" ]; then
                  versionCompare=1
              else
                  versionCompare=-1
              fi
              echo $versionCompare
              exit
          fi
     fi

   else
  if [ "$v1" -gt "$v2" ]; then
        versionCompare=1
        echo $versionCompare
        exit
  fi
  if [ "$v2" -gt "$v1" ]; then
        versionCompare=-1
        echo $versionCompare
        exit
  fi
   fi 
   j=`expr $j + 1` 
done
versionCompare=0
echo $versionCompare
}

if [ "$1" = "$UNAVAILABLE_STR" ]; then
  echo "$FAIL_STR"
  exit
fi

res=`versionCompare $1 $2`

if [ $res -eq -1 ]; then
 echo "$FAIL_STR"
else
 echo "$PASS_STR"
fi
