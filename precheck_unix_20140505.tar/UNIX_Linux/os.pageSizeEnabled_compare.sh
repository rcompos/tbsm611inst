#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

. ../lib/common_function.sh
# Arguments passed in to this evaluator:
# arg1 : Real value received from the collector 
#        Example: <TRUE/FALSE>
# arg2 : expected value as specified in the config file
#        Example: <small | medium | large | supreme>

##### Start of main logic #####
logInfo "Invoking evaluator os.pageSizeEnabled with command line options $1 ** $2"

### Process the 1st argument and check whether it is TRUE or FALSE ###

if [ "$1" = "$TRUE_STR" ] ; then
	logInfo "Evaluator os.pageSizeEnabled exiting with result : $PASS_STR"
	echo "$PASS_STR"
else
	logInfo "Evaluator os.pageSizeEnabled exiting with result : $FAIL_STR"
	echo "$FAIL_STR"
fi

