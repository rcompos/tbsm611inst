#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh

ExpectedArch=$2
ActualArch=$1
logDebug "Comparing the CPUArchitecture"
for EachArch in `echo $ExpectedArch | sed 's/,/ /g'`
do
        if [ "$ActualArch" = "$EachArch" ]; then
                MatchFound=True
                break
        fi
done
if [ "$MatchFound" = "True" ]; then
        echo "$PASS_STR"
else
        echo "$FAIL_STR"
fi

