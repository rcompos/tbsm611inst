# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh
version=`echo $1 | sed 's/-/./g'`
#eversion=`echo $2 | sed 's/-/./g'`
#Initialize the res value to 0
res=0
option=`echo "$2" | sed -e "s/^.*\(.\)$/\1/"`

if [ "+" = "$option" ]; then
	eversion=`echo $2 | sed -e 's/[+ ]*$//g' | sed 's/-/./g'`
	tmpArg=`versionCompare $eversion $version`
	echo "tmpArg=$tmpArg"
	if [ $tmpArg -eq -1 -o $tmpArg -eq 0 ]; then
		res=1
	fi


	if [ $res -eq 1 ]; then
		echo "$PASS_STR"
		exit
	fi
elif [ "-" = "$option" ]; then
	eversion=`echo $2 | sed -e 's/[- ]*$//g' | sed 's/-/./g'`
	tmpArg=`versionCompare $eversion $version`
	if [ $tmpArg -eq 1 -o $tmpArg -eq 0 ]; then
		res=1
	fi

	if [ $res -eq 1 ]; then
		echo "$PASS_STR"
		exit
	fi
elif [ "*" = "$option" ]; then
	eversion=`echo $2 | sed -e 's/[* ]*$//g' | sed 's/-/./g'`
	tmpArg=`versionCompare $eversion $version`
	if [ $tmpArg -eq 0 ]; then
		res=1
	fi
	if [ $res -eq 1 ]; then
		echo "$PASS_STR"
		exit
	fi
else
	tmpArg=`versionCompare $eversion $version`
	if [ $tmpArg -eq 0 ]; then
		res=1
	fi

	if [ $res -eq 1 ]; then
		echo "$PASS_STR"
		exit
	fi
fi

echo "$FAIL_STR"
