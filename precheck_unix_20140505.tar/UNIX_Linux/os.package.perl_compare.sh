#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh

# Compare package versions,
# Package names are not compared by this function
# + sign is not handled here, only checks the version is equal or higher
# Return 0 if the package is equal or higher, otherwise return 1
versionCompare() {

logDebug "In os.package Compare Function : Sub function versionCompare"
#Handle special cases
if [ "$1" = "" ]; then
   if [ "$2" = "" ]; then
        echo 0
	logDebug "In versionCompare function : Returning Success"
        exit
  fi
fi

if [ "$1" = "" ]; then
   if [ "$2" != "" ]; then
        echo 2
	logDebug "In versionCompare function : Returning Failure 2"
        exit
   fi
fi

if [ "$1" != "" ]; then
    if [ "$2" = "" ]; then
	logDebug "In versionCompare function : Returning Success"
        echo 0
        exit
 fi
fi
#if both are equal
if [ "$1" = "$2" ]; then
	logDebug "In versionCompare function : Returning Success"
        echo 0
        exit
fi

expectedResult=$1
actualResult=$2

ExpCount=1
ActCount=1
Count=1

while [ true ]; do

        FirstVal=`echo $expectedResult | awk -F"." '{print $'''$Count'''}'`
        SecondVal=`echo $actualResult | awk -F"." '{print $'''$Count'''}'`

	logDebug "FirstVal=$FirstVal ** SecondVal=$SecondVal"
        Count=`expr $Count + 1`


        if [ "${FirstVal}" = "" -o "${SecondVal}" = "" ]; then
		if [ "${FirstVal}" = "" ]; then
		    if [ "$SecondVal" != "" ]; then
			echo 2 
			logDebug "In versionCompare function : Returning Failure 2"
			break ;
		    fi
		fi
		if [ "$FirstVal" != "" ]; then
		    if [ "$SecondVal" = "" ]; then
			logDebug "In versionCompare function : Returning Success"
			echo 0
			break ;
		    fi
		fi
		echo 1
                break ;
        fi
        if [ "${FirstVal}" = "${SecondVal}" ]; then
                continue ;
        fi
        #which one is bigger ?
        echo ${FirstVal} >/$TMP_DIR/versioncompare.txt
        echo ${SecondVal}>>/$TMP_DIR/versioncompare.txt

        LowerValue=`cat /$TMP_DIR/versioncompare.txt | uniq | sort -n| head -1 2>/dev/null`
		rm -rf /$TMP_DIR/versioncompare.txt
        if [ "$LowerValue" = "$FirstVal" ]; then
                echo "2"
		logDebug "In versionCompare function : Returning Failure 2"
                break ;
        else
                echo "1"
		logDebug "In versionCompare function : Returning Failure 1"
		break ;
        fi
done
}

#This function breaks the package names and calls the function version compare for comparing the versions
#Returns 0 on success otherwise 1
rpmCompare()
{

logDebug "In os.package Compare Function : Sub function rpmCompare"
#for 1st rpm

res=`echo $1 | sed 's/-/ /g'`
j=`echo $res | wc -w`
if [ "$j" -eq 1 ]; then
	rpm1ver2=""
	rpm1ver1=""
fi

if [ "$j" -eq 2 ]; then
	rpm1ver1=`echo $res | cut -d ' ' -f$j`
	rpm1ver2=""
fi

if [ "$j" -gt 2 ]; then
	rpm1ver2=`echo $res | cut -d ' ' -f$j`
	k=`expr $j - 1`
	rpm1ver1=`echo $res | cut -d ' ' -f$k`
fi

#for 2nd rpm
res=`echo $2 | sed 's/-/ /g'`
j=`echo $res | wc -w`

if [ "$j" -eq 1 ]; then
	rpm2ver1=""
	rpm2ver2=""
fi
if [ "$j" -eq 2 ]; then
rpm2ver1=`echo $res | cut -d ' ' -f$j`
rpm2ver2=""
fi
if [ "$j" -gt 2 ]; then
rpm2ver2=`echo $res | cut -d ' ' -f$j`
k=`expr $j - 1`
rpm2ver1=`echo $res | cut -d ' ' -f$k`
fi

logDebug "In rpmCompare function : rpm1ver1=$rpm1ver1 ** rpm2ver1=$rpm2ver1"
RetStatusOfversionCompare=`versionCompare $rpm1ver1 $rpm2ver1`
if [ $RetStatusOfversionCompare -eq 0 ]; then
     RetStatusOfversionCompare=`versionCompare $rpm1ver2 $rpm2ver2`
     if [ $RetStatusOfversionCompare -eq 0 ]; then
	   logDebug "In rpmCompare function : exiting with success "
           echo 0
           exit
     else
	   RetStatusOfversionCompare=`versionCompare $rpm1ver2 $rpm2ver2`
           echo $RetStatusOfversionCompare
	   logDebug "In rpmCompare function : exiting "
          exit
     fi
else
   RetStatusOfversionCompare=`versionCompare $rpm1ver1 $rpm2ver1`
   echo $RetStatusOfversionCompare
   exit
fi
}

#Check the packages existing or installed in the system using the short names
#if a package is not found using the short names then return NULL;
Compare_Check_Package_Exists() {

logDebug "In Compare_Check_Package_Exists Function : Sub function Compare_Check_Package_Exists"
	type=`uname`
	PROD_NAME=$1
	Shortname=`echo "$PROD_NAME" | cut -d"." -f1`
	if [ "$type" = "AIX" ]; then
		logDebug "In Compare_Check_Package_Exists Function :  Checking for AIX platform"
		rpm -q $PROD_NAME > /$TMP_DIR/prs.package.txt 2>/dev/null
                Package=`cat /$TMP_DIR/prs.package.txt | sed -n '$p' | cut -d' ' -f1 | grep $PROD_NAME`
                if [ "$Package" = "" ]; then
                        lslpp -l | grep $PROD_NAME > /$TMP_DIR/prs.package.txt 2>/dev/null
                        Package=`cat /$TMP_DIR/prs.package.txt | sort -r | uniq | grep " $PROD_NAME " | tr -s "       " " " | awk '{ print $1"-"$2}'`
			logDebug "Package=$Package"
                fi

	elif [ "$type" = "Linux" ]; then
		logDebug "In Compare_Check_Package_Exists Function :  Checking for Linux platform"
		rpm -q $PROD_NAME > $TMP_DIR/prs.package.txt 2>/dev/null
		Package=`cat $TMP_DIR/prs.package.txt | sed -n '1{p;q}' | cut -d' ' -f1 | grep "$Shortname"`
		logDebug "Package=$Package"

	elif [ "$type" = "SunOS" ]; then
		logDebug "In Compare_Check_Package_Exists Function :  Checking for SunOS platform"
		pkginfo -l $PROD_NAME > $TMP_DIR/prs.package.txt 2>&1
		lineCount=`cat $TMP_DIR/prs.package.txt | wc -l`
		if [ $lineCount -gt 4 ]; then
			version=`awk "/$PROD_NAME/ {for(i=1; i<=5; i++) {getline; print}}" < $TMP_DIR/prs.package.txt  | grep "VERSION" | cut -d "," -f1 | awk '{print $2}'`
			Package=`echo "$PROD_NAME-$version"`
		fi
		logDebug "Package=$Package"
	elif [ "$type" = "HP-UX" ]; then
		logDebug "In Compare_Check_Package_Exists Function :  Checking for HP-UX platform"
		swlist  -l product $PROD_NAME > $TMP_DIR/prs.package.txt 2>/dev/null
		Package=`cat $TMP_DIR/prs.package.txt | sed '/^$/d'  | sed -n '$p' | grep -v "^#" | tr -s "   " " " | tr -s "        " " " | sed 's/^[ \t]*//' |  awk '{print $1"-"$2}'`
		logDebug "Package=$Package"
	fi
	echo "$Package"

}

#Evaluator execution starting here
logInfo "In Evaluator os.package Compare function"
logInfo "Comparing values $1 and $2"
IsRangeStr=`echo $2 | grep "\["`
if [ "$IsRangeStr" = "" ]; then
	#No need to call Compare_Check_Package_Exists function, if range is not specified
    PROD=$2
	Package=$2
	logDebug "No Short name ranges provided"
else
        PROD=$2
        StartCount=`echo $PROD | cut -d "[" -f2 | cut -d "]" -f1 | cut -d"-" -f1`
        EndCount=`echo $PROD | cut -d "[" -f2 | cut -d "]" -f1 | cut -d"-" -f2`
	logDebug "Short name ranges provided : StartCount=$StartCount ** EndCount=$EndCount"
        while [ $StartCount -le $EndCount ]
        do
                PROD_Tmp=`echo $PROD | sed -e "s/\(\[[^]]*]\)/${StartCount}/"`
                StartCount=`expr $StartCount + 1`
                Package=`Compare_Check_Package_Exists "$PROD_Tmp"`
                if [ ! "$Package" = "" ]; then
                        break
                fi
        done
fi

logDebug  "perl compare Package =$Package" 

#If the range is specified, Check the package found is NULL
if [ ! "$IsRangeStr" = "" ]; then
        if [ "$Package" = "" ]; then
                logError "The evaluator cannot find the specified package, Three possible reasons for the error are as follows: 1) The package was not found within the specified range; 2) The specified package range on the left of the = delimiter is different from the one specified on the right; 3) Both the package range and package version were specified on the right of the = delimiter. Use the correct syntax and run the scan again."
                echo "$FAIL_STR"
                exit
        fi
fi

if [ "$1" != "$UNAVAILABLE_STR" ]; then
RPM_VERSION=`echo $1 | sed "s/$3/9999/g" 2>/dev/null`
#STR_BASE_ACCEPTABLE_VER=`echo $2 | sed "s/$3/9999/g" 2>/dev/null`
STR_BASE_ACCEPTABLE_VER=`echo "$Package" | sed "s/$3/9999/g" 2>/dev/null`

isDot1=`echo "$RPM_VERSION" | grep "9999\."`
if [ "$isDot1" != "" ]; then
	RPM_VERSION=`echo $RPM_VERSION | sed "s/9999\./9999-/" 2>/dev/null`
fi
isDot2=`echo "$STR_BASE_ACCEPTABLE_VER" | grep "9999\."`
if [ "$isDot2" != "" ]; then
        STR_BASE_ACCEPTABLE_VER=`echo $STR_BASE_ACCEPTABLE_VER | sed "s/9999\./9999-/" 2>/dev/null`
fi
isHyphen1=`echo "$RPM_VERSION" | grep "9999_"`
if [ "$isHyphen1" != "" ]; then
        RPM_VERSION=`echo $RPM_VERSION | sed "s/9999_/9999-/" 2>/dev/null`
fi
isHyphen2=`echo "$STR_BASE_ACCEPTABLE_VER" | grep "9999_"`
if [ "$isHyphen2" != "" ]; then
        STR_BASE_ACCEPTABLE_VER=`echo $STR_BASE_ACCEPTABLE_VER | sed "s/9999_/9999-/" 2>/dev/null`
fi

len=`echo $STR_BASE_ACCEPTABLE_VER | wc -m`
len=`expr $len - 1`

#echo $len
STR_VERSION_TYPE=`echo $STR_BASE_ACCEPTABLE_VER | cut -c $len 2>/dev/null`
#echo $STR_VERSION_TYPE
#echo $STR_BASE_ACCEPTABLE_VER
if [ "$STR_VERSION_TYPE" = "+" -o "$STR_VERSION_TYPE" = "-" ]; then
  len=`expr $len - 1`
  STR_ABSOLUTE=`echo $STR_BASE_ACCEPTABLE_VER | cut -c -${len}`
  logDebug "STR_VERSION_TYPE=$STR_VERSION_TYPE ** STR_VERSION_TYPE=$STR_VERSION_TYPE ** STR_ABSOLUTE=$STR_ABSOLUTE"
  #echo $STR_ABSOLUTE

	result=`rpmCompare $RPM_VERSION $STR_ABSOLUTE`
  if [ $result -eq 0 ]; then
	logInfo "os.package compare function exiting with $PASS_STR"
		logDebug "STR_VERSION_TYPE=$STR_VERSION_TYPE**RPM_VERSION=$RPM_VERSION**STR_ABSOLUTE=$STR_ABSOLUTE"
		if [ "$STR_ABSOLUTE" = "9999" -a "$STR_VERSION_TYPE" = "-" ]; then
			echo "$FAIL_STR"
		else
			echo "$PASS_STR"
		fi
  else 
	result=`rpmCompare $RPM_VERSION $STR_ABSOLUTE`
	if [ $result -eq 2 ]; then
		if [ "$STR_VERSION_TYPE" = "+" ]; then
			logInfo "os.package compare function exiting with $FAIL_STR"
			echo "$FAIL_STR"
		else
			logInfo "os.package compare function exiting with $PASS_STR"
			echo "$PASS_STR"
		fi
	else if [ "$STR_VERSION_TYPE" = "-" ]; then
		 logInfo "os.package compare function exiting with $FAIL_STR"
                 echo "$FAIL_STR"
        else
		 logInfo "os.package compare function exiting with $PASS_STR"
                 echo "$PASS_STR"
        fi
  fi
fi
else 
        isVerExists=`echo "$RPM_VERSION" | grep "^$STR_BASE_ACCEPTABLE_VER"`
        logDebug "os.package compare function - Checking exact match of the packages"
        if [ "$RPM_VERSION" = "$STR_BASE_ACCEPTABLE_VER" ]; then
                logInfo "os.package compare function exiting with $PASS_STR"
                echo "$PASS_STR"
        elif [ "$isVerExists" != "" ]; then
                logInfo "os.package compare function exiting with $PASS_STR"
                echo "$PASS_STR"
        else
                logInfo "os.package compare function exiting with $FAIL_STR"
                echo "$FAIL_STR"
        fi
fi
else
	STR_BASE_ACCEPTABLE_VER=`echo "$Package" | sed "s/$3/9999/g" 2>/dev/null`
	if [ "$STR_BASE_ACCEPTABLE_VER" = "9999-" ]; then
		logInfo "os.package compare function exiting with $PASS_STR"
		echo "$PASS_STR"
	else
		logInfo "os.package compare function exiting with $FAIL_STR"
		echo "$FAIL_STR"
	fi
fi
rm -f /$TMP_DIR/prs.package.txt
