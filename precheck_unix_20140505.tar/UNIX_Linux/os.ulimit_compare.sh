#!/bin/sh

# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure RESTRICTEd by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
#set -n
#Old code
. ../lib/common_function.sh
logDebug " Comparing the results for the ulimit "
if [ "$1" = "$NOTFOUND_STR" ]; then
        echo "$FAIL_STR"
        exit
fi
if [ "$2" = "Available" ]; then 
	if [ "$1" = "$AVAILABLE_STR"  ]; then
		echo  "$PASS_STR"
		exit
	else
		echo "$FAIL_STR"
		exit
	fi
fi
####Getting the Values to be checked #####
ExpValue=`echo "$2" | cut -d "]" -f2`

FirstVal=`echo $ExpValue |  awk -F"," '{ print $1}' | sed 's/+//g'`

ActVal=`echo "$1" | sed 's/unlimited/9999999999/g'`
UsrVal=`echo $FirstVal | sed 's/unlimited/9999999999/g'`

	if [ $ActVal -ge  $UsrVal ]; then
		echo "$PASS_STR"
	else
		echo "$FAIL_STR"
	fi
exit	
fi


