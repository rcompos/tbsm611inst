#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh

# Evaluator for the following property:
#     de.installationUnit.version=UUID:<RootIU UUID>;Version:<version>
# where
#     UUID : is the RootIU UUID for a product or component.  This is always unique per product or component
#     version : can be a single version or comma separated list of versions which represents the version(s) of that product or component
#     special characters, +, *, are supported for the version
# Examples:
#     de.installationUnit.version=UUID:B4B3579ACA88468CBDB20F52639EAF0A;Version:7.3.1.1+
#     de.installationUnit.version=UUID:B4B3579ACA88468CBDB20F52639EAF0A;Version:7.3.1.0,7.3.1.1+
#     de.installationUnit.version=UUID:B4B3579ACA88468CBDB20F52639EAF0A;Version:7.3.1.*
#
# Arguments passed in to this evaluator:
# arg1 : RootIU UUID and version string representing the installed version found by the collector
#        Example: UUID:B4B3579ACA88468CBDB20F52639EAF0A;Version:7.3.1.3
# arg2 : expected value as specified in the de.installationUnit.version property in the cfg file (See examples above)
#        Example: UUID:B4B3579ACA88468CBDB20F52639EAF0A;Version:7.3.1.0,7.3.1.1+

##### Helper functions #####
logDebug "Comparing the DE Installation Unit Version "
versionCompare() {
   #Handle special cases
   if [ "$1" = "" ] ; then
      if [ "$2" = "" ] ; then
         echo 0
         exit
      fi
   fi

   if [ "$1" = "" ] ; then
      if [ "$2" != "" ] ; then
         echo -1
         exit
      fi
   fi

   if [ "$1" != "" ] ; then
      if [ "$2" = "" ] ; then
         echo 0
         exit
      fi
   fi
   
   #if both are equal
   if [ "$1" = "$2" ] ; then
      echo 0
      exit
   fi

   expectedResult=$1
   actualResult=$2

   ExpCount=1
   ActCount=1

   FirstVal=$expectedResult
   SecondVal=$actualResult 

   if [ "${FirstVal}" = "" -o "${SecondVal}" = "" ]; then
      if [ "${FirstVal}" = "" ] ; then
         if [ "$SecondVal" != "" ] ; then
            echo -1
         fi
      fi
      if [ "$FirstVal" != "" ] ; then
         if [ "$SecondVal" = "" ] ; then
            echo 0
         fi
      fi
      echo 1
   fi
   
   # which one is bigger ?
   echo ${FirstVal} >/$TMP_DIR/versioncompare.txt
   echo ${SecondVal}>>/$TMP_DIR/versioncompare.txt
   LowerValue=`cat /$TMP_DIR/versioncompare.txt | uniq | sort -n| head -1 2>/dev/null`
   rm -f /$TMP_DIR/versioncompare.txt
   if [ "$LowerValue" = "$FirstVal" ]; then
      echo "0"
   else
      echo "-1"
   fi
}


Plus_Version_Checking() {
   expVersion=$1
   foundVersion=$2
   Count=1
   ExpCount=1
   ActCount=1
   while [ true ] 
   do
      FirstVal=`echo $expectedResult | awk -F"." '{print $'''$Count'''}'`
      SecondVal=`echo $actualResult | awk -F"." '{print $'''$Count'''}'`

      Count=`expr $Count + 1`

      if [ "${FirstVal}" = "" ] ; then
         if [ "$SecondVal" != "" ] ; then
            echo "$PASS_STR"
            break ;
         fi
      fi
      if [ "$FirstVal" != "" ] ; then
         if [ "$SecondVal" = "" ] ; then
            echo "$FAIL_STR"
            break ;
         fi
      fi
      if [ "${FirstVal}" = "" ] ; then
         if [ "$SecondVal" = "" ] ; then
            echo "$PASS_STR"
            break ;
         fi
      fi
      if [ "${FirstVal}" = "${SecondVal}" ]; then
         continue ;
      fi
      option=`echo "$FirstVal" | sed -e "s/^.*\(.\)$/\1/"`
      if [ "+" = "$option" ] ; then
         FirstVal=`echo "$FirstVal" | sed 's/+//g' | sed 's/-/./g' | sed 's/_/./g'`
         SecondVal=`echo "$SecondVal" | sed 's/+//g' | sed 's/-/./g' | sed 's/_/./g'`	
         tmpArg=`versionCompare $FirstVal $SecondVal`
         if [ $tmpArg -eq 0 ] ; then
            echo "$PASS_STR"
            exit
         fi
      fi
      exit
   done
}

Star_Version_Checking() {
   expVersion=$1
   foundVersion=$2
   var1=$3 # $2 of the main argument
   expVersion=`echo $1 | sed 's/*//g'`
   tmpArg=`echo "$foundVersion" | grep "$expVersion"`
   if [ "$tmpArg" != "" ] ; then
      res=1
   fi
   if [ $res -eq 1 ] ; then
      echo "$PASS_STR"
      exit
   fi
}

Strict_Version_Checking() {
   var1=$1
   var2=$2
   if [ "$var1" = "$var2" ]; then
      echo "$PASS_STR"
   else
      echo "$FAIL_STR"
   fi
}



##### Start of main logic #####
foundValue=$1
expValue=$2

### Process the 1st argument and set the found version ###
# If an installed version was found by the collector, then it will be part of the found value (arg1) passed in 
# Parse out the UUID and the 'Version:' prefix from the found string (arg1) passed in, leaving only the found version string
if [ "$foundValue" = "$NOTFOUND_STR" ] ; then
   foundVer="$foundValue"
else
   foundVer=`echo $foundValue | cut -d ";" -f2 | cut -d ":" -f2`
   ### Process the 2nd argument and set the expected version(s) ###
   # Parse out the UUID and the 'Version:' prefix leaving only the expected version string
   expVerStr=`echo $expValue | cut -d ";" -f2 | cut -d ":" -f2`   
fi

#echo "Version found by the collector is: $foundVer" >> /$TMP_DIR/de_installationUnit.version_compare.log
#echo "Expected version String is: $expVerStr" >> /$TMP_DIR/de_installationUnit.version_compare.log

result="$FAIL_STR"
res=0

# For case where DE was not found or the RootIU UUID was not found in the DE database, fail the check
# If the found version equals to the expected version then PASS the check
# else process the version string for plus version checking, star version checking or strict version checking
if [ "$foundVer" = "$NOTFOUND_STR" ]; then
   result="$FAIL_STR"
elif [ "$foundVer" = "$expVerStr" ]; then
   result="$PASS_STR"
else
   for expVer in `echo $expVerStr | sed 's/,/ /g'`
   do
      option=`echo "$expVer" | sed -e "s/^.*\(.\)$/\1/"`
      if [ "$option" = "+" ]; then
         #echo "Performing plus version checking on: $expVer $foundVer" >> /$TMP_DIR/de_installationUnit.version_compare.log
         RC=`Plus_Version_Checking "$expVer" "$foundVer"`
         if [ "$RC" = "$PASS_STR" ]; then
            result="$PASS_STR"
            break
         fi
      elif [ "$option" = "*" ]; then
         #echo "Performing star version checking on: $expVer $foundVer" >> /$TMP_DIR/de_installationUnit.version_compare.log
         RC=`Star_Version_Checking $expVer $foundVer`
         if [ "$RC" = "$PASS_STR" ]; then
            result="$PASS_STR"
            break
         fi
      else
         #echo "Performing strict version checking on: $expVer $foundVer" >> /$TMP_DIR/de_installationUnit.version_compare.log
         RC=`Strict_Version_Checking $expVer $foundVer`
         if [ "$RC" = "$PASS_STR" ]; then
            result="$PASS_STR"
            break
         fi
      fi
   done
fi

# Remove temporary files
#rm -f /$TMP_DIR/de_installationUnit.version_compare.log

echo "$result"
logDebug "Result : $result"
