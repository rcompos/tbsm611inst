# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. $PREREQ_HOME/lib/common_function.sh

if [ "$1" = "$UNAVAILABLE_STR" ]; then
        echo "$FAIL_STR"
        exit
fi

ExpVal=`echo "$2" | sed 's/+//g'`
valueStatus=`echo "$ExpVal" | grep "-"`

if [ "$valueStatus" != "" ]; then
        #Found range values
        Result=`CompareRangeValues "$1" "$ExpVal"`
        logInfo "Evaluator os.FreePagingSpace returning $RangeValStatus"
else
        ActualPS=`echo $1 | sed 's/GB/ GB/g' | cut -d " " -f1`
        ####Refining for Plus####
        IsPlusFound=`echo $2 | grep "+"`
        if [ $IsPlusFound ]; then
                ExpectedPS=`echo $2 | sed 's/.$//g' | sed 's/GB/ GB/g' | cut -d " " -f1`
                Result=`compare $ActualPS $ExpectedPS`
        else
                ExpectedPS=`echo $2 | sed 's/GB/ GB/g' | cut -d " " -f1`
                #####Divide Mantisa and Decimal part####
                ActVal1=`echo $ActualPS | cut -d "." -f1`
                ####Checking the Expected value for decimal part####
                IsDecimal=`echo $ExpectedPS | grep "."`
                if [ $IsDecimal ]; then
                        DecimalExpPart1=`echo $ExpectedPS | cut -d "." -f1`
                        DecimalExpPart2=`echo $ExpectedPS | cut -d "." -f2`

                        if [ $ActVal1 -eq $DecimalExpPart1 ]; then

                                ActVal2=`echo $ActualPS | cut -d "." -f2 | cut -c 1`
                                if [ $ActVal2 -eq $DecimalExpPart2 ]; then
                                        Result=$PASS_STR
                                else
                                        Result=$FAIL_STR
                                fi
                        else
                                Result=$FAIL_STR
                        fi
                else
                        if [ $ActVal1 -eq $ExpectedPS ]; then
                                Result=$PASS_STR
                        else
                                Result=$FAIL_STR
                        fi
                fi
        fi
fi
echo $Result
