# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

# first parameter is real architecture, like: "i386, i686"
# second parameter is expect one, like: "32 bit, 64 bit"

# filter the type
. ../lib/common_function.sh
logDebug " Comparing the details for OS Architecture "
type=`uname`


if [ "$type" = "AIX" ]; then
    #arch=`bootinfo -y`
    arch=`getconf KERNEL_BITMODE`
fi

if [ "$type" = "Linux" ]; then
        Architecture=`arch`
        case $Architecture in
                i*86|s390|ppc)
                        arch="32";;
                ia64|x86_64|ppc64|s390x)
                        arch="64";;
                *)
                        arch=`getconf LONG_BIT`
        esac
fi

if [ "$type" = "HP-UX" ]; then
        arch=`getconf KERNEL_BITS`
fi

if [ "$type" = "SunOS" ]; then
       arch=`isainfo -kv | cut -f1 -d -`
fi


# get the architecture, such as "32 bit" or "64 bit"
Earch=`echo $2 | sed 's/\([s/a-zA-Z0-9.]\{1,\}\).*/\1/g'`
# get the options, such as "+", "-"
option=`echo $2 | sed 's/.*[a-zA-Z0-9.]\{1,\}\(.\).*/\1/g'`

if [ "$option" = "+" ]; then

	if [ $arch -ge $Earch ]; then
		echo "$PASS_STR"
	else
		echo "$FAIL_STR"
	fi
else
       if [ "$option" = "-" ]; then
	
		if [ $arch -lt $Earch ]; then
			echo "$PASS_STR"
		else
			echo "$FAIL_STR"
		fi
	else
		if [ "$arch" = "$Earch" ]; then
			echo "$PASS_STR"
		else
			echo "$FAIL_STR"
		fi
	fi
fi



 

