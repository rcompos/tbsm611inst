#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************

. ../lib/common_function.sh

#Function returns PASS or FAIL
# $2 arg is the expected value from the config file
# $1 is the real value from the collector
CheckFilePermissions_compare() {
	Plusfound=`echo $2 | grep "+"`
	if [ $Plusfound ]; then
		ExpValue=`echo $2 | cut -d "]" -f2 | sed 's/.$//g'`
		operator=ge
	else
		ExpValue=`echo $2 | cut -d "]" -f2`
		operator=eq
	fi
	###Counting and making the Value readable for Comparison####
	ValCount=`echo $1 | wc -c`
	if [ $ValCount -eq 5 ]; then
		ActualVal=`echo $1 | cut -c 2-`
	else
		ActualVal=$1
	fi

	#We could have done direct integer comparison,
	FirstActnum=`echo $ActualVal | cut -c 1`
	FirstExpnum=`echo $ExpValue | cut -c 1`
	if [ $FirstActnum -$operator $FirstExpnum ]; then
		SecondActnum=`echo $ActualVal | cut -c 2`
		SecondExpnum=`echo $ExpValue | cut -c 2`
		if [ $SecondActnum -$operator $SecondExpnum ]; then
			ThirdActnum=`echo $ActualVal | cut -c 3`
			ThirdExpnum=`echo $ExpValue | cut -c 3`
			if [ $ThirdActnum -$operator $ThirdExpnum ]; then
				logInfo "os.fileInfo evaluator is exiting with return value : $PASS_STR"
				echo "$PASS_STR"
			else
				logInfo "os.fileInfo evaluator is exiting with return value : $FAIL_STR"
				echo "$FAIL_STR"
			fi
		else
			logInfo "os.fileInfo evaluator is exiting with return value : $FAIL_STR"
			echo "$FAIL_STR"
		fi
	else
		logInfo "os.fileInfo evaluator is exiting with return value : $FAIL_STR"
		echo "$FAIL_STR"
	fi
}

#Function checks the existence of the file and returns PASS or FAIL
# $1 is the real value from the collector
CheckFileExistence_compare() {
	Arg1="$1"

	if [ "$Arg1" = "$NOTFOUND_STR" ]; then
		logInfo "os.fileInfo evaluator is exiting with return value : $FAIL_STR"
		echo "$FAIL_STR"
	else
		logInfo "os.fileInfo evaluator is exiting with return value : $PASS_STR"
		echo "$PASS_STR"
	fi
}
# $1 -> Real value from the collector
# $2 -> expected value from the evaluator
logInfo "os.fileInfo evaluator is called with parameter : $1 and $2"
if [ "$1" = "$NOTFOUND_STR" ]; then
	logInfo "os.fileInfo evaluator is exiting with return value : $1"
        echo "$FAIL_STR"
        exit
fi

Arg1="$1"
Arg2="$2"

#check the file Info type,
FileInfoType=`echo "$Arg2" | awk -F"]" '{print $1}' | awk -F":" '{print $NF}'`
if [ "$FileInfoType" = "permission" ]; then
        logDebug "os.fileInfo is invoked for the type \"permission\""
	CheckFilePermissions_compare "$Arg1" "$Arg2"
elif [ "$FileInfoType" = "existence" ]; then
        logDebug "os.fileInfo is invoked for the type \"existence\""
	CheckFileExistence_compare "$Arg1" "$Arg2"
else
        logDebug "Currently os.fileInfo type \"$FileInfoType\" is not supported..."
        echo "$NOTFOUND_STR"
fi

