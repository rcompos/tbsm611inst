#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. ../lib/common_function.sh
logDebug "Fetching the DB2 Version"
verdb=`db2level 2>/dev/null`
if [ "$verdb" = "" ]; then
	#for toe in `find /opt -name db2level 2>/dev/null`
	#do
	#	verdb=`$toe`	
	#	break
	#done 

	# find the db2profile from /home
	prof=`find /home -name db2profile | sed -n '1p'`	
	if [ -z "$prof" ]; then
		echo "$UNAVAILABLE_STR"
		exit
	fi 

	. $prof
	verdb=`db2level 2>/dev/null`
fi

if [ "$verdb" = "" ]; then
	echo "$UNAVAILABLE_STR"
	exit
fi

# some shell not recognize awk -F"xxxxx", so use sed instead
#vv=`echo $verdb | awk -F"\"DB2 " '{print $2;}' | awk -F"\"" '{print $1;}'` 
vv=`echo "$verdb" | sed 's/.*\"DB2 \([v|V][0-9\.]\{1,\}\)\".*/\1/' | sed -n '/^[v|V][0-9\.]\{1,\}/p'`

#fp=`echo $verdb | awk -F"Pack \"" '{print $2;}' | awk -F"\"" '{print $1;}'`
if [ "$type" = "SunOS" ]; then
        fp=`echo "$verdb" | nawk '{printf}' | awk '{for(i=1;i<=NF;i++)if($i~/Pack/)print $(i+1)}' |  sed 's/^\"\([0-9\.]\{1\}\)\".*/\1/g' | sed -n '/^[0-9\.]\{1,\}/p'`
else
        fp=`echo "$verdb" | awk '{printf}' | awk '{for(i=1;i<=NF;i++)if($i~/Pack/)print $(i+1)}' |  sed 's/^\"\([0-9\.]\{1\}\)\".*/\1/g' | sed -n '/^[0-9\.]\{1,\}/p'`
fi
if [ -z "$fp" ]; then
	fp=`echo $verdb | awk -F"FixPak \"" '{print $2;}' | awk -F"\"" '{print $1;}'`
fi

if [ -z "$fp" ]; then
	fp="0"
fi
logDebug "The DB2 version fetched is : $vv "
echo $vv"FP"$fp
