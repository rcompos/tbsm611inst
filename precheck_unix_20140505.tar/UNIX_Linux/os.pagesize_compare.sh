#!/bin/sh
# ************** Begin Copyright - Do not add comments here ****************
#
#  Licensed Materials . Property of IBM
#  (C) Copyright IBM Corp. 2009, 2013 All Rights Reserved.
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# ************************ End Standard Header *************************
. $PREREQ_HOME/lib/common_function.sh


if [ "$1" = "$UNAVAILABLE_STR" ]; then
        echo "$FAIL_STR"
        exit
fi

ExpVal=`echo "$2" | sed 's/+//g'`

valueStatus=`echo "$ExpVal" | grep "-"`
if [ "$valueStatus" != "" ]; then
        #Found range values
        RangeValStatus=`CompareRangeValues "$1" "$ExpVal"`
        echo "$RangeValStatus"
        logInfo "Evaluator os.pagesize returning $RangeValStatus"
else
        OutPutValue=`compare $1 $ExpVal`
        if [ "$OutPutValue" = "$FAIL_STR" ]; then
                echo "$FAIL_STR"
        else
                echo "$PASS_STR"
        fi
fi
